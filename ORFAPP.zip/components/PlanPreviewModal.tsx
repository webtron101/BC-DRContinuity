
import React from 'react';
import { CloseIcon } from './icons/CloseIcon';

interface PlanPreviewModalProps {
    title: string;
    content: string;
    onClose: () => void;
}

export default function PlanPreviewModal({ title, content, onClose }: PlanPreviewModalProps) {
    
    const handlePrint = () => {
        window.print();
    };

    return (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 print:p-0 print:bg-white">
            <style>
                {`
                @media print {
                    body * {
                        visibility: hidden;
                    }
                    #print-section, #print-section * {
                        visibility: visible;
                    }
                    #print-section {
                        position: absolute;
                        left: 0;
                        top: 0;
                        width: 100%;
                    }
                    .print-hide {
                        display: none;
                    }
                }
                `}
            </style>
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-4xl h-[90vh] border border-slate-700 flex flex-col print:hidden">
                <div className="flex justify-between items-center p-4 border-b border-slate-700 print-hide">
                    <h3 className="text-lg font-semibold text-slate-200">{title}</h3>
                    <div>
                        <button onClick={handlePrint} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-1.5 px-4 rounded-lg text-sm mr-4">Print to PDF</button>
                        <button onClick={onClose} className="text-slate-400 hover:text-white">
                            <CloseIcon className="w-6 h-6" />
                        </button>
                    </div>
                </div>
                <div id="print-section" className="p-8 max-h-full overflow-y-auto bg-white text-black">
                     <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: content }} />
                </div>
            </div>
        </div>
    );
}
