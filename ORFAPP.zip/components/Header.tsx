

import React, { useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useMetadata } from '../context/MetadataContext';
import { useAuth } from '../context/AuthContext';
import { CompanyProfile } from '../types';
import { mockCompanies } from '../data/mockData';
import { useTheme } from '../context/ThemeContext';
import { SunIcon } from './icons/SunIcon';
import { MoonIcon } from './icons/MoonIcon';

const pageTitles: Record<string, string> = {
    '/': 'Dashboard',
    '/assignments': 'Assignments',
    '/framework': 'Resilience Framework',
    '/resources': 'Resources',
    '/bia': 'Business Impact Analysis',
    '/itscm': 'IT Service Continuity',
    '/documents': 'Plans & Documents',
    '/rehearsals': 'Rehearsals',
    '/risk-register': 'Risk Register',
    '/third-party-risk': 'Third-Party Risk',
    '/it-security': 'IT Security',
    '/georisk': 'GeoRisk',
    '/governance': 'Governance',
    '/compliance': 'Compliance',
    '/command-center': 'Command Center',
    '/secure-comms': 'Secure Comms',
    '/notify': 'Notifications',
    '/battlebox': 'Software Battlebox',
    '/settings': 'Settings',
    '/integrations': 'Integrations',
};

export default function Header() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { companies, currentCompany, switchCompany, addCompany } = useMetadata();
  const { theme, toggleTheme } = useTheme();
  
  const title = pageTitles[location.pathname] || 'Dashboard';

  const handleDeclareDisaster = () => {
      navigate('/command-center');
  }

  const handleAddCompany = () => {
    const newId = `c${Date.now()}`;
    const newCompanyTemplate = mockCompanies.find(c => !c.isWizardCompleted);
    if (!newCompanyTemplate) return;

    const newCompany: CompanyProfile = {
      ...newCompanyTemplate,
      id: newId,
      name: `New Company ${companies.length + 1}`,
      isWizardCompleted: false,
    };
    addCompany(newCompany);
  }

  const maturityScore = useMemo(() => {
    const framework = currentCompany?.resilienceFramework || [];
    if (framework.length === 0) return 0;
    const totalProgress = framework.reduce((sum, phase) => sum + phase.progress, 0);
    return Math.round(totalProgress / framework.length);
  }, [currentCompany?.resilienceFramework]);


  return (
    <header className="h-20 flex items-center justify-between px-6 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700/50 flex-shrink-0">
      <div>
        <h1 className="text-2xl font-semibold text-slate-800 dark:text-slate-200">{title}</h1>
        {currentCompany?.isWizardCompleted && (
            <div className="flex items-center gap-3 mt-1.5" style={{width: '350px'}}>
                <span className="text-xs font-bold text-cyan-600 dark:text-cyan-400 whitespace-nowrap">BCM Program Maturity</span>
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                    <div className="bg-gradient-to-r from-cyan-600 to-cyan-400 h-2 rounded-full" style={{ width: `${maturityScore}%` }}></div>
                </div>
                <span className="text-sm font-semibold text-slate-600 dark:text-slate-200">{maturityScore}%</span>
            </div>
        )}
      </div>
      <div className="flex items-center gap-4">
        {user?.role === 'Super Admin' && (
            <select 
              value={currentCompany?.id || ''} 
              onChange={(e) => switchCompany(e.target.value)}
              className="bg-slate-100 dark:bg-slate-700 border-slate-300 dark:border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500"
            >
              {companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
        )}
        {user?.role === 'Super Admin' && (
             <button 
                onClick={handleAddCompany}
                className="px-4 py-2 font-semibold text-white bg-green-600 rounded-lg shadow-md hover:bg-green-700 text-sm"
            >
                Add New Company
            </button>
        )}
         <button
            onClick={toggleTheme}
            className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
            aria-label="Toggle theme"
          >
            {theme === 'light' ? <MoonIcon className="h-5 w-5" /> : <SunIcon className="h-5 w-5" />}
          </button>
        <button 
            onClick={handleDeclareDisaster}
            className="px-5 py-2.5 font-semibold text-white bg-red-600 rounded-lg shadow-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-opacity-75 transform transition-all duration-200 ease-in-out active:scale-95"
            >
            Declare a Disaster
        </button>
         <button 
            onClick={logout}
            className="px-4 py-2 font-semibold text-white bg-slate-500 dark:bg-slate-600 rounded-lg hover:bg-slate-600 dark:hover:bg-slate-700 text-sm"
        >
            Logout ({user?.name})
        </button>
      </div>
    </header>
  );
};