
import React, { useState, useMemo } from 'react';
import { CloseIcon } from './icons/CloseIcon';
import { useMetadata } from '../context/MetadataContext';
import { useBIA } from '../context/BIAContext';
import { useGovernance } from '../context/GovernanceContext';
import { useIT } from '../context/ITContext';
import { useThirdPartyRisk } from '../context/ThirdPartyRiskContext';
import { Document } from '../types';

type WizardProps = {
    templateType: 'bcp' | 'drp';
    isOpen: boolean;
    onClose: () => void;
    onFinish: (document: Document) => void;
};

const StepIndicator: React.FC<{ current: number, total: number }> = ({ current, total }) => (
    <div className="flex items-center w-full my-4">
        {Array.from({ length: total }).map((_, i) => (
            <React.Fragment key={i}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${i + 1 <= current ? 'bg-cyan-500 text-white' : 'bg-slate-700 text-slate-400'}`}>
                    {i + 1}
                </div>
                {i + 1 < total && <div className={`flex-1 h-1 ${i + 1 < current ? 'bg-cyan-500' : 'bg-slate-700'}`} />}
            </React.Fragment>
        ))}
    </div>
);

export default function DocumentWizardModal({ templateType, isOpen, onClose, onFinish }: WizardProps) {
    const { currentCompany } = useMetadata();
    const { processes, businessUnits } = useBIA();
    const { bcmRoles } = useGovernance();
    const { itAssets } = useIT();
    const { vendors } = useThirdPartyRisk();

    const [step, setStep] = useState(1);
    const [docData, setDocData] = useState({
        scope: '',
        objectives: '- Maintain critical operations.\n- Recover within RTOs.',
        team: bcmRoles.map(r => r.id),
        criticalProcesses: processes.filter(p => p.criticality > 1).map(p => p.id),
        criticalAssets: itAssets.filter(a => a.riskRating > 1).map(a => a.id),
    });

    if (!isOpen || !currentCompany) return null;

    const TOTAL_STEPS = 4;

    const handleNext = () => setStep(s => Math.min(s + 1, TOTAL_STEPS));
    const handleBack = () => setStep(s => Math.max(s - 1, 1));
    
    const handleToggleSelection = (field: 'team' | 'criticalProcesses' | 'criticalAssets', id: string) => {
        setDocData(prev => ({
            ...prev,
            [field]: prev[field].includes(id) 
                ? prev[field].filter(itemId => itemId !== id) 
                : [...prev[field], id]
        }));
    };

    const generateHtml = () => {
        const { name, notifyUsers } = currentCompany;
        const businessUnitMap = new Map(businessUnits.map(bu => [bu.id, bu.name]));
        
        let content = `<h1>${templateType === 'bcp' ? 'Business Continuity Plan' : 'Disaster Recovery Plan'} for ${name}</h1>`;
        content += `<h2 style="margin-top:24px;">1. Introduction & Scope</h2><p>${docData.scope.replace(/\n/g, '<br/>')}</p>`;
        content += `<h2 style="margin-top:24px;">2. Objectives</h2><ul>${docData.objectives.split('\n').map(o => `<li>${o}</li>`).join('')}</ul>`;
        
        const rolesHtml = bcmRoles
            .filter(role => docData.team.includes(role.id))
            .map(role => `<tr><td style="padding: 8px; border: 1px solid #4A5568;">${role.name}</td><td style="padding: 8px; border: 1px solid #4A5568;">${notifyUsers.find(u => u.id === role.assigneeId)?.name || ''}</td></tr>`)
            .join('');
        content += `<h2 style="margin-top:24px;">3. Response Team</h2><table style="width:100%; border-collapse:collapse;"><thead><tr><th>Role</th><th>Assignee</th></tr></thead><tbody>${rolesHtml}</tbody></table>`;

        if (templateType === 'bcp') {
            const processesHtml = processes
                .filter(p => docData.criticalProcesses.includes(p.id))
                .map(p => `<tr><td style="padding: 8px; border: 1px solid #4A5568;">${p.name}</td><td style="padding: 8px; border: 1px solid #4A5568;">${businessUnitMap.get(p.unitId)}</td><td style="padding: 8px; border: 1px solid #4A5568;">${p.rto}</td></tr>`)
                .join('');
            content += `<h2 style="margin-top:24px;">4. Critical Business Processes</h2><table style="width:100%; border-collapse:collapse;"><thead><tr><th>Process</th><th>Unit</th><th>RTO</th></tr></thead><tbody>${processesHtml}</tbody></table>`;
        } else { // DRP
            const assetsHtml = itAssets
                .filter(a => docData.criticalAssets.includes(a.id))
                .map(a => `<tr><td style="padding: 8px; border: 1px solid #4A5568;">${a.name}</td><td style="padding: 8px; border: 1px solid #4A5568;">${a.type}</td><td style="padding: 8px; border: 1px solid #4A5568;">${a.rto || 'N/A'}</td></tr>`)
                .join('');
            content += `<h2 style="margin-top:24px;">4. Critical IT Assets for Recovery</h2><table style="width:100%; border-collapse:collapse;"><thead><tr><th>Asset</th><th>Type</th><th>RTO</th></tr></thead><tbody>${assetsHtml}</tbody></table>`;
        }
        return content;
    };

    const handleFinish = () => {
        const content = generateHtml();
        const newDoc: Document = {
            id: `doc_${Date.now()}`,
            name: `${templateType.toUpperCase()} - ${currentCompany.name} - ${new Date().toLocaleDateString()}`,
            category: 'Generated',
            type: templateType === 'bcp' ? 'BCM Plan' : 'DRP',
            version: '1.0',
            status: 'Draft',
            lastUpdated: new Date().toISOString().split('T')[0],
            owner: currentCompany.keyContacts[0]?.name || 'System',
            changeHistory: [{ version: '1.0', date: new Date().toISOString().split('T')[0], editor: 'Wizard', summary: 'Initial generation' }],
            content: content,
        };
        onFinish(newDoc);
    };

    const renderStep = () => {
        switch(step) {
            case 1: return (
                <div>
                    <h3 className="text-xl font-semibold mb-2">Scope & Objectives</h3>
                    <label className="block text-sm font-medium mb-1">Plan Scope</label>
                    <textarea value={docData.scope} onChange={e => setDocData({...docData, scope: e.target.value})} rows={4} className="w-full bg-slate-700 p-2 rounded-md" placeholder="e.g., This plan covers the recovery of critical services at the Johannesburg HQ..."></textarea>
                    <label className="block text-sm font-medium mt-4 mb-1">Plan Objectives (one per line)</label>
                    <textarea value={docData.objectives} onChange={e => setDocData({...docData, objectives: e.target.value})} rows={4} className="w-full bg-slate-700 p-2 rounded-md"></textarea>
                </div>
            );
            case 2: return (
                <div>
                    <h3 className="text-xl font-semibold mb-2">Select Team Members</h3>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                        {bcmRoles.map(role => (
                            <div key={role.id} className="flex items-center bg-slate-700 p-2 rounded-md">
                                <input type="checkbox" id={`role-${role.id}`} checked={docData.team.includes(role.id)} onChange={() => handleToggleSelection('team', role.id)} className="h-4 w-4 rounded text-cyan-500" />
                                <label htmlFor={`role-${role.id}`} className="ml-3 text-slate-300">{role.name}</label>
                            </div>
                        ))}
                    </div>
                </div>
            );
            case 3: 
                const items = templateType === 'bcp' ? processes : itAssets;
                const fieldKey = templateType === 'bcp' ? 'criticalProcesses' : 'criticalAssets';
                return (
                <div>
                    <h3 className="text-xl font-semibold mb-2">Select Critical {templateType === 'bcp' ? 'Processes' : 'Assets'}</h3>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                        {items.map(item => (
                            <div key={item.id} className="flex items-center bg-slate-700 p-2 rounded-md">
                                <input type="checkbox" id={`item-${item.id}`} checked={docData[fieldKey].includes(item.id)} onChange={() => handleToggleSelection(fieldKey, item.id)} className="h-4 w-4 rounded text-cyan-500" />
                                <label htmlFor={`item-${item.id}`} className="ml-3 text-slate-300">{item.name}</label>
                            </div>
                        ))}
                    </div>
                </div>
            );
            case 4: return (
                <div>
                    <h3 className="text-xl font-semibold mb-2">Review & Generate</h3>
                    <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700/50 max-h-96 overflow-y-auto"
                         dangerouslySetInnerHTML={{ __html: generateHtml() }} />
                </div>
            );
            default: return null;
        }
    }

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-4xl border border-slate-700 flex flex-col">
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h2 className="text-2xl font-bold">Document Wizard: {templateType.toUpperCase()}</h2>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </div>

                <div className="p-6 flex-grow overflow-y-auto">
                    <StepIndicator current={step} total={TOTAL_STEPS} />
                    <div className="mt-6">
                        {renderStep()}
                    </div>
                </div>

                <div className="flex justify-between p-4 border-t border-slate-700">
                    <button onClick={handleBack} disabled={step === 1} className="bg-slate-600 px-4 py-2 rounded-lg disabled:opacity-50">Back</button>
                    {step < TOTAL_STEPS ? (
                        <button onClick={handleNext} className="bg-cyan-600 px-4 py-2 rounded-lg">Next</button>
                    ) : (
                        <button onClick={handleFinish} className="bg-green-600 px-4 py-2 rounded-lg">Finish & Save</button>
                    )}
                </div>
            </div>
        </div>
    );
}
