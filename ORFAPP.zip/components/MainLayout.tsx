

import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';
import AiCopilotWidget from './AiCopilotWidget';
import Dashboard from '../pages/Dashboard';
import Documents from '../pages/Documents';
import RiskRegister from '../pages/RiskRegister';
import GeoRisk from '../pages/GeoRisk';
import Rehearsals from '../pages/Rehearsals';
import NotFound from '../pages/NotFound';
import BIA from '../pages/BIA';
import Notify from '../pages/Notify';
import Settings from '../pages/Settings';
import InvocationProcess from '../pages/InvocationProcess';
import Governance from '../pages/Governance';
import ITSecurity from '../pages/ITSecurity';
import Assignments from '../pages/Assignments';
import Framework from '../pages/Framework';
import Battlebox from '../pages/Battlebox';
import ITSCM from '../pages/ITSCM';
import ThirdPartyRisk from '../pages/ThirdPartyRisk';
import SecureComms from '../pages/SecureComms';
import Resources from '../pages/Resources';
import Compliance from '../pages/Compliance';
import Integrations from '../pages/Integrations';

export default function MainLayout() {
  return (
    <div className="flex h-full overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-slate-100 dark:bg-slate-800/50 p-6">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/assignments" element={<Assignments />} />
            <Route path="/bia" element={<BIA />} />
            <Route path="/risk-register" element={<RiskRegister />} />
            <Route path="/third-party-risk" element={<ThirdPartyRisk />} />
            <Route path="/georisk" element={<GeoRisk />} />
            <Route path="/documents" element={<Documents />} />
            <Route path="/battlebox" element={<Battlebox />} />
            <Route path="/itscm" element={<ITSCM />} />
            <Route path="/rehearsals" element={<Rehearsals />} />
            <Route path="/secure-comms" element={<SecureComms />} />
            <Route path="/notify" element={<Notify />} />
            <Route path="/governance" element={<Governance />} />
            <Route path="/compliance" element={<Compliance />} />
            <Route path="/framework" element={<Framework />} />
            <Route path="/it-security" element={<ITSecurity />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/integrations" element={<Integrations />} />
            <Route path="/command-center" element={<InvocationProcess />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
      <AiCopilotWidget />
    </div>
  );
};