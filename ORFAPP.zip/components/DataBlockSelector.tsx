import React from 'react';

export type DataBlockType = 'risks' | 'processes';

interface DataBlockSelectorProps {
    onInsert: (blockType: DataBlockType) => void;
}

const dataBlocks = [
    { type: 'risks' as DataBlockType, name: 'Risk Summary', description: 'Insert a table of selected risks.' },
    { type: 'processes' as DataBlockType, name: 'BIA Process List', description: 'Insert a table of critical processes from the BIA.' },
];

export default function DataBlockSelector({ onInsert }: DataBlockSelectorProps) {
    return (
        <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase text-slate-500 dark:text-slate-400">Data Blocks</h4>
            {dataBlocks.map(block => (
                <button
                    key={block.type}
                    onClick={() => onInsert(block.type)}
                    className="w-full text-left p-3 rounded-lg bg-slate-100 dark:bg-slate-700/50 hover:bg-slate-200 dark:hover:bg-slate-700"
                >
                    <p className="font-semibold text-slate-800 dark:text-slate-200">{block.name}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{block.description}</p>
                </button>
            ))}
        </div>
    );
}
