
import React from 'react';

export const ServiceNowIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <circle cx="12" cy="12" r="10" fill="#81B549" />
        <path fill="#FFFFFF" d="M12 4a8 8 0 1 0 0 16a8 8 0 0 0 0-16zm-1.5 12.5a1 1 0 0 1-1-1v-7a1 1 0 1 1 2 0v7a1 1 0 0 1-1 1zm4 0a1 1 0 0 1-1-1v-7a1 1 0 1 1 2 0v7a1 1 0 0 1-1 1z" />
    </svg>
);