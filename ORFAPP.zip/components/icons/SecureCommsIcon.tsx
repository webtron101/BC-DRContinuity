
import React from 'react';

export const SecureCommsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21.75c-3.866 0-7-1.483-7-3.375V12c0-1.892 3.134-3.375 7-3.375s7 1.483 7 3.375v6.375c0 1.892-3.134 3.375-7 3.375z" opacity={0.4}/>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.812 14.25c.32.1.65.19.99.25m3.4-3.75a4.5 4.5 0 01-2.912 1.5" />
</svg>
);
