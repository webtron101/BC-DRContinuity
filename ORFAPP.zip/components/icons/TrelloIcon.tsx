
import React from 'react';

export const TrelloIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <rect width="20" height="20" x="2" y="2" fill="#0079BF" rx="3" />
        <rect width="7" height="12" x="5" y="6" fill="#FFFFFF" rx="1" />
        <rect width="7" height="7" x="14" y="6" fill="#FFFFFF" rx="1" />
    </svg>
);