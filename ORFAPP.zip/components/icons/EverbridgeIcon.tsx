
import React from 'react';

export const EverbridgeIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <circle cx="12" cy="12" r="10" fill="#FF4500" />
        <path fill="#FFFFFF" d="M6.5,9.5l3,3l-3,3V9.5z M11.5,9.5l3,3l-3,3V9.5z M16.5,9.5l3,3l-3,3V9.5z" />
    </svg>
);