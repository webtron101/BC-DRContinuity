
import React from 'react';

export const TwilioIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <circle cx="12" cy="12" r="10" fill="#F22F46" />
        <path fill="#FFFFFF" d="M12,6a6,6,0,1,0,6,6A6,6,0,0,0,12,6Zm0,10a4,4,0,1,1,4-4A4,4,0,0,1,12,16Z" />
        <circle fill="#FFFFFF" cx="12" cy="12" r="2" />
    </svg>
);