
import React from 'react';

export const MapIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 6.75V15m0 0l-3.75-3.75M9 15l3.75-3.75M9 15v2.25m6-13.5v8.25m0 0l-3.75 3.75m3.75-3.75l3.75 3.75M15 3v4.5m-7.5 4.5V3m0 13.5h.008v.008H7.5V16.5zm.75 0a.75.75 0 000 1.5h.008a.75.75 0 000-1.5H8.25z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);