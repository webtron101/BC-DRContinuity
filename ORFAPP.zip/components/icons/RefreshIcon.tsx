
import React from 'react';

export const RefreshIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 16.023c3.481-3.481 3.481-9.137 0-12.618-3.481-3.481-9.137-3.481-12.618 0-3.481 3.481-3.481 9.137 0 12.618 3.481 3.481 9.137 3.481 12.618 0" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25v4.5h-4.5" />
  </svg>
);
