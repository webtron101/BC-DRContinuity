
import React from 'react';

export const SendIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path d="M3.105 3.105a.75.75 0 01.848-.125l13.5 6.75a.75.75 0 010 1.34l-13.5 6.75a.75.75 0 01-.973-.973l1.91-9.525-1.91-9.525a.75.75 0 01.125-.848z" />
  </svg>
);