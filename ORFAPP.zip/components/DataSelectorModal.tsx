import React, { useState, useMemo } from 'react';
import { CloseIcon } from './icons/CloseIcon';
import { useRisks } from '../context/RisksContext';
import { useBIA } from '../context/BIAContext';

export type DataBlockType = 'risks' | 'processes';

interface DataSelectorModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (selectedIds: string[]) => void;
    dataType: DataBlockType;
}

export default function DataSelectorModal({ isOpen, onClose, onSave, dataType }: DataSelectorModalProps) {
    const { risks } = useRisks();
    const { processes } = useBIA();
    const [selectedIds, setSelectedIds] = useState<string[]>([]);

    const availableItems = useMemo(() => {
        switch (dataType) {
            case 'risks':
                return risks.map(r => ({ id: r.id, name: r.title, description: r.category }));
            case 'processes':
                return processes.map(p => ({ id: p.id, name: p.name, description: p.description }));
            default:
                return [];
        }
    }, [dataType, risks, processes]);
    
    const handleToggle = (id: string) => {
        setSelectedIds(prev =>
            prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
        );
    };

    const handleSave = () => {
        onSave(selectedIds);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-2xl border border-slate-200 dark:border-slate-700 flex flex-col h-[70vh]">
                <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700">
                    <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Select {dataType.charAt(0).toUpperCase() + dataType.slice(1)}</h3>
                    <button onClick={onClose} className="text-slate-500 dark:text-slate-400 hover:text-black dark:hover:text-white">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
                <div className="p-6 flex-grow overflow-y-auto space-y-2">
                    {availableItems.map(item => (
                        <div key={item.id} className="flex items-center p-3 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                            <input
                                type="checkbox"
                                id={`item-${item.id}`}
                                checked={selectedIds.includes(item.id)}
                                onChange={() => handleToggle(item.id)}
                                className="h-4 w-4 rounded text-cyan-600 bg-slate-200 dark:bg-slate-600 border-slate-300 dark:border-slate-500 focus:ring-cyan-500"
                            />
                            <label htmlFor={`item-${item.id}`} className="ml-3 text-sm">
                                <p className="font-semibold text-slate-800 dark:text-slate-200">{item.name}</p>
                                <p className="text-slate-500 dark:text-slate-400">{item.description}</p>
                            </label>
                        </div>
                    ))}
                </div>
                <div className="p-4 border-t border-slate-200 dark:border-slate-700 flex justify-end gap-4">
                    <button onClick={onClose} className="bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-slate-200 font-semibold py-2 px-4 rounded-lg text-sm">Cancel</button>
                    <button onClick={handleSave} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg text-sm">Insert Selected ({selectedIds.length})</button>
                </div>
            </div>
        </div>
    );
}
