
import React, { useMemo, useState } from 'react';
import { ITAsset, RiskLevel } from '../types';

const getRiskClass = (level: RiskLevel) => {
    switch (level) {
        case RiskLevel.Critical: return { border: 'border-red-500', bg: 'bg-red-900/50', text: 'text-red-300' };
        case RiskLevel.High: return { border: 'border-orange-500', bg: 'bg-orange-900/50', text: 'text-orange-300' };
        case RiskLevel.Medium: return { border: 'border-yellow-500', bg: 'bg-yellow-900/50', text: 'text-yellow-300' };
        default: return { border: 'border-green-500', bg: 'bg-green-900/50', text: 'text-green-300' };
    }
};

const Icon: React.FC<{ type: ITAsset['type'] }> = ({ type }) => {
    switch (type) {
        case 'Firewall': return <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>;
        case 'Application': return <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg>;
        case 'Server (Virtual)':
        case 'Server (Physical)':
             return <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" /></svg>;
        case 'Database': return <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4v0" /></svg>;
        default: return <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 9l4-4 4 4m0 6l-4 4-4-4" /></svg>;
    }
}

interface Node extends ITAsset {
    x: number;
    y: number;
    width: number;
    height: number;
}

interface DependencyMapProps {
    assets: ITAsset[];
}

export default function DependencyMap({ assets }: DependencyMapProps) {
    const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);
    const [simulatingFailureId, setSimulatingFailureId] = useState<string | null>(null);

    const nodes = useMemo(() => {
        const hasAsset = (id: string) => assets.some(a => a.id === id);
        const basePositions: Record<string, { x: number, y: number }> = {
            'asset3': { x: 450, y: 150 }, // Firewall
            'asset2': { x: 600, y: 300 }, // CRM App
            'asset4': { x: 300, y: 450 }, // AD
            'asset1': { x: 450, y: 600 }, // DB
            'asset5': { x: 450, y: 750 }, // Storage
        };
        const width = 180;
        const height = 80;
        
        return assets.filter(a => hasAsset(a.id)).map(asset => ({
            ...asset,
            x: (basePositions[asset.id]?.x || Math.random() * 800) - width/2,
            y: (basePositions[asset.id]?.y || Math.random() * 800) - height/2,
            width,
            height,
        }));
    }, [assets]);

    const nodeMap = useMemo(() => new Map(nodes.map(n => [n.id, n])), [nodes]);

    const edges = useMemo(() => {
        const createdEdges: { from: Node, to: Node, id: string }[] = [];
        nodes.forEach(node => {
            node.dependencies.forEach(depId => {
                const dependentNode = nodeMap.get(depId);
                if (dependentNode) {
                    createdEdges.push({ from: node, to: dependentNode, id: `${node.id}-${depId}` });
                }
            });
        });
        return createdEdges;
    }, [nodes, nodeMap]);

    const { upstream, downstream } = useMemo(() => {
        const up = new Set<string>();
        const down = new Set<string>();
        const idToTrace = simulatingFailureId || selectedAssetId;

        if (!idToTrace) return { upstream: up, downstream: down };

        const addUpstream = (id: string) => {
            if (up.has(id)) return;
            up.add(id);
            const node = nodeMap.get(id);
            node?.dependencies.forEach(addUpstream);
        };
        
        const addDownstream = (id: string) => {
             if (down.has(id)) return;
             down.add(id);
             assets.forEach(asset => {
                if(asset.dependencies.includes(id)) {
                    addDownstream(asset.id);
                }
             });
        }
        
        const selectedNode = nodeMap.get(idToTrace);
        selectedNode?.dependencies.forEach(addUpstream);
        assets.forEach(asset => {
             if(asset.dependencies.includes(idToTrace)) {
                addDownstream(asset.id);
            }
        });

        return { upstream: up, downstream: down };
    }, [selectedAssetId, simulatingFailureId, nodeMap, assets]);
    
    const handleNodeClick = (e: React.MouseEvent, nodeId: string) => {
        e.stopPropagation();
        setSimulatingFailureId(null); // Clear simulation on new selection
        setSelectedAssetId(currentId => currentId === nodeId ? null : nodeId);
    }
    
    const handleSimulateFailure = (e: React.MouseEvent) => {
        e.stopPropagation();
        setSimulatingFailureId(selectedAssetId);
    }

    return (
        <div 
            className="relative w-full h-[850px] bg-slate-900/50 rounded-lg p-4 overflow-auto"
            onClick={() => {setSelectedAssetId(null); setSimulatingFailureId(null);}}
        >
            <div className="absolute top-4 left-4 z-10 space-y-2 bg-slate-800/80 p-3 rounded-lg">
                <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Legend</div>
                <div className="flex items-center gap-2 text-xs"><div className="w-3 h-3 rounded-sm bg-cyan-400 border border-cyan-300"></div> Selected</div>
                <div className="flex items-center gap-2 text-xs"><div className="w-3 h-3 rounded-sm bg-orange-400 border border-orange-300"></div> Upstream (Needs)</div>
                <div className="flex items-center gap-2 text-xs"><div className="w-3 h-3 rounded-sm bg-blue-400 border border-blue-300"></div> Downstream (Impacted)</div>
                {simulatingFailureId && <div className="flex items-center gap-2 text-xs"><div className="w-3 h-3 rounded-sm bg-red-600 border border-red-500 animate-pulse"></div> Failure Point</div>}
            </div>
            
            {selectedAssetId && !simulatingFailureId && (
                 <div className="absolute top-4 right-4 z-10">
                    <button 
                        onClick={handleSimulateFailure}
                        className="bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-4 rounded-lg shadow-lg animate-pulse"
                    >
                        Simulate Failure
                    </button>
                 </div>
            )}

            <svg className="absolute top-0 left-0" width="900" height="850">
                 <defs>
                    <marker id="arrowhead" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#64748b" /></marker>
                    <marker id="arrowhead-upstream" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#fb923c" /></marker>
                    <marker id="arrowhead-downstream" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#60a5fa" /></marker>
                 </defs>
                 {edges.map((edge) => {
                    const isUpstream = upstream.has(edge.to.id) && (edge.from.id === selectedAssetId || upstream.has(edge.from.id));
                    const isDownstream = downstream.has(edge.from.id) && (edge.to.id === selectedAssetId || downstream.has(edge.to.id));
                    let stroke = '#475569';
                    let marker = 'url(#arrowhead)';
                    if(isUpstream) { stroke = '#fb923c'; marker = 'url(#arrowhead-upstream)'; }
                    if(isDownstream) { stroke = '#60a5fa'; marker = 'url(#arrowhead-downstream)'; }
                    
                    const isFaded = (selectedAssetId || simulatingFailureId) && !isUpstream && !isDownstream;

                    return (
                        <line
                            key={edge.id}
                            x1={edge.from.x + edge.from.width / 2}
                            y1={edge.from.y + edge.from.height / 2}
                            x2={edge.to.x + edge.to.width / 2}
                            y2={edge.to.y + edge.to.height / 2}
                            stroke={stroke}
                            strokeWidth="2"
                            markerEnd={marker}
                            className={`transition-all duration-300 ${isFaded ? 'opacity-20' : 'opacity-100'}`}
                        />
                    )
                })}
            </svg>
            <div className="relative" style={{ width: 900, height: 850 }}>
                {nodes.map(node => {
                    const risk = getRiskClass(node.riskRating);
                    const isSelected = node.id === selectedAssetId;
                    const isUpstream = upstream.has(node.id);
                    const isDownstream = downstream.has(node.id);
                    const isFailurePoint = node.id === simulatingFailureId;
                    
                    const isFaded = (selectedAssetId || simulatingFailureId) && !isSelected && !isUpstream && !isDownstream && !isFailurePoint;
                    
                    let highlightClass = '';
                    if (isFailurePoint) highlightClass = 'ring-4 ring-red-500 shadow-lg shadow-red-500/50 animate-pulse';
                    else if (isSelected) highlightClass = 'ring-4 ring-cyan-400 shadow-lg shadow-cyan-500/50';
                    else if (isUpstream) highlightClass = 'ring-2 ring-orange-400';
                    else if (isDownstream) highlightClass = 'ring-2 ring-blue-400';
                    
                    return (
                         <div
                            key={node.id}
                            onClick={(e) => handleNodeClick(e, node.id)}
                            className={`absolute p-3 rounded-lg border-2 shadow-lg flex items-center space-x-3 transition-all duration-300 cursor-pointer 
                                ${isFaded ? 'opacity-20' : 'opacity-100'} 
                                ${isDownstream ? 'grayscale-[50%]' : ''}
                                ${highlightClass}
                                ${risk.border} ${risk.bg}`}
                            style={{ left: node.x, top: node.y, width: node.width, height: node.height, }}
                         >
                            <div className="relative">
                                <div className={risk.text}><Icon type={node.type} /></div>
                                <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-slate-800 ${node.status === 'Online' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                            </div>
                            <div>
                                <p className="font-bold text-sm text-slate-200 truncate">{node.name}</p>
                                <p className="text-xs text-slate-400">{node.type}</p>
                            </div>
                        </div>
                    )
                })}
            </div>
        </div>
    );
}