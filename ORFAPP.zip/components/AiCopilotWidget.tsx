import React, { useState, useRef, useEffect, useCallback } from 'react';
import { AiIcon } from './icons/AiIcon';
import { CloseIcon } from './icons/CloseIcon';
import { SendIcon } from './icons/SendIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { geminiService } from '../services/geminiService';
import { ChatMessage, MessageAuthor, GroundingChunk } from '../types';

interface AiCopilotWidgetProps {
    startOpen?: boolean;
    prefilledInput?: string;
    onClose?: () => void;
}

export default function AiCopilotWidget({ startOpen = false, prefilledInput = '', onClose }: AiCopilotWidgetProps) {
  const [isOpen, setIsOpen] = useState(startOpen);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState(prefilledInput);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const handleClose = () => {
      setIsOpen(false);
      if(onClose) {
          onClose();
      }
  }

  const handleSendMessage = useCallback(async (messageOverride?: string) => {
    const messageContent = messageOverride || input.trim();
    if (messageContent === '' || isLoading) return;

    const userMessage: ChatMessage = { author: MessageAuthor.USER, content: messageContent };
    const currentHistory = messages.length === 1 && messages[0].content === '' ? [] : messages;
    
    setMessages([...currentHistory, userMessage]);
    setInput('');
    setIsLoading(true);

    const assistantMessage: ChatMessage = { author: MessageAuthor.ASSISTANT, content: '', groundingChunks: [] };
    setMessages(prev => [...prev, assistantMessage]);

    try {
      const stream = await geminiService.sendMessageStream(messageContent, [...currentHistory, userMessage]);
      let fullResponse = '';
      
      for await (const chunk of stream) {
        fullResponse += chunk.text;
        
        setMessages(prev => {
          const newMessages = [...prev];
          const lastMessage = newMessages[newMessages.length - 1];
          if (lastMessage) {
            lastMessage.content = fullResponse;
          }
          return newMessages;
        });
      }
    } catch (error) {
      console.error('Gemini API error:', error);
       setMessages(prev => {
          const newMessages = [...prev];
          const lastMessage = newMessages[newMessages.length - 1];
          if(lastMessage) {
            lastMessage.content = "Sorry, I encountered an error. Please check the console or API key and try again.";
          }
          return newMessages;
        });
    } finally {
      setIsLoading(false);
    }
  }, [input, isLoading, messages]);
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  const initialGreeting = useCallback(async () => {
    if (messages.length > 0) return;
    
    if (prefilledInput) {
        handleSendMessage(prefilledInput);
        return;
    }
    
    setIsLoading(true);
    const assistantMessage: ChatMessage = { author: MessageAuthor.ASSISTANT, content: '' };
    setMessages([assistantMessage]);
    
    try {
        const stream = await geminiService.sendMessageStream("Hello, introduce yourself.", []);
        let fullResponse = '';
        for await (const chunk of stream) {
            const chunkText = chunk.text;
            fullResponse += chunkText;
            setMessages(prev => {
              const newMessages = [...prev];
              newMessages[newMessages.length - 1].content = fullResponse;
              return newMessages;
            });
        }
    } catch(e) {
        console.error(e);
        setMessages([{
            author: MessageAuthor.ASSISTANT,
            content: "Could not connect to the AI assistant. Please ensure your API key is configured correctly."
        }]);
    } finally {
        setIsLoading(false);
    }
  }, [messages.length, prefilledInput, handleSendMessage]);

  useEffect(() => {
    if (isOpen) {
      initialGreeting();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-cyan-500 hover:bg-cyan-400 text-white rounded-full p-4 shadow-lg transition-transform hover:scale-110"
        aria-label="Open AI Copilot"
      >
        <AiIcon className="h-8 w-8" />
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 w-[400px] h-[600px] bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-2xl shadow-2xl flex flex-col z-50 transition-all duration-300">
      <header className="flex items-center justify-between p-4 border-b border-slate-300 dark:border-slate-700">
        <div className="flex items-center">
          <AiIcon className="h-6 w-6 text-cyan-500 dark:text-cyan-400" />
          <h2 className="ml-2 font-bold text-slate-800 dark:text-slate-100">Atlas Copilot</h2>
        </div>
        <button onClick={handleClose} className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white">
          <CloseIcon className="h-6 w-6" />
        </button>
      </header>

      <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50 dark:bg-slate-800">
        {messages.map((msg, index) => (
          <div key={index} className={`flex items-start gap-3 ${msg.author === 'user' ? 'justify-end' : ''}`}>
            {msg.author === 'assistant' && <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center flex-shrink-0"><AiIcon className="w-5 h-5 text-cyan-500 dark:text-cyan-400"/></div>}
            <div className={`max-w-xs md:max-w-sm rounded-xl px-4 py-2 ${msg.author === 'user' ? 'bg-cyan-600 text-white rounded-br-none' : 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-300 rounded-bl-none'}`}>
              <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
            </div>
          </div>
        ))}
        {isLoading && messages[messages.length-1]?.author === 'user' && (
           <div className="flex items-start gap-3">
             <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center flex-shrink-0"><AiIcon className="w-5 h-5 text-cyan-500 dark:text-cyan-400"/></div>
             <div className="max-w-xs md:max-w-sm rounded-xl px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-300 rounded-bl-none">
                <SpinnerIcon className="w-5 h-5 animate-spin text-cyan-500 dark:text-cyan-400"/>
             </div>
           </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-slate-300 dark:border-slate-700">
        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={"Ask about a BCM plan..."}
            className="w-full bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg py-2 pl-3 pr-12 resize-none focus:ring-2 focus:ring-cyan-500 focus:outline-none"
            rows={1}
            disabled={isLoading}
          />
          <button onClick={() => handleSendMessage()} disabled={isLoading || input.trim() === ''} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-600 disabled:text-slate-400 dark:disabled:text-slate-600 disabled:hover:bg-transparent">
            {isLoading ? <SpinnerIcon className="h-5 w-5 animate-spin" /> : <SendIcon className="h-5 w-5" />}
          </button>
        </div>
      </div>
    </div>
  );
};