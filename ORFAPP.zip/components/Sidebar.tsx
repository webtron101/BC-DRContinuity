
import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { NAV_GROUPS } from '../constants';
import { LockIcon } from './icons/LockIcon';
import { FrameworkIcon } from './icons/FrameworkIcon';
import { ChevronDownIcon } from './icons/ChevronDownIcon';

export default function Sidebar() {
  const location = useLocation();
  const [openGroups, setOpenGroups] = useState<string[]>(NAV_GROUPS.map(g => g.name)); // Default to all open

  const toggleGroup = (groupName: string) => {
    setOpenGroups(prev => 
      prev.includes(groupName) 
        ? prev.filter(g => g !== groupName)
        : [...prev, groupName]
    );
  };

  return (
    <div className="w-64 bg-white/50 dark:bg-slate-900/70 backdrop-blur-lg flex flex-col border-r border-slate-200 dark:border-slate-700/50">
      <div className="flex items-center justify-center h-20 border-b border-slate-200 dark:border-slate-700/50 px-4 gap-3">
        <FrameworkIcon className="h-8 w-8 text-cyan-500 dark:text-cyan-400 flex-shrink-0" />
        <h1 className="text-lg font-semibold text-slate-800 dark:text-slate-200 whitespace-nowrap">Open Resilience</h1>
      </div>
      <nav className="flex-1 px-2 py-4 overflow-y-auto">
        {NAV_GROUPS.map((group) => {
          const isOpen = openGroups.includes(group.name);
          return (
            <div key={group.name} className="mb-2">
              <button 
                onClick={() => toggleGroup(group.name)}
                className="w-full flex items-center justify-between px-4 py-2 text-xs font-bold uppercase text-slate-500 dark:text-slate-500 tracking-wider hover:bg-slate-200/50 dark:hover:bg-slate-800/50 rounded-md"
              >
                <span>{group.name}</span>
                <ChevronDownIcon className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
              </button>
              <ul className={`overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
                {group.items.map((item) => {
                  const isActive = location.pathname === item.path;
                  
                  return (
                    <li key={item.name}>
                      <NavLink
                        to={item.path}
                        className={`flex items-center px-4 py-2.5 my-1 rounded-lg transition-colors duration-200 text-sm
                          hover:bg-slate-200 dark:hover:bg-slate-800 hover:text-slate-800 dark:hover:text-slate-200
                          ${isActive ? 'bg-cyan-500/10 text-cyan-500 dark:text-cyan-400 font-semibold' : 'text-slate-600 dark:text-slate-400'}
                        `}
                      >
                        <item.icon className="h-5 w-5" />
                        <span className="ml-4 flex-1">{item.name}</span>
                        {item.premium && <LockIcon className="h-4 w-4 text-slate-400 dark:text-slate-500" />}
                      </NavLink>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </nav>
      <div className="p-4 border-t border-slate-200 dark:border-slate-700/50">
        <p className="text-xs text-slate-500 dark:text-slate-500 text-center">Version 0.8.0 (Enterprise)</p>
      </div>
    </div>
  );
};