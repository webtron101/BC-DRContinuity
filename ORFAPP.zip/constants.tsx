

import React from 'react';
import { NavGroup } from './types';
import { DashboardIcon } from './components/icons/DashboardIcon';
import { DocumentIcon } from './components/icons/DocumentIcon';
import { RiskIcon } from './components/icons/RiskIcon';
import { MapIcon } from './components/icons/MapIcon';
import { RehearsalIcon } from './components/icons/RehearsalIcon';
import { BiaIcon } from './components/icons/ITDeptIcon';
import { NotifyIcon } from './components/icons/NotifyIcon';
import { GovernanceIcon } from './components/icons/GovernanceIcon';
import { ITSecurityIcon } from './components/icons/ITSecurityIcon';
import { AssignmentsIcon } from './components/icons/AssignmentsIcon';
import { FrameworkIcon } from './components/icons/FrameworkIcon';
import { BattleboxIcon } from './components/icons/BattleboxIcon';
import { ITSCMIcon } from './components/icons/ITSCMIcon';
import { ThirdPartyRiskIcon } from './components/icons/ThirdPartyRiskIcon';
import { SettingsIcon } from './components/icons/SettingsIcon';
import { CommandCenterIcon } from './components/icons/CommandCenterIcon';
import { SecureCommsIcon } from './components/icons/SecureCommsIcon';
import { ResourcesIcon } from './components/icons/ResourcesIcon';
import { ComplianceIcon } from './components/icons/ComplianceIcon';
import { IntegrationsIcon } from './components/icons/IntegrationsIcon';

export const NAV_GROUPS: NavGroup[] = [
  {
    name: 'Resilience',
    items: [
      { name: 'Dashboard', path: '/', icon: (props) => <DashboardIcon {...props} /> },
      { name: 'Framework', path: '/framework', icon: (props) => <FrameworkIcon {...props} />, premium: true },
      { name: 'Assignments', path: '/assignments', icon: (props) => <AssignmentsIcon {...props} /> },
      { name: 'Business Impact Analysis', path: '/bia', icon: (props) => <BiaIcon {...props} /> },
      { name: 'IT Service Continuity', path: '/itscm', icon: (props) => <ITSCMIcon {...props} /> },
      { name: 'Plans & Documents', path: '/documents', icon: (props) => <DocumentIcon {...props} /> },
      { name: 'Rehearsals', path: '/rehearsals', icon: (props) => <RehearsalIcon {...props} /> },
    ],
  },
  {
    name: 'Risk',
    items: [
      { name: 'Risk Register', path: '/risk-register', icon: (props) => <RiskIcon {...props} /> },
      { name: 'Third-Party Risk', path: '/third-party-risk', icon: (props) => <ThirdPartyRiskIcon {...props} /> },
      { name: 'IT Security', path: '/it-security', icon: (props) => <ITSecurityIcon {...props} />, premium: true },
      { name: 'GeoRisk', path: '/georisk', icon: (props) => <MapIcon {...props} />, premium: true },
    ],
  },
  {
    name: 'Governance',
    items: [
      { name: 'Governance', path: '/governance', icon: (props) => <GovernanceIcon {...props} /> },
      { name: 'Compliance', path: '/compliance', icon: (props) => <ComplianceIcon {...props} /> },
    ],
  },
  {
    name: 'Response',
    items: [
      { name: 'Command Center', path: '/command-center', icon: (props) => <CommandCenterIcon {...props} /> },
      { name: 'Secure Comms', path: '/secure-comms', icon: (props) => <SecureCommsIcon {...props} /> },
      { name: 'Notifications', path: '/notify', icon: (props) => <NotifyIcon {...props} />, premium: true },
      { name: 'Software Battlebox', path: '/battlebox', icon: (props) => <BattleboxIcon {...props} /> },
    ],
  },
  {
    name: 'System',
    items: [
      { name: 'Integrations', path: '/integrations', icon: (props) => <IntegrationsIcon {...props} /> },
      { name: 'Resources', path: '/resources', icon: (props) => <ResourcesIcon {...props} /> },
      { name: 'Settings', path: '/settings', icon: (props) => <SettingsIcon {...props} /> },
    ],
  }
];