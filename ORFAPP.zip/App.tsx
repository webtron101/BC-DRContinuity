
import React from 'react';
import { useAuth } from './context/AuthContext';
import { MetadataProvider, useMetadata } from './context/MetadataContext';
import Login from './pages/Login';
import MainLayout from './components/MainLayout';
import SetupWizard from './pages/SetupWizard';
import WaitingForSetup from './pages/WaitingForSetup';
import { AssignmentsProvider } from './context/AssignmentsContext';
import { RisksProvider } from './context/RisksContext';
import { BIAProvider } from './context/BIAContext';
import { ITProvider } from './context/ITContext';
import { DocumentsProvider } from './context/DocumentsContext';
import { ThirdPartyRiskProvider } from './context/ThirdPartyRiskContext';
import { RehearsalsProvider } from './context/RehearsalsContext';
import { GovernanceProvider } from './context/GovernanceContext';
import { IncidentProvider } from './context/IncidentContext';
import { SpinnerIcon } from './components/icons/SpinnerIcon';
import { SecureCommsProvider } from './context/SecureCommsContext';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { Routes, Route } from 'react-router-dom';
import VendorPortal from './pages/VendorPortal';

const ThemedApp: React.FC = () => {
    return (
        <MetadataProvider>
            <AssignmentsProvider>
                <RisksProvider>
                    <BIAProvider>
                        <ITProvider>
                            <DocumentsProvider>
                                <ThirdPartyRiskProvider>
                                    <RehearsalsProvider>
                                        <GovernanceProvider>
                                            <IncidentProvider>
                                                <SecureCommsProvider>
                                                    <Routes>
                                                        <Route path="/vendor-portal/:vendorId/:accessKey" element={<VendorPortal />} />
                                                        <Route path="/*" element={<AppContentRouter />} />
                                                    </Routes>
                                                </SecureCommsProvider>
                                            </IncidentProvider>
                                        </GovernanceProvider>
                                    </RehearsalsProvider>
                                </ThirdPartyRiskProvider>
                            </DocumentsProvider>
                        </ITProvider>
                    </BIAProvider>
                </RisksProvider>
            </AssignmentsProvider>
        </MetadataProvider>
    )
}


// This component determines what to show based on company setup status.
const AppContent: React.FC = () => {
    const { user } = useAuth(); // User is guaranteed to exist here
    const { currentCompany } = useMetadata();
    
    // While the current company is being loaded from context, show a spinner.
    if (!currentCompany) {
        return (
            <div className="flex items-center justify-center h-full">
                <SpinnerIcon className="w-12 h-12 animate-spin text-cyan-400" />
            </div>
        );
    }

    // Once company is loaded, check if the setup wizard needs to be shown.
    if (!currentCompany.isWizardCompleted) {
        if (user?.role === 'User') {
            return <WaitingForSetup />;
        }
        return <SetupWizard />;
    }

    // Otherwise, show the main application layout.
    return <MainLayout />;
};


// This component handles routing based on authentication state
const AppContentRouter: React.FC = () => {
  const { user } = useAuth();

  if (!user) {
    return <Login />;
  }
  
  return <AppContent />;
}


// The main App component, which sets up the base themed div.
export default function App() {
  return (
    <div className="text-slate-800 dark:text-slate-300 h-full">
      <ThemedApp />
    </div>
  )
};