

import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { Vendor, SuppliedService, Breach, ThirdPartyAssessmentQuestion, ThirdPartyAssessmentAnswer, VendorCertificate } from '../types';
import { useMetadata } from './MetadataContext';
import { mockAllVendors, mockAllSuppliedServices, mockAssessmentQuestions } from '../data/mockData';

interface ThirdPartyRiskContextType {
    vendors: Vendor[];
    suppliedServices: SuppliedService[];
    assessmentQuestions: ThirdPartyAssessmentQuestion[];
    addVendor: (vendor: Omit<Vendor, 'id' | 'riskScore' | 'assessments' | 'certificates'>) => void;
    addSuppliedService: (service: Omit<SuppliedService, 'id'>) => void;
    logSlaBreach: (serviceId: string, breach: Omit<Breach, 'id' | 'date'>) => void;
    updateVendorAssessment: (vendorId: string, answers: ThirdPartyAssessmentAnswer[]) => void;
    addVendorCertificate: (vendorId: string, certificate: Omit<VendorCertificate, 'id'>) => void;
    generateVendorAccessKey: (vendorId: string) => string;
}

const ThirdPartyRiskContext = createContext<ThirdPartyRiskContextType | undefined>(undefined);

export const ThirdPartyRiskProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { currentCompany } = useMetadata();
    const [vendors, setVendors] = useState<Vendor[]>([]);
    const [suppliedServices, setSuppliedServices] = useState<SuppliedService[]>([]);
    const assessmentQuestions = mockAssessmentQuestions;

    useEffect(() => {
        if (currentCompany) {
            setVendors(mockAllVendors[currentCompany.id] || []);
            setSuppliedServices(mockAllSuppliedServices[currentCompany.id] || []);
        } else {
            setVendors([]);
            setSuppliedServices([]);
        }
    }, [currentCompany]);

    const addVendor = useCallback((vendorData: Omit<Vendor, 'id' | 'riskScore' | 'assessments' | 'certificates'>) => {
        const newVendor: Vendor = { 
            ...vendorData, 
            id: `v-${Date.now()}`,
            riskScore: 30, // Default starting score
            assessments: [],
            certificates: [],
        };
        setVendors(prev => [newVendor, ...prev]);
    }, []);

    const addSuppliedService = useCallback((serviceData: Omit<SuppliedService, 'id'>) => {
        const newService = { ...serviceData, id: `ss-${Date.now()}`};
        setSuppliedServices(prev => [newService, ...prev]);
    }, []);

    const logSlaBreach = useCallback((serviceId: string, breachData: Omit<Breach, 'id' | 'date'>) => {
        const newBreach = { ...breachData, id: `b-${Date.now()}`, date: new Date().toISOString().split('T')[0] };
        setSuppliedServices(prev => prev.map(s => {
            if (s.id === serviceId) {
                return { ...s, breaches: [...(s.breaches || []), newBreach] };
            }
            return s;
        }));
    }, []);

    const updateVendorAssessment = useCallback((vendorId: string, answers: ThirdPartyAssessmentAnswer[]) => {
        setVendors(prev => prev.map(v => {
            if (v.id === vendorId) {
                // Simple risk scoring logic for mock purposes
                const scoreMap = { 'Yes': 100, 'Partial': 50, 'No': 0, 'N/A': 75 };
                let totalScore = 0;
                answers.forEach(ans => {
                    totalScore += scoreMap[ans.answer];
                });
                const riskScore = answers.length > 0 ? Math.round(totalScore / answers.length) : v.riskScore;
                
                return { ...v, assessments: answers, riskScore };
            }
            return v;
        }));
    }, []);

    const addVendorCertificate = useCallback((vendorId: string, certificateData: Omit<VendorCertificate, 'id'>) => {
        const newCertificate: VendorCertificate = { ...certificateData, id: `cert-${Date.now()}`};
        setVendors(prev => prev.map(v => {
            if (v.id === vendorId) {
                return { ...v, certificates: [...v.certificates, newCertificate] };
            }
            return v;
        }));
    }, []);
    
    const generateVendorAccessKey = useCallback((vendorId: string): string => {
        const key = `key_${Math.random().toString(36).substr(2, 16)}`;
        setVendors(prev => prev.map(v => 
            v.id === vendorId ? { ...v, accessKey: key } : v
        ));
        return key;
    }, []);

    const value = useMemo(() => ({
        vendors, suppliedServices, assessmentQuestions,
        addVendor, addSuppliedService, logSlaBreach, updateVendorAssessment, addVendorCertificate, generateVendorAccessKey
    }), [vendors, suppliedServices, assessmentQuestions, addVendor, addSuppliedService, logSlaBreach, updateVendorAssessment, addVendorCertificate, generateVendorAccessKey]);

    return <ThirdPartyRiskContext.Provider value={value}>{children}</ThirdPartyRiskContext.Provider>;
};

export const useThirdPartyRisk = (): ThirdPartyRiskContextType => {
    const context = useContext(ThirdPartyRiskContext);
    if (!context) {
        throw new Error('useThirdPartyRisk must be used within a ThirdPartyRiskProvider');
    }
    return context;
};