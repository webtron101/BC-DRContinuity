
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { Assignment } from '../types';
import { useMetadata } from './MetadataContext';
import { mockAllAssignments } from '../data/mockData';

interface AssignmentsContextType {
    assignments: Assignment[];
    addAssignment: (assignment: Assignment) => void;
    updateAssignment: (assignmentId: string, updates: Partial<Assignment>) => void;
}

const AssignmentsContext = createContext<AssignmentsContextType | undefined>(undefined);

export const AssignmentsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { currentCompany } = useMetadata();
    const [assignments, setAssignments] = useState<Assignment[]>([]);

    useEffect(() => {
        if (currentCompany) {
            // In a real app, this would be an API call.
            setAssignments(mockAllAssignments[currentCompany.id] || []);
        } else {
            setAssignments([]);
        }
    }, [currentCompany]);

    const addAssignment = useCallback((assignment: Assignment) => {
        setAssignments(prev => [...prev, assignment]);
        // In a real app, this would also update the persistent source (e.g., mockAllAssignments or an API)
        // For this mock setup, we'll just update local state.
    }, []);

    const updateAssignment = useCallback((assignmentId: string, updates: Partial<Assignment>) => {
        setAssignments(prev => prev.map(a => a.id === assignmentId ? {...a, ...updates} : a));
    }, []);

    const value = useMemo(() => ({ assignments, addAssignment, updateAssignment }), [assignments, addAssignment, updateAssignment]);

    return (
        <AssignmentsContext.Provider value={value}>
            {children}
        </AssignmentsContext.Provider>
    );
};

export const useAssignments = (): AssignmentsContextType => {
    const context = useContext(AssignmentsContext);
    if (!context) {
        throw new Error('useAssignments must be used within an AssignmentsProvider');
    }
    return context;
};
