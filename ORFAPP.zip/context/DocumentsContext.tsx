

import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { Document, ComplianceItem, DocumentTemplate, SoAControl, NotificationTemplate } from '../types';
import { useMetadata } from './MetadataContext';
import { mockAllDocuments, mockAllComplianceItems, mockAllDocumentTemplates, mockAllSoAControls, mockAllNotificationTemplates } from '../data/mockData';

interface DocumentsContextType {
    documents: Document[];
    complianceItems: ComplianceItem[];
    documentTemplates: DocumentTemplate[];
    notificationTemplates: NotificationTemplate[];
    statementOfApplicability: SoAControl[];
    addDocument: (document: Document) => void;
    approveDocument: (docId: string, userId: string, userName: string) => void;
    updateSoAControl: (controlId: string, updates: Partial<SoAControl>) => void;
}

const DocumentsContext = createContext<DocumentsContextType | undefined>(undefined);

export const DocumentsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { currentCompany } = useMetadata();
    const [documents, setDocuments] = useState<Document[]>([]);
    const [complianceItems, setComplianceItems] = useState<ComplianceItem[]>([]);
    const [documentTemplates, setDocumentTemplates] = useState<DocumentTemplate[]>([]);
    const [notificationTemplates, setNotificationTemplates] = useState<NotificationTemplate[]>([]);
    const [statementOfApplicability, setStatementOfApplicability] = useState<SoAControl[]>([]);

    useEffect(() => {
        if (currentCompany) {
            setDocuments(mockAllDocuments[currentCompany.id] || []);
            setComplianceItems(mockAllComplianceItems[currentCompany.id] || []);
            setDocumentTemplates(mockAllDocumentTemplates[currentCompany.id] || []);
            setNotificationTemplates(mockAllNotificationTemplates[currentCompany.id] || []);
            setStatementOfApplicability(mockAllSoAControls[currentCompany.id] || []);
        } else {
            setDocuments([]);
            setComplianceItems([]);
            setDocumentTemplates([]);
            setNotificationTemplates([]);
            setStatementOfApplicability([]);
        }
    }, [currentCompany]);

    const addDocument = useCallback((document: Document) => {
        setDocuments(prev => [document, ...prev]);
    }, []);

    const approveDocument = useCallback((docId: string, userId: string, userName: string) => {
        setDocuments(prev => prev.map(doc => {
            if (doc.id === docId) {
                const newVersion = (parseFloat(doc.version) + 0.1).toFixed(1);
                return {
                    ...doc,
                    status: 'Approved' as 'Approved',
                    version: newVersion,
                    lastUpdated: new Date().toISOString().split('T')[0],
                    changeHistory: [{ version: newVersion, date: new Date().toISOString().split('T')[0], editor: userName, summary: `Digitally approved.`}, ...doc.changeHistory],
                    approvals: [...(doc.approvals || []), { userId, userName, timestamp: new Date().toISOString() }]
                }
            }
            return doc;
        }));
    }, []);

    const updateSoAControl = useCallback((controlId: string, updates: Partial<SoAControl>) => {
        setStatementOfApplicability(prev => prev.map(control => 
            control.id === controlId ? { ...control, ...updates } : control
        ));
    }, []);

    const value = useMemo(() => ({
        documents, complianceItems, documentTemplates, notificationTemplates, statementOfApplicability,
        addDocument, approveDocument, updateSoAControl,
    }), [documents, complianceItems, documentTemplates, notificationTemplates, statementOfApplicability, addDocument, approveDocument, updateSoAControl]);

    return <DocumentsContext.Provider value={value}>{children}</DocumentsContext.Provider>;
};

export const useDocuments = (): DocumentsContextType => {
    const context = useContext(DocumentsContext);
    if (!context) {
        throw new Error('useDocuments must be used within a DocumentsProvider');
    }
    return context;
};
