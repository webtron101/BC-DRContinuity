
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { ITAsset, Network, BattleboxItem } from '../types';
import { useMetadata } from './MetadataContext';
import { mockAllITAssets, mockAllNetworks, mockAllBattleboxItems } from '../data/mockData';

interface ITContextType {
    itAssets: ITAsset[];
    networks: Network[];
    battleboxItems: BattleboxItem[];
    addITAsset: (asset: ITAsset) => void;
    updateITAsset: (assetId: string, updates: Partial<ITAsset>) => void;
    addBattleboxItem: (item: BattleboxItem) => void;
}

const ITContext = createContext<ITContextType | undefined>(undefined);

export const ITProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { currentCompany } = useMetadata();
    const [itAssets, setItAssets] = useState<ITAsset[]>([]);
    const [networks, setNetworks] = useState<Network[]>([]);
    const [battleboxItems, setBattleboxItems] = useState<BattleboxItem[]>([]);

    useEffect(() => {
        if (currentCompany) {
            setItAssets(mockAllITAssets[currentCompany.id] || []);
            setNetworks(mockAllNetworks[currentCompany.id] || []);
            setBattleboxItems(mockAllBattleboxItems[currentCompany.id] || []);
        } else {
            setItAssets([]);
            setNetworks([]);
            setBattleboxItems([]);
        }
    }, [currentCompany]);

    const addITAsset = useCallback((asset: ITAsset) => setItAssets(prev => [...prev, asset]), []);
    const updateITAsset = useCallback((assetId: string, updates: Partial<ITAsset>) => {
        setItAssets(prev => prev.map(a => a.id === assetId ? { ...a, ...updates } : a));
    }, []);
    const addBattleboxItem = useCallback((item: BattleboxItem) => setBattleboxItems(prev => [...prev, item]), []);
    
    const value = useMemo(() => ({
        itAssets, networks, battleboxItems,
        addITAsset, updateITAsset, addBattleboxItem,
    }), [itAssets, networks, battleboxItems, addITAsset, updateITAsset, addBattleboxItem]);

    return <ITContext.Provider value={value}>{children}</ITContext.Provider>;
};

export const useIT = (): ITContextType => {
    const context = useContext(ITContext);
    if (!context) {
        throw new Error('useIT must be used within an ITProvider');
    }
    return context;
};
