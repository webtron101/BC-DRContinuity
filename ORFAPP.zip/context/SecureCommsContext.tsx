
import React, { createContext, useState, useContext, ReactNode, useEffect, useMemo, useCallback } from 'react';
import { ChatChannel, SecureMessage } from '../types';
import { useMetadata } from './MetadataContext';
import { useAuth } from './AuthContext';
import { mockAllChannels, mockAllSecureMessages } from '../data/mockData';

interface SecureCommsContextType {
    channels: ChatChannel[];
    messages: SecureMessage[];
    getMessagesForChannel: (channelId: string) => SecureMessage[];
    sendMessage: (channelId: string, content: string) => void;
}

const SecureCommsContext = createContext<SecureCommsContextType | undefined>(undefined);

export const SecureCommsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { currentCompany } = useMetadata();
    const { user } = useAuth();
    const [channels, setChannels] = useState<ChatChannel[]>([]);
    const [messages, setMessages] = useState<SecureMessage[]>([]);

    useEffect(() => {
        if (currentCompany) {
            setChannels(mockAllChannels[currentCompany.id] || []);
            setMessages(mockAllSecureMessages[currentCompany.id] || []);
        } else {
            setChannels([]);
            setMessages([]);
        }
    }, [currentCompany]);

    const getMessagesForChannel = useCallback((channelId: string) => {
        return messages
            .filter(msg => msg.channelId === channelId)
            .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    }, [messages]);

    const sendMessage = useCallback((channelId: string, content: string) => {
        if (!user) return;
        const newMessage: SecureMessage = {
            id: `msg-${Date.now()}`,
            channelId,
            authorId: user.id,
            authorName: user.name,
            authorAvatar: '', // Add avatar logic if needed
            timestamp: new Date().toISOString(),
            content,
        };
        setMessages(prev => [...prev, newMessage]);
    }, [user]);
    
    const value = useMemo(() => ({
        channels, messages, getMessagesForChannel, sendMessage
    }), [channels, messages, getMessagesForChannel, sendMessage]);

    return <SecureCommsContext.Provider value={value}>{children}</SecureCommsContext.Provider>;
};

export const useSecureComms = (): SecureCommsContextType => {
    const context = useContext(SecureCommsContext);
    if (!context) {
        throw new Error('useSecureComms must be used within a SecureCommsProvider');
    }
    return context;
};