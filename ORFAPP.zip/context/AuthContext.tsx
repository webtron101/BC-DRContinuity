
import React, { createContext, useState, useContext, ReactNode, useCallback, useMemo } from 'react';
import { User } from '../types';
import { mockUsers } from '../data/mockData';

interface AuthContextType {
    user: User | null;
    login: (username: string, password?: string) => boolean;
    logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(() => {
        try {
            const savedUser = localStorage.getItem('authUser');
            return savedUser ? JSON.parse(savedUser) : null;
        } catch (error) {
            console.error("Failed to parse auth user from localStorage", error);
            return null;
        }
    });

    const login = useCallback((username: string, password?: string): boolean => {
        // This is a mock authentication. In a real app, this would be an API call.
        const foundUser = mockUsers.find(u => u.name.toLowerCase() === username.toLowerCase() && u.password === password);
        if (foundUser) {
            localStorage.setItem('authUser', JSON.stringify(foundUser));
            setUser(foundUser);
            return true;
        }
        return false;
    }, []);

    const logout = useCallback(() => {
        localStorage.removeItem('authUser');
        setUser(null);
    }, []);

    const value = useMemo(() => ({ user, login, logout }), [user, login, logout]);

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = (): AuthContextType => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};