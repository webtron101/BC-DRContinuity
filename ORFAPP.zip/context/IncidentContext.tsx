
import React, { createContext, useState, useContext, ReactNode, useCallback, useMemo } from 'react';
import { Incident, InvocationStep, IncidentEvent } from '../types';
import { useAuth } from './AuthContext';

interface IncidentContextType {
    activeIncident: Incident | null;
    declareIncident: (plan: InvocationStep[]) => void;
    resolveIncident: () => void;
    addLogEntry: (message: string) => void;
    updateStepStatus: (stepId: string, status: InvocationStep['status']) => void;
}

const IncidentContext = createContext<IncidentContextType | undefined>(undefined);

export const IncidentProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { user } = useAuth();
    const [activeIncident, setActiveIncident] = useState<Incident | null>(null);

    const declareIncident = useCallback((plan: InvocationStep[]) => {
        if (!user) return;
        const newIncident: Incident = {
            id: `inc-${Date.now()}`,
            name: `Major Incident - ${new Date().toLocaleString()}`,
            declaredAt: new Date().toISOString(),
            resolvedAt: null,
            status: 'Active',
            plan: plan.map(p => ({...p, status: 'Pending'})), // Reset plan status
            log: [{
                id: `evt-${Date.now()}`,
                timestamp: new Date().toISOString(),
                authorId: user.id,
                authorName: user.name,
                message: "Incident declared."
            }]
        };
        setActiveIncident(newIncident);
    }, [user]);

    const resolveIncident = useCallback(() => {
        if (!user) return;
        setActiveIncident(prev => {
            if (!prev) return null;
            const logEntry: IncidentEvent = {
                id: `evt-${Date.now()}`,
                timestamp: new Date().toISOString(),
                authorId: user.id,
                authorName: user.name,
                message: "Incident resolved."
            };
            return {
                ...prev,
                status: 'Resolved',
                resolvedAt: new Date().toISOString(),
                log: [...prev.log, logEntry],
            };
        });
    }, [user]);

    const addLogEntry = useCallback((message: string) => {
        if (!user || !activeIncident) return;
        const newEntry: IncidentEvent = {
            id: `evt-${Date.now()}`,
            timestamp: new Date().toISOString(),
            authorId: user.id,
            authorName: user.name,
            message,
        };
        setActiveIncident(prev => prev ? { ...prev, log: [...prev.log, newEntry] } : null);
    }, [user, activeIncident]);

    const updateStepStatus = useCallback((stepId: string, status: InvocationStep['status']) => {
        setActiveIncident(prev => {
            if (!prev) return null;
            return {
                ...prev,
                plan: prev.plan.map(step => 
                    step.id === stepId ? { ...step, status } : step
                )
            };
        });
    }, []);

    const value = useMemo(() => ({
        activeIncident,
        declareIncident,
        resolveIncident,
        addLogEntry,
        updateStepStatus,
    }), [activeIncident, declareIncident, resolveIncident, addLogEntry, updateStepStatus]);

    return (
        <IncidentContext.Provider value={value}>
            {children}
        </IncidentContext.Provider>
    );
};

export const useIncident = (): IncidentContextType => {
    const context = useContext(IncidentContext);
    if (!context) {
        throw new Error('useIncident must be used within an IncidentProvider');
    }
    return context;
};
