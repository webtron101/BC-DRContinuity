
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { Rehearsal, Scenario } from '../types';
import { useMetadata } from './MetadataContext';
import { mockAllRehearsals, mockAllScenarios } from '../data/mockData';

interface RehearsalsContextType {
    rehearsals: Rehearsal[];
    scenarios: Scenario[];
    addRehearsal: (rehearsal: Omit<Rehearsal, 'id' | 'status'>) => void;
    updateRehearsal: (rehearsalId: string, updates: Partial<Rehearsal>) => void;
}

const RehearsalsContext = createContext<RehearsalsContextType | undefined>(undefined);

export const RehearsalsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { currentCompany } = useMetadata();
    const [rehearsals, setRehearsals] = useState<Rehearsal[]>([]);
    const [scenarios, setScenarios] = useState<Scenario[]>([]);

    useEffect(() => {
        if (currentCompany) {
            setRehearsals(mockAllRehearsals[currentCompany.id] || []);
            setScenarios(mockAllScenarios[currentCompany.id] || []);
        } else {
            setRehearsals([]);
            setScenarios([]);
        }
    }, [currentCompany]);

    const addRehearsal = useCallback((rehearsal: Omit<Rehearsal, 'id' | 'status'>) => {
        const newRehearsal = { ...rehearsal, id: `rh-${Date.now()}`, status: 'Planned' as 'Planned'};
        setRehearsals(prev => [newRehearsal, ...prev])
    }, []);
    const updateRehearsal = useCallback((rehearsalId: string, updates: Partial<Rehearsal>) => {
        setRehearsals(prev => prev.map(r => r.id === rehearsalId ? { ...r, ...updates } : r));
    }, []);
    
    const value = useMemo(() => ({ rehearsals, scenarios, addRehearsal, updateRehearsal }), [rehearsals, scenarios, addRehearsal, updateRehearsal]);

    return <RehearsalsContext.Provider value={value}>{children}</RehearsalsContext.Provider>;
};

export const useRehearsals = (): RehearsalsContextType => {
    const context = useContext(RehearsalsContext);
    if (!context) {
        throw new Error('useRehearsals must be used within a RehearsalsProvider');
    }
    return context;
};
