
import React, { createContext, useState, useContext, ReactNode, useEffect, useMemo, useCallback } from 'react';
import { BCMRole, BCMStrategy, GovernanceControl, PCIDSSRequirement, BlockedThreat, NotifyUser } from '../types';
import { useMetadata } from './MetadataContext';
import { mockAllBCMRoles, mockAllBCMStrategies, mockAllGovControls, mockAllPciReqs, mockAllBlockedThreats } from '../data/mockData';

interface GovernanceContextType {
    bcmRoles: BCMRole[];
    bcmStrategies: BCMStrategy[];
    governanceControls: GovernanceControl[];
    pciDssRequirements: PCIDSSRequirement[];
    blockedThreats: BlockedThreat[];
    notifyUsers: NotifyUser[];
    addBCMRole: (role: BCMRole) => void;
    updateBCMRole: (roleId: string, updates: Partial<BCMRole>) => void;
    deleteBCMRole: (roleId: string) => void;
    addBCMStrategy: (strategy: BCMStrategy) => void;
}

const GovernanceContext = createContext<GovernanceContextType | undefined>(undefined);

export const GovernanceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { currentCompany } = useMetadata();
    const [bcmRoles, setBcmRoles] = useState<BCMRole[]>([]);
    const [bcmStrategies, setBcmStrategies] = useState<BCMStrategy[]>([]);
    const [governanceControls, setGovernanceControls] = useState<GovernanceControl[]>([]);
    const [pciDssRequirements, setPciDssRequirements] = useState<PCIDSSRequirement[]>([]);
    const [blockedThreats, setBlockedThreats] = useState<BlockedThreat[]>([]);
    
    // notifyUsers is still needed here for role assignments, so we get it from the main context.
    const notifyUsers = currentCompany?.notifyUsers || [];

    useEffect(() => {
        if (currentCompany) {
            setBcmRoles(mockAllBCMRoles[currentCompany.id] || []);
            setBcmStrategies(mockAllBCMStrategies[currentCompany.id] || []);
            setGovernanceControls(mockAllGovControls[currentCompany.id] || []);
            setPciDssRequirements(mockAllPciReqs[currentCompany.id] || []);
            setBlockedThreats(mockAllBlockedThreats[currentCompany.id] || []);
        } else {
            setBcmRoles([]); setBcmStrategies([]); setGovernanceControls([]); setPciDssRequirements([]); setBlockedThreats([]);
        }
    }, [currentCompany]);

    const addBCMRole = useCallback((role: BCMRole) => setBcmRoles(prev => [...prev, role]), []);
    const updateBCMRole = useCallback((roleId: string, updates: Partial<BCMRole>) => {
        setBcmRoles(prev => prev.map(r => r.id === roleId ? { ...r, ...updates } : r));
    }, []);
    const deleteBCMRole = useCallback((roleId: string) => {
        setBcmRoles(prev => prev.filter(r => r.id !== roleId));
    }, []);
    const addBCMStrategy = useCallback((strategy: BCMStrategy) => setBcmStrategies(prev => [...prev, strategy]), []);
    
    const value = useMemo(() => ({
        bcmRoles, bcmStrategies, governanceControls, pciDssRequirements, blockedThreats, notifyUsers,
        addBCMRole, updateBCMRole, deleteBCMRole, addBCMStrategy
    }), [bcmRoles, bcmStrategies, governanceControls, pciDssRequirements, blockedThreats, notifyUsers, addBCMRole, updateBCMRole, deleteBCMRole, addBCMStrategy]);

    return <GovernanceContext.Provider value={value}>{children}</GovernanceContext.Provider>;
};

export const useGovernance = (): GovernanceContextType => {
    const context = useContext(GovernanceContext);
    if (!context) {
        throw new Error('useGovernance must be used within a GovernanceProvider');
    }
    return context;
};
