

import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { CompanyProfile, CompanyMetadata, Integration, ResiliencePhase, IntegrationName, IntegrationStatus } from '../types';
import { useAuth } from './AuthContext';
import { mockCompanies } from '../data/mockData';

interface MetadataContextType {
    companies: CompanyProfile[];
    currentCompany: CompanyProfile | null;
    switchCompany: (companyId: string) => void;
    updateCurrentCompany: (data: Partial<CompanyMetadata>, markWizardAsComplete?: boolean) => void;
    addCompany: (newCompany: CompanyProfile) => void;
    updateIntegration: (integrationId: IntegrationName, updates: Partial<Integration>) => void;
    updateResilienceFramework: (framework: ResiliencePhase[]) => void;
}

const MetadataContext = createContext<MetadataContextType | undefined>(undefined);

export const MetadataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { user } = useAuth();
    const [companies, setCompanies] = useState<CompanyProfile[]>(mockCompanies);
    const [currentCompanyId, setCurrentCompanyId] = useState<string | null>(null);

    useEffect(() => {
        if (user) {
            // Find first company this user might belong to (mock logic)
            // In a real app, the user object would contain their company ID.
            const userIsSuperAdmin = user.role === 'Super Admin';
            const firstCompanyId = mockCompanies[0]?.id;
            setCurrentCompanyId(userIsSuperAdmin ? firstCompanyId : mockCompanies[0]?.id);
        }
    }, [user]);

    const currentCompany = useMemo(() => companies.find(c => c.id === currentCompanyId) || null, [companies, currentCompanyId]);

    const switchCompany = useCallback((companyId: string) => {
        setCurrentCompanyId(companyId);
    }, []);

    const updateCurrentCompany = useCallback((data: Partial<CompanyMetadata>, markWizardAsComplete: boolean = false) => {
        setCompanies(prev =>
            prev.map(company => {
                if (company.id === currentCompanyId) {
                    const updatedCompany = { ...company, ...data };
                    if (markWizardAsComplete) {
                        updatedCompany.isWizardCompleted = true;
                    }
                    return updatedCompany;
                }
                return company;
            })
        );
    }, [currentCompanyId]);

    const addCompany = useCallback((newCompany: CompanyProfile) => {
        setCompanies(prev => [...prev, newCompany]);
        setCurrentCompanyId(newCompany.id);
    }, []);
    
    const updateIntegration = useCallback((integrationId: IntegrationName, updates: Partial<Integration>) => {
         setCompanies(prev =>
            prev.map(company => {
                if (company.id === currentCompanyId) {
                    const updatedIntegrations = (company.integrations || []).map(item => 
                        item.id === integrationId ? { ...item, ...updates } : item
                    );
                    return { ...company, integrations: updatedIntegrations };
                }
                return company;
            })
        );
    }, [currentCompanyId]);
    
    const updateResilienceFramework = useCallback((framework: ResiliencePhase[]) => {
        setCompanies(prev =>
            prev.map(company => {
                if (company.id === currentCompanyId) {
                    return { ...company, resilienceFramework: framework };
                }
                return company;
            })
        );
    }, [currentCompanyId]);


    const value = useMemo(() => ({ 
        companies, 
        currentCompany, 
        switchCompany, 
        updateCurrentCompany, 
        addCompany,
        updateIntegration,
        updateResilienceFramework
    }), [companies, currentCompany, switchCompany, updateCurrentCompany, addCompany, updateIntegration, updateResilienceFramework]);

    return (
        <MetadataContext.Provider value={value}>
            {children}
        </MetadataContext.Provider>
    );
};

export const useMetadata = (): MetadataContextType => {
    const context = useContext(MetadataContext);
    if (!context) {
        throw new Error('useMetadata must be used within a MetadataProvider');
    }
    return context;
};
