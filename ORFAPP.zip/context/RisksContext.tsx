

import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { Risk, RiskTreatmentAction } from '../types';
import { useMetadata } from './MetadataContext';
import { mockAllRisks } from '../data/mockData';

interface RisksContextType {
    risks: Risk[];
    addRisk: (risk: Omit<Risk, 'id'>) => void;
    updateRisk: (riskId: string, updates: Partial<Risk>) => void;
    addTreatmentAction: (riskId: string, action: Omit<RiskTreatmentAction, 'id' | 'status'>) => void;
    updateTreatmentActionStatus: (riskId: string, actionId: string, status: RiskTreatmentAction['status']) => void;
}

const RisksContext = createContext<RisksContextType | undefined>(undefined);

export const RisksProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { currentCompany } = useMetadata();
    const [risks, setRisks] = useState<Risk[]>([]);

    useEffect(() => {
        if (currentCompany) {
            // In a real app, this would be an API call.
            setRisks(mockAllRisks[currentCompany.id] || []);
        } else {
            setRisks([]);
        }
    }, [currentCompany]);

    const addRisk = useCallback((riskData: Omit<Risk, 'id'>) => {
        const newRisk = { ...riskData, id: `r${Date.now()}`};
        setRisks(prev => [newRisk, ...prev]);
    }, []);

    const updateRisk = useCallback((riskId: string, updates: Partial<Risk>) => {
        setRisks(prev => prev.map(r => r.id === riskId ? {...r, ...updates} : r));
    }, []);

    const addTreatmentAction = useCallback((riskId: string, actionData: Omit<RiskTreatmentAction, 'id' | 'status'>) => {
        const newAction: RiskTreatmentAction = {
            ...actionData,
            id: `act-${Date.now()}`,
            status: 'To Do',
        };
        setRisks(prev => prev.map(r => {
            if (r.id === riskId) {
                return { ...r, treatmentPlan: [...r.treatmentPlan, newAction] };
            }
            return r;
        }));
    }, []);

    const updateTreatmentActionStatus = useCallback((riskId: string, actionId: string, status: RiskTreatmentAction['status']) => {
        setRisks(prev => prev.map(r => {
            if (r.id === riskId) {
                return {
                    ...r,
                    treatmentPlan: r.treatmentPlan.map(act => 
                        act.id === actionId ? { ...act, status } : act
                    )
                };
            }
            return r;
        }));
    }, []);

    const value = useMemo(() => ({ risks, addRisk, updateRisk, addTreatmentAction, updateTreatmentActionStatus }), [risks, addRisk, updateRisk, addTreatmentAction, updateTreatmentActionStatus]);

    return (
        <RisksContext.Provider value={value}>
            {children}
        </RisksContext.Provider>
    );
};

export const useRisks = (): RisksContextType => {
    const context = useContext(RisksContext);
    if (!context) {
        throw new Error('useRisks must be used within a RisksProvider');
    }
    return context;
};
