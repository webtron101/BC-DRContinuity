

import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { BusinessUnit, Process, Service } from '../types';
import { useMetadata } from './MetadataContext';
import { mockAllBusinessUnits, mockAllProcesses, mockAllServices } from '../data/mockData';

interface BIAContextType {
    businessUnits: BusinessUnit[];
    processes: Process[];
    services: Service[];
    addBusinessUnit: (unitData: Omit<BusinessUnit, 'id'>) => void;
    addProcess: (processData: Omit<Process, 'id'>) => void;
    updateProcess: (processId: string, updates: Partial<Process>) => void;
    addService: (service: Service) => void;
    updateService: (serviceId: string, updates: Partial<Service>) => void;
}

const BIAContext = createContext<BIAContextType | undefined>(undefined);

export const BIAProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { currentCompany } = useMetadata();
    const [businessUnits, setBusinessUnits] = useState<BusinessUnit[]>([]);
    const [processes, setProcesses] = useState<Process[]>([]);
    const [services, setServices] = useState<Service[]>([]);

    useEffect(() => {
        if (currentCompany) {
            setBusinessUnits(mockAllBusinessUnits[currentCompany.id] || []);
            setProcesses(mockAllProcesses[currentCompany.id] || []);
            setServices(mockAllServices[currentCompany.id] || []);
        } else {
            setBusinessUnits([]);
            setProcesses([]);
            setServices([]);
        }
    }, [currentCompany]);

    const addBusinessUnit = useCallback((unitData: Omit<BusinessUnit, 'id'>) => {
        const newUnit: BusinessUnit = { ...unitData, id: `bu-${Date.now()}`};
        setBusinessUnits(prev => [...prev, newUnit]);
    }, []);
    
    const addProcess = useCallback((processData: Omit<Process, 'id'>) => {
        const newProcess: Process = { ...processData, id: `p-${Date.now()}`};
        setProcesses(prev => [...prev, newProcess]);
    }, []);

    const updateProcess = useCallback((processId: string, updates: Partial<Process>) => {
        setProcesses(prev => prev.map(p => p.id === processId ? { ...p, ...updates } : p));
    }, []);

    const addService = useCallback((service: Service) => setServices(prev => [...prev, service]), []);
    const updateService = useCallback((serviceId: string, updates: Partial<Service>) => {
        setServices(prev => prev.map(s => s.id === serviceId ? { ...s, ...updates } : s));
    }, []);

    const value = useMemo(() => ({
        businessUnits, processes, services,
        addBusinessUnit, addProcess, updateProcess, addService, updateService,
    }), [businessUnits, processes, services, addBusinessUnit, addProcess, updateProcess, addService, updateService]);

    return <BIAContext.Provider value={value}>{children}</BIAContext.Provider>;
};

export const useBIA = (): BIAContextType => {
    const context = useContext(BIAContext);
    if (!context) {
        throw new Error('useBIA must be used within a BIAProvider');
    }
    return context;
};
