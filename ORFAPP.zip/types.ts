


export type UserRole = 'Super Admin' | 'Company Admin' | 'User';

export interface User {
  id: string;
  name: string;
  password?: string; // NOTE: Passwords should be handled securely on a real backend.
  role: UserRole;
}

export interface NavItem {
  name:string;
  path: string;
  icon: (props: React.SVGProps<SVGSVGElement>) => React.ReactNode;
  premium?: boolean;
}

export interface NavGroup {
  name: string;
  items: NavItem[];
}

export enum RiskLevel {
  Low,
  Medium,
  High,
  Critical,
}

export interface RiskTreatmentAction {
  id:string;
  description: string;
  assigneeId: string;
  dueDate: string;
  status: 'To Do' | 'In Progress' | 'Completed';
}

export interface Risk {
  id:string;
  title: string;
  category: 'Operational' | 'Financial' | 'Technical' | 'Strategic' | 'Reputational';
  impact: number; // 1-5
  likelihood: number; // 1-5
  level: RiskLevel;
  riskScore: number;
  trend: 'up' | 'down' | 'stable';
  treatmentPlan: RiskTreatmentAction[];
  relatedAssetIds: string[];
  linkedControlIds?: string[];
}

export interface Task {
  id: string;
  description: string;
  dueDate: string;
  completed: boolean;
}

export interface AiAlert {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  severity: 'Info' | 'Warning' | 'Critical';
}

export type DocumentType =
  | 'BIA' | 'DRP' | 'Crisis Comms' | 'Policy' | 'Report' | 'BCM Plan'
  | 'Server Profile' | 'Network Design' | 'Visio Diagram' | 'Technical Recovery Plan'
  | 'Generated' // For dynamically created docs
  | 'Best Practice'
  | 'White Paper';

export interface ChangeHistoryEntry {
    version: string;
    date: string;
    editor: string;
    summary: string;
}

export interface Document {
  id: string;
  name: string;
  category: 'BCM' | 'IT' | 'Generated' | 'Resource';
  type: DocumentType;
  version: string;
  status: 'Draft' | 'In Review' | 'Approved' | 'Archived';
  lastUpdated: string;
  owner: string;
  changeHistory: ChangeHistoryEntry[];
  content?: string; // For generated documents
  approvals?: {
      userId: string;
      userName: string;
      timestamp: string;
  }[];
}

export enum MessageAuthor {
    USER = 'user',
    ASSISTANT = 'assistant'
}

export interface GroundingChunk {
    web?: {
        uri: string;
        title: string;
    };
}

export interface ChatMessage {
    author: MessageAuthor;
    content: string;
    groundingChunks?: GroundingChunk[];
}

export type RehearsalType =
    | 'Unit Test'
    | 'Network Test'
    | 'Application Test'
    | 'Failover Test'
    | 'Systems Integration Test'
    | 'BCM Tabletop Test'
    | 'Fully Integrated Test'
    | 'Full BCM Test'
    | 'Data Restore Test'
    | 'Technical Recovery Test'
    | 'Walkthrough' // Generic fallback
    | 'Simulation'; // Generic fallback

export interface Scenario {
    id: string;
    title: string;
    description: string;
}
    
export interface Rehearsal {
    id: string;
    name: string;
    type: RehearsalType;
    status: 'Planned' | 'In Progress' | 'Completed' | 'Cancelled';
    objectives: string;
    startDate: string;
    endDate: string;
    completionDate?: string;
    reportId?: string; // link to a document ID
    participants: string[];
    resultsSummary?: string;
    evidence?: {
        name: string;
        url: string;
    }[];
    scenarioId?: string;
}

export interface Site {
  id: string;
  name: string;
  location: string;
  type: 'Headquarters' | 'Data Center' | 'Branch Office' | 'Cloud Region';
  criticality: RiskLevel;
}

export type RTOPeriod = 
    | 'N/A' 
    | '< 1 Hour' 
    | '1-4 Hours' 
    | '4-8 Hours' 
    | '8-12 Hours' 
    | '12-24 Hours' 
    | '1-2 Days' 
    | '3-4 Days' 
    | '5-7 Days' 
    | '> 1 Week';

export type RPOPeriod = 
    | 'N/A' 
    | 'Zero / Synchronous' 
    | '< 15 minutes' 
    | '15 - 60 minutes'
    | '1 - 4 hours'
    | '4 - 12 hours' 
    | '12 - 24 hours';

export type ResilienceStatus = 'Not Resilient' | 'In Progress' | 'Resilient';

export interface ServerProfile {
    os: string;
    cpu: string;
    ram: string;
    storage: string;
    roles: string[];
    paths: string[];
}
export interface ITAsset {
  id: string;
  name: string;
  type: 'Server (Virtual)' | 'Server (Physical)' | 'Database' | 'Network Switch' | 'Firewall' | 'Storage Array' | 'Application';
  siteId: string;
  riskRating: RiskLevel;
  dependencies: string[]; // array of ITAsset ids
  description: string;
  owner: string;
  status?: 'Online' | 'Offline' | 'Degraded';
  rto?: RTOPeriod;
  rpo?: RPOPeriod;
  recoveryProcedureDocId?: string;
  vulnerabilities: {
      cve: string;
      severity: 'Critical' | 'High' | 'Medium' | 'Low';
      description: string;
  }[];
  resilienceStatus: ResilienceStatus;
  lastRehearsal?: string; // Date
  serverProfile?: ServerProfile;
}

export interface Network {
  id: string;
  name: string;
  type: 'LAN' | 'WAN' | 'VPN';
  subnet: string;
  siteId: string;
}

export interface SLA {
    uptimePercentage: number;
    responseTimeHours: number;
}
export interface Breach {
    id: string;
    date: string;
    description: string;
}

export interface Service { // Internal Service
  id: string;
  name: string;
  description: string;
  owner: string; // department or person
  rto: RTOPeriod; // Recovery Time Objective
  rpo: RPOPeriod; // Recovery Point Objective
  supportingAssets: string[]; // array of ITAsset ids
  criticality: RiskLevel;
  ola: SLA;
  breaches: Breach[];
  strategyIds?: string[];
}

export interface SuppliedService { // External Service
    id: string;
    vendorId: string;
    name: string;
    description: string;
    criticality: RiskLevel;
    sla: SLA;
    breaches: Breach[];
}

export interface BusinessUnit {
    id: string;
    name: string;
    cluster?: string;
    description?: string;
    functionalOwner?: string;
    reportsTo?: string;
    location?: string;
    headcount?: number;
    supportHeadcount?: number;
}

export interface VitalRecord {
    id: string;
    name: string;
    location: string;
    description?: string;
}

export interface ProcessDependency {
    type: 'internal' | 'external';
    serviceId: string;
}

export interface Process {
    id: string;
    name: string;
    description: string;
    unitId: string;
    rto: RTOPeriod;
    rpo: RPOPeriod;
    criticality: RiskLevel;
    dependencies: ProcessDependency[];
    linkedSystemIds: string[];
    vitalRecords: VitalRecord[];
    manualDependencies: string;
    strategyIds?: string[];
    mtpd?: RTOPeriod; // Maximum Tolerable Period of Disruption
}

export interface ComplianceItem {
    id: string;
    name: string;
    requirement: string;
    status: 'Completed' | 'In Progress' | 'Missing';
    progress: number; // 0-100
    linkedDocId?: string;
    auditHistory: {
        date: string;
        reviewer: string;
        notes: string;
    }[];
}

export interface NotifyUser {
    id: string;
    name: string;
    role: string;
    email: string;
    phone: string;
}

export interface NotificationTemplate {
    id: string;
    name: string;
    subject: string;
    body: string;
}

export interface KeyContact {
    id: string;
    name: string;
    role: string;
    email: string;
}

export interface CompanySite {
    id: string;
    name: string;
    location: string;
}

export type AssignmentStatus = 'To Do' | 'In Progress' | 'Completed';

export interface Assignment {
    id:string;
    task: string;
    assigneeId: string;
    status: AssignmentStatus;
    dueDate: string;
    riskLevel: RiskLevel;
    progress: number; // 0-100
    relatedItem: {
        type: 'Document' | 'Rehearsal' | 'Risk' | 'Process';
        id: string;
        name: string;
    };
}

export type ResiliencePhaseStatus = 'Mature' | 'In Progress' | 'Not Started';

export interface ResiliencePhase {
    id: string;
    name: string;
    description: string;
    status: ResiliencePhaseStatus;
    progress: number;
    resources: {
        name: string;
        type: 'Document' | 'Link' | 'Course';
        url: string;
    }[];
}

export interface DocumentTemplate {
    id: string;
    name: string;
    description: string;
    content: string; // Markdown/text content with placeholders
}

export interface SoAControl {
    id: string;
    controlRef: string;
    description: string;
    applicable: boolean;
    justification: string;
}

export interface HistoricalGeoRisk {
    date: string;
    siteId: string;
    electricity: number;
    vandalism: number;
}

export interface BattleboxItem {
    id: string;
    name: string;
    type: 'Software' | 'Document' | 'Credential' | 'Service';
    description: string;
    location: string; // URL or secure reference
    criticality: RiskLevel;
    lastVerified: string;
}

export interface BCMRole {
    id: string;
    name: string; // e.g., Crisis Manager
    assigneeId: string; // link to NotifyUser ID
    deputyId?: string; // link to NotifyUser ID
    responsibilities: string[];
    hasInvocationAuthority: boolean;
}

export interface BCMStrategy {
    id: string;
    name: string;
    description: string;
    type: 'Redundancy' | 'Alternate Site' | 'Manual Workaround' | 'Cloud Failover' | 'Third-Party Agreement';
}

export interface ThirdPartyAssessmentQuestion {
    id: string;
    text: string;
    category: 'Security' | 'Compliance' | 'Resilience' | 'Reputation';
}
export interface ThirdPartyAssessmentAnswer {
    questionId: string;
    answer: 'Yes' | 'No' | 'Partial' | 'N/A';
    comment: string;
}
export interface VendorCertificate {
    id: string;
    name: 'ISO 27001' | 'SOC 2 Type II' | 'PCI DSS' | 'Other';
    fileUrl: string; // Mock URL
    expiryDate: string;
}
export interface Vendor {
    id: string;
    name: string;
    contactPerson: string;
    contactEmail: string;
    contactPhone: string;
    tier: '1' | '2' | '3';
    riskScore: number; // 0-100
    assessments: ThirdPartyAssessmentAnswer[];
    certificates: VendorCertificate[];
    accessKey?: string;
}

export type IntegrationStatus = 'Active' | 'Inactive' | 'Error';
export type IntegrationName = 'Twilio' | 'Trello' | 'ServiceNow' | 'Everbridge' | 'Slack' | 'SCCM';

export interface Integration {
    id: IntegrationName;
    status: IntegrationStatus;
    credentials: Record<string, string>;
}

export interface CompanyProfile {
    id: string;
    name: string;
    address: string;
    isWizardCompleted: boolean;
    logoUrl?: string;
    keyContacts: KeyContact[];
    sites: CompanySite[];
    financialRiskZAR: number;
    tasks: Task[];
    aiAlerts: AiAlert[];
    // All major data arrays are now managed in their own contexts
    // for performance and separation of concerns.
    notifyUsers: NotifyUser[];
    invocationPlan: InvocationStep[];
    siteRiskBreakdown: Record<string, SiteRiskDetail>;
    historicalGeoRisk: HistoricalGeoRisk[];
    integrations: Integration[];
    resilienceFramework: ResiliencePhase[]; // This one is a summary object, not raw data
}

export type CompanyMetadata = Pick<CompanyProfile, 'name' | 'address' | 'logoUrl' | 'keyContacts' | 'sites'>;

export interface InvocationStep {
    id: string;
    step: number;
    action: string;
    description: string;
    assigneeRole: string;
    status: 'Pending' | 'In Progress' | 'Completed' | 'Skipped';
    decision?: string;
}

export interface IncidentEvent {
  id: string;
  timestamp: string;
  authorId: string;
  authorName: string;
  message: string;
}

export interface Incident {
  id: string;
  name: string;
  declaredAt: string;
  resolvedAt: string | null;
  status: 'Active' | 'Monitoring' | 'Resolved';
  log: IncidentEvent[];
  plan: InvocationStep[];
}


export interface SiteRiskDetail {
    electricity: { score: number, trend: 'up' | 'down' | 'stable' };
    vandalism: { score: number, trend: 'up' | 'down' | 'stable' };
}

export type ControlStatus = 'Compliant' | 'Non-compliant' | 'At Risk' | 'Not Audited';

export interface GovernanceControl {
    id: string;
    controlReference: string;
    description: string;
    domain: 'Align, Plan and Organize' | 'Build, Acquire and Implement' | 'Deliver, Service and Support' | 'Monitor, Evaluate and Assess';
    status: ControlStatus;
    owner: string;
    lastAudit: string;
}

export interface PCIDSSRequirement {
    id: string;
    goal: number;
    requirement: string;
    description: string;
    status: 'Not Started' | 'In Progress' | 'Completed';
    progress: number;
}

export interface BlockedThreat {
    id: string;
    timestamp: string;
    type: 'Malware' | 'Ransomware' | 'Phishing' | 'DDoS';
    name: string;
    sourceIp: string;
    action: 'Blocked' | 'Allowed';
}

// ### SECURE COMMS ###
export interface SecureMessage {
    id: string;
    channelId: string;
    authorId: string;
    authorName: string;
    authorAvatar: string;
    timestamp: string;
    content: string;
}

export interface ChatChannel {
    id: string;
    name: string;
    description: string;
    memberIds: string[];
    isEncrypted: boolean;
}

// ### SERVICE DEFINITION ###
export interface ServiceFeature {
  name: string;
  benefit: string;
  tier: 'Standard' | 'Premium';
}

export interface ServiceModule {
  name: string;
  description: string;
  features: ServiceFeature[];
  relatedStandard: string;
}

// ### RESOURCES ###
export interface GlossaryTerm {
    term: string;
    definition: string;
    category: 'General' | 'Analysis' | 'Design' | 'Recovery';
}