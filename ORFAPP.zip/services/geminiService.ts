



import { GoogleGenAI, GenerateContentResponse, Content } from "@google/genai";
import { ChatMessage, MessageAuthor } from '../types';

const BCM_SYSTEM_INSTRUCTION = `You are "Atlas Copilot," an expert AI assistant for Business Continuity Management (BCM) and organizational resilience, based on ISO 22301 and BCI Good Practice Guidelines. Your role is to help users build, manage, and improve their resilience posture.

Your capabilities include:
1.  **Plan Generation:** Create drafts for BIA, DRP, and Crisis Communication plans based on user prompts. Ask clarifying questions to ensure the output is specific and useful.
2.  **Plan Summarization:** Briefly summarize long policy or plan documents.
3.  **Gap Detection:** Analyze user-provided information to identify potential gaps or conflicts in their BCM program (e.g., RTO/RPO mismatches, compliance issues, overdue tasks).
4.  **Guidance & Best Practices:** Provide expert advice on BCM topics.
5.  **Exercise Scenarios:** Generate realistic scenarios for BCP/DR tests.
6.  **Post-Mortem Generation:** Based on test results, generate a post-mortem report with findings and recommendations.

When responding:
- Be clear, concise, and professional.
- Use industry-standard terminology (RTO, RPO, BIA, DRP).
- When generating plans or documents, use markdown for formatting (headings, lists, bold text).
- Start your first response with a friendly greeting and introduce yourself.`;

class GeminiService {
  private ai: GoogleGenAI;

  constructor(apiKey: string | undefined) {
    if (!apiKey) {
      throw new Error("API key is missing. Please set the API_KEY environment variable.");
    }
    this.ai = new GoogleGenAI({ apiKey });
  }

  public async sendMessageStream(
    message: string,
    history: ChatMessage[]
  ): Promise<AsyncGenerator<GenerateContentResponse>> {
    
    const contents: Content[] = history.map(msg => ({
        role: msg.author === MessageAuthor.USER ? 'user' : 'model',
        parts: [{ text: msg.content }]
    }));
    contents.push({ role: 'user', parts: [{ text: message }] });

    const config = {
        systemInstruction: BCM_SYSTEM_INSTRUCTION,
    };

    const result = await this.ai.models.generateContentStream({
        model: 'gemini-2.5-flash-preview-04-17',
        contents,
        config,
    });
    
    return result;
  }
}

// The API key MUST be provided as an environment variable
export const geminiService = new GeminiService(process.env.API_KEY);