


import React from 'react';
import { CompanyProfile, User, RiskLevel, DocumentTemplate, SoAControl, NotificationTemplate, BattleboxItem, BCMRole, BCMStrategy, Vendor, SuppliedService, Integration, Rehearsal, ComplianceItem, Assignment, Risk, Document, ITAsset, Network, Service, BusinessUnit, Process, GovernanceControl, PCIDSSRequirement, BlockedThreat, Scenario, ThirdPartyAssessmentQuestion, ChatChannel, SecureMessage, ServiceModule, GlossaryTerm, IntegrationName } from '../types';
import { TrelloIcon } from '../components/icons/TrelloIcon';
import { ServiceNowIcon } from '../components/icons/ServiceNowIcon';
import { SlackIcon } from '../components/icons/SlackIcon';
import { TwilioIcon } from '../components/icons/TwilioIcon';
import { EverbridgeIcon } from '../components/icons/EverbridgeIcon';
import { SCCMIcon } from '../components/icons/SCCMIcon';

export const mockUsers: User[] = [
    { id: 'u1', name: 'superadmin', password: 'password', role: 'Super Admin' },
    { id: 'u2', name: 'companyadmin', password: 'password', role: 'Company Admin' },
    { id: 'u3', name: 'user', password: 'password', role: 'User' },
];

const mockDocumentTemplates: DocumentTemplate[] = [
    {
        id: 'TPL_SOA',
        name: 'Statement of Applicability (ISO 22301)',
        description: 'Declare which ISO 22301 controls are applicable and justify exclusions.',
        content: '## Statement of Applicability (SoA)\n\n**Company:** {companyName}\n**Date:** {currentDate}\n**Approved by:** {approverName}\n\nThis document declares the applicability of ISO 22301:2019 clauses to the Business Continuity Management System (BCMS) of {companyName}.\n\n{soaTable}\n'
    },
    {
        id: 'TPL_BCM_POLICY',
        name: 'BCM Policy Statement',
        description: 'A high-level policy document that outlines the organization\'s commitment to BCM.',
        content: '# Business Continuity Management Policy\n\n## 1. Introduction\n{companyName} is committed to ensuring the continuity of its critical business operations... The custodian of this policy is {custodianName} ({custodianRole}).\n\n## 2. Scope\nThis policy applies to all departments and personnel at our main site: {primarySiteName}.\n\n## 3. Objectives\n- To implement and maintain a BCMS compliant with ISO 22301.\n- To regularly conduct BIAs and risk assessments.\n- To test and validate continuity plans annually.\n',
    },
];

const mockSoAControls: SoAControl[] = [
    { id: 'soa-4.1', controlRef: '4.1 Understanding the organization', description: 'Determine external and internal issues relevant to its purpose.', applicable: true, justification: 'Fundamental to establishing the BCMS context.' },
    { id: 'soa-5.2', controlRef: '5.2 Policy', description: 'Top management shall establish a business continuity policy.', applicable: true, justification: 'Core governance requirement.' },
    { id: 'soa-8.2.2', controlRef: '8.2.2 Business impact analysis', description: 'Establish, implement and maintain a formal and documented BIA process.', applicable: true, justification: 'Essential for identifying priorities.' },
];

export const mockNotificationTemplates: NotificationTemplate[] = [
    { id: 'tpl_inc_initial', name: 'Initial Incident Alert', subject: 'ALERT: Incident In Progress', body: 'This is an alert from the {companyName} Crisis Management Team. We are currently investigating an incident affecting [SERVICE/SITE]. Further updates will be provided within [TIME].' },
    { id: 'tpl_inc_update', name: 'Incident Update', subject: 'UPDATE: Incident In Progress', body: 'This is an update regarding the ongoing incident. [PROVIDE UPDATE DETAILS]. The current estimated time to resolution is [ETR].' },
];

const c1NotifyUsers = [
    { id: 'user1', name: 'Thabo Ndlovu', role: 'BCM Manager', email: 'thabo.ndlovu@example.co.za', phone: '+27821234567' },
    { id: 'user2', name: 'John Smith', role: 'IT Director', email: 'john.smith@example.co.za', phone: '+27831234568' },
    { id: 'user3', name: 'Lerato Mokoena', role: 'Comms Lead', email: 'lerato.mokoena@example.co.za', phone: '+27841234569' },
    { id: 'user4', name: 'Priya Singh', role: 'CIO', email: 'priya.singh@example.co.za', phone: '+27829876543' },
    { id: 'user5', name: 'David Chen', role: 'Lead Developer', email: 'david.chen@example.co.za', phone: '+27835551234' },
];

// ### ASSIGNMENTS ###
const c1Assignments: Assignment[] = [
    { id: 'as1', task: 'Review and approve new Crisis Comms plan', assigneeId: 'user1', status: 'In Progress', progress: 50, dueDate: '2024-09-01', riskLevel: RiskLevel.Medium, relatedItem: { type: 'Document', id: 'd3', name: 'External Crisis Comms Plan' } },
    { id: 'as2', task: 'Address findings from Ransomware test', assigneeId: 'user2', status: 'To Do', progress: 0, dueDate: '2024-08-30', riskLevel: RiskLevel.High, relatedItem: { type: 'Rehearsal', id: 'rh2', name: 'Ransomware Scenario Walkthrough' } },
];
export const mockAllAssignments: Record<string, Assignment[]> = { 'c1': c1Assignments, 'c2': [] };

// ### RISKS ###
const c1Risks: Risk[] = [
  { id: 'r1', title: 'Loadshedding causing prolonged power outage', category: 'Operational', impact: 5, likelihood: 5, level: RiskLevel.Critical, riskScore: 25, trend: 'up', 
    treatmentPlan: [
      { id: 'rt1-1', description: 'Increase diesel storage capacity to 72 hours', assigneeId: 'user2', dueDate: '2024-10-01', status: 'In Progress' },
      { id: 'rt1-2', description: 'Conduct Solar panel feasibility study for DC', assigneeId: 'user4', dueDate: '2024-11-15', status: 'To Do' }
    ],
    relatedAssetIds: ['asset3'],
    linkedControlIds: [],
  },
  { id: 'r2', title: 'Ransomware Attack on Core Systems', category: 'Technical', impact: 5, likelihood: 4, level: RiskLevel.Critical, riskScore: 20, trend: 'stable',
    treatmentPlan: [
        { id: 'rt2-1', description: 'Conduct quarterly phishing simulation for all staff', assigneeId: 'user1', dueDate: '2024-09-30', status: 'Completed' },
        { id: 'rt2-2', description: 'Verify integrity and recoverability of offline backups', assigneeId: 'user2', dueDate: '2024-09-15', status: 'In Progress' }
    ],
    relatedAssetIds: ['asset1', 'asset4'],
    linkedControlIds: ['DSS04.07'],
  },
];
export const mockAllRisks: Record<string, Risk[]> = { 'c1': c1Risks, 'c2': [] };

// ### DOCUMENTS ###
const c1Documents: Document[] = [
    { id: 'd1', name: 'Corporate Business Impact Analysis (BIA)', category: 'BCM', type: 'BIA', version: '3.1', status: 'Approved', lastUpdated: '2024-07-15', owner: 'Thabo Ndlovu', changeHistory: [{ version: '3.1', date: '2024-07-15', editor: 'Thabo Ndlovu', summary: 'Final approval for Q3.' }] },
    { id: 'd2', name: 'Core Infrastructure DRP', category: 'BCM', type: 'DRP', version: '2.5', status: 'Approved', lastUpdated: '2024-06-28', owner: 'John Smith', changeHistory: [] },
    { id: 'd3', name: 'External Crisis Comms Plan', category: 'BCM', type: 'Crisis Comms', version: '1.8', status: 'In Review', lastUpdated: '2024-08-01', owner: 'Alice Johnson', changeHistory: [] },
    { id: 'trp1', name: 'TRP - DB-SQL-01', category: 'IT', type: 'Technical Recovery Plan', version: '1.0', status: 'Approved', lastUpdated: '2024-07-01', owner: 'DBA Team', changeHistory: [], content: '1.  **Verify Outage:** Confirm the primary database cluster is unresponsive...\n2.  **Initiate Failover:** Execute script...\n3.  **Update DNS:** Point apps to secondary IP...' },
    { id: 'pol1', name: 'Business Continuity Management Policy', category: 'BCM', type: 'Policy', version: '1.0', status: 'Approved', lastUpdated: '2024-01-10', owner: 'CIO', changeHistory: [] },
    { id: 'res1', name: 'BCI Good Practice Guidelines (GPG) 2018 Edition', category: 'Resource', type: 'Best Practice', version: '1.0', status: 'Approved', lastUpdated: '2023-01-01', owner: 'BCI', changeHistory: [] },
    { id: 'res2', name: 'ISO 22317 - BIA Standard', category: 'Resource', type: 'Best Practice', version: '1.0', status: 'Approved', lastUpdated: '2023-01-01', owner: 'ISO', changeHistory: [] },
    { id: 'res3', name: 'White Paper: The Future of Organizational Resilience', category: 'Resource', type: 'White Paper', version: '1.0', status: 'Approved', lastUpdated: '2024-05-20', owner: 'Gartner', changeHistory: [] },
];
const c1ComplianceItems: ComplianceItem[] = [
    { id: 'iso-4.1', name: 'Context of the Organization', requirement: '4.1 Understanding the organization and its context', status: 'Completed', progress: 100, linkedDocId: 'd1', auditHistory: [] },
    { id: 'iso-4.2', name: 'Needs of interested parties', requirement: '4.2 Understanding the needs and expectations of interested parties', status: 'Completed', progress: 100, auditHistory: [] },
    { id: 'iso-5.2', name: 'BCM Policy', requirement: '5.2 Policy', status: 'Completed', progress: 100, linkedDocId: 'pol1', auditHistory: [] },
    { id: 'iso-6.2', name: 'BC objectives and plans', requirement: '6.2 Business continuity objectives and plans to achieve them', status: 'In Progress', progress: 70, auditHistory: [] },
    { id: 'iso-8.2.2', name: 'Business Impact Analysis (BIA)', requirement: '8.2.2 Business impact analysis', status: 'Completed', progress: 100, linkedDocId: 'd1', auditHistory: [] },
    { id: 'iso-8.2.3', name: 'Risk Assessment', requirement: '8.2.3 Risk assessment', status: 'Completed', progress: 100, auditHistory: [] },
    { id: 'iso-8.4.2', name: 'BCP Structure', requirement: '8.4.2 Structure of a business continuity plan', status: 'In Progress', progress: 50, auditHistory: [] },
    { id: 'iso-8.4.4', name: 'Recovery Procedures', requirement: '8.4.4 Recovery', status: 'Completed', progress: 100, linkedDocId: 'd2', auditHistory: [] },
    { id: 'iso-8.5', name: 'Exercise Programme', requirement: '8.5 Exercise programme', status: 'In Progress', progress: 40, auditHistory: [] },
];
export const mockAllDocuments: Record<string, Document[]> = { 'c1': c1Documents, 'c2': [] };
export const mockAllComplianceItems: Record<string, ComplianceItem[]> = { 'c1': c1ComplianceItems, 'c2': c1ComplianceItems.map(c => ({...c, status: 'Missing', progress: 0})) };
export const mockAllDocumentTemplates: Record<string, DocumentTemplate[]> = { 'c1': mockDocumentTemplates, 'c2': mockDocumentTemplates };
export const mockAllNotificationTemplates: Record<string, NotificationTemplate[]> = { 'c1': mockNotificationTemplates, 'c2': mockNotificationTemplates.map(t => ({...t})) };
export const mockAllSoAControls: Record<string, SoAControl[]> = { 'c1': mockSoAControls, 'c2': mockSoAControls };

// ### IT & BATTLEBOX ###
const c1ITAssets: ITAsset[] = [
    { id: 'asset1', name: 'DB-SQL-01', type: 'Database', siteId: 's1-site2', riskRating: RiskLevel.Critical, dependencies: ['asset5'], description: 'Primary customer database cluster', owner: 'DBA Team', rto: '1-4 Hours', rpo: '< 15 minutes', recoveryProcedureDocId: 'trp1', status: 'Online', vulnerabilities: [{cve: 'CVE-2023-3456', severity: 'High', description: 'SQL Injection Vulnerability'}], resilienceStatus: 'Resilient', lastRehearsal: '2024-03-20', serverProfile: { os: 'Windows Server 2022', cpu: '8 vCPU', ram: '64 GB', storage: '1 TB SSD', roles: ['SQL Server', 'Failover Clustering'], paths: ['D:\\Data', 'E:\\Logs'] } },
    { id: 'asset2', name: 'APP-CRM-01', type: 'Application', siteId: 's1-site4', riskRating: RiskLevel.High, dependencies: ['asset1', 'asset4'], description: 'Salesforce CRM Application', owner: 'Business Apps Team', rto: '4-8 Hours', rpo: '< 15 minutes', status: 'Online', vulnerabilities: [], resilienceStatus: 'Resilient', lastRehearsal: '2024-03-20' },
    { id: 'asset3', name: 'FW-JHB-01', type: 'Firewall', siteId: 's1-site2', riskRating: RiskLevel.High, dependencies: [], description: 'Perimeter firewall for Midrand DC', owner: 'Network Team', rto: '< 1 Hour', rpo: 'N/A', status: 'Offline', vulnerabilities: [{cve: 'CVE-2024-1234', severity: 'Critical', description: 'Remote Code Execution possible.'}], resilienceStatus: 'Not Resilient' },
    { id: 'asset4', name: 'VS-AD-01', type: 'Server (Virtual)', siteId: 's1-site2', riskRating: RiskLevel.Critical, dependencies: [], description: 'Active Directory Domain Controller', owner: 'Infrastructure Team', rto: '< 1 Hour', rpo: '< 15 minutes', status: 'Online', vulnerabilities: [], resilienceStatus: 'Resilient', lastRehearsal: '2024-03-20' },
    { id: 'asset5', name: 'SA-CUST-DATA-01', type: 'Storage Array', siteId: 's1-site2', riskRating: RiskLevel.Critical, dependencies: [], description: 'Storage for customer databases', owner: 'Storage Team', rto: '1-4 Hours', rpo: '< 15 minutes', status: 'Online', vulnerabilities: [], resilienceStatus: 'Resilient' },
];
const c1Networks: Network[] = [ { id: 'net1', name: 'Midrand DC Server VLAN', type: 'LAN', subnet: '10.2.10.0/24', siteId: 's1-site2' } ];
const c1BattleboxItems: BattleboxItem[] = [ { id: 'bb1', name: 'Corporate DRP', type: 'Document', description: 'Main Disaster Recovery Plan for corporate services.', location: 'sharepoint.com/drp', criticality: RiskLevel.Critical, lastVerified: '2024-07-20' } ];
export const mockAllITAssets: Record<string, ITAsset[]> = { 'c1': c1ITAssets, 'c2': [] };
export const mockAllNetworks: Record<string, Network[]> = { 'c1': c1Networks, 'c2': [] };
export const mockAllBattleboxItems: Record<string, BattleboxItem[]> = { 'c1': c1BattleboxItems, 'c2': [] };

// ### BIA ###
const c1BusinessUnits: BusinessUnit[] = [ { id: 'bu1', name: 'Finance', cluster: 'Corporate Services', functionalOwner: 'CFO', headcount: 25, description: "Manages all financial operations, including payroll, accounts payable/receivable, and financial reporting." } ];
const c1Processes: Process[] = [
    { 
        id: 'p1', 
        name: 'Monthly Payroll', 
        description: 'Processing salaries for all employees.', 
        unitId: 'bu1', 
        rto: '12-24 Hours', 
        rpo: '1 - 4 hours', 
        criticality: RiskLevel.Critical, 
        dependencies: [
            { type: 'internal', serviceId: 'svc1' },
            { type: 'internal', serviceId: 'svc2' },
        ],
        linkedSystemIds: ['asset2', 'asset4'],
        vitalRecords: [
            { id: 'vr1', name: 'Employee Banking Data Export', location: 'SFTP Server path: /secure/payroll/exports', description: 'Encrypted file containing bank details for payment run.'}
        ],
        manualDependencies: 'Requires successful completion of monthly financial close from Finance system.',
        mtpd: '3-4 Days' 
    },
    { 
        id: 'p2', 
        name: 'Customer Invoicing', 
        description: 'Generating and sending invoices to customers.', 
        unitId: 'bu1', 
        rto: '3-4 Days', 
        rpo: '12 - 24 hours', 
        criticality: RiskLevel.High,
        dependencies: [
            { type: 'internal', serviceId: 'svc1' },
        ],
        linkedSystemIds: ['asset1', 'asset2'],
        vitalRecords: [],
        manualDependencies: '',
        mtpd: '5-7 Days' 
    }
];
const c1Services: Service[] = [
    { id: 'svc1', name: 'Customer Relationship Management (CRM)', description: 'Manages all customer interactions and sales data.', owner: 'Sales Dept', rto: '4-8 Hours', rpo: '< 15 minutes', supportingAssets: ['asset2', 'asset1'], criticality: RiskLevel.Critical, ola: { uptimePercentage: 99.9, responseTimeHours: 4 }, breaches: [] },
    { id: 'svc2', name: 'Identity & Access Management', description: 'Provides authentication via Active Directory.', owner: 'IT Security', rto: '1-4 Hours', rpo: '15 - 60 minutes', supportingAssets: ['asset4'], criticality: RiskLevel.Critical, ola: { uptimePercentage: 99.95, responseTimeHours: 2 }, breaches: [] },
];
export const mockAllBusinessUnits: Record<string, BusinessUnit[]> = { 'c1': c1BusinessUnits, 'c2': [] };
export const mockAllProcesses: Record<string, Process[]> = { 'c1': c1Processes, 'c2': [] };
export const mockAllServices: Record<string, Service[]> = { 'c1': c1Services, 'c2': [] };

// ### THIRD PARTY RISK ###
export const mockAssessmentQuestions: ThirdPartyAssessmentQuestion[] = [
    { id: 'q1', category: 'Security', text: 'Does the vendor maintain a formal information security program?' },
    { id: 'q2', category: 'Security', text: 'Are employee background checks conducted?' },
    { id: 'q3', category: 'Resilience', text: 'Does the vendor have a documented and tested Business Continuity Plan?' },
    { id: 'q4', category: 'Resilience', text: 'Can the vendor provide evidence of a DR test within the last 12 months?' },
    { id: 'q5', category: 'Compliance', text: 'Is the vendor ISO 27001 certified?' },
];

const c1Vendors: Vendor[] = [ { id: 'v1', name: 'SA-Telco', contactPerson: 'Sipho Williams', contactEmail: 'sipho@sa-telco.com', contactPhone: '+27115551111', tier: '1', riskScore: 78, assessments: [{ questionId: 'q3', answer: 'Yes', comment: 'BCP provided and reviewed.'}, { questionId: 'q5', answer: 'Partial', comment: 'In progress, audit scheduled for Q4.'}], certificates: [{id: 'cert1', name: 'ISO 27001', fileUrl: '#', expiryDate: '2025-10-15'}] } ];
const c1SuppliedServices: SuppliedService[] = [ { id: 'ss1', vendorId: 'v1', name: 'Fibre Internet - 1Gbps', description: 'Primary internet connectivity for Midrand DC.', criticality: RiskLevel.Critical, sla: { uptimePercentage: 99.95, responseTimeHours: 4 }, breaches: [] } ];
export const mockAllVendors: Record<string, Vendor[]> = { 'c1': c1Vendors, 'c2': [] };
export const mockAllSuppliedServices: Record<string, SuppliedService[]> = { 'c1': c1SuppliedServices, 'c2': [] };

// ### REHEARSALS ###
const c1Scenarios: Scenario[] = [
    { id: 'scen1', title: 'Ransomware Attack', description: 'A widespread ransomware attack has encrypted all primary servers and workstations.' },
    { id: 'scen2', title: 'Data Center Fire', description: 'A fire has broken out in the Midrand Data Center, triggering a full evacuation and shutdown of all systems.' },
    { id: 'scen3', title: 'Key Supplier Outage', description: 'Our primary cloud provider (AWS) is experiencing a major regional outage.' },
];
const c1Rehearsals: Rehearsal[] = [
    { id: 'rh1', name: 'Q1 CRM Failover Drill', type: 'Failover Test', status: 'Completed', startDate: '2024-03-20', endDate: '2024-03-20', completionDate: '2024-03-20', participants: ['user2', 'user5'], objectives: 'Test automated failover of the primary CRM database.', resultsSummary: 'Failover completed in 2 hours, RTO met.' },
    { id: 'rh2', name: 'Q2 Ransomware Tabletop', type: 'BCM Tabletop Test', status: 'Completed', startDate: '2024-06-15', endDate: '2024-06-15', completionDate: '2024-06-15', participants: ['user1', 'user2', 'user4'], objectives: 'Walk through incident response and recovery decision-making during a ransomware attack.', resultsSummary: 'Good response, but communication plan with customers was unclear.', scenarioId: 'scen1' },
    { id: 'rh3', name: 'Q3 Full DR Rehearsal', type: 'Fully Integrated Test', status: 'Planned', startDate: '2024-09-25', endDate: '2024-09-26', participants: [], objectives: 'Simulate a full site failure of Midrand DC.' },
];
export const mockAllRehearsals: Record<string, Rehearsal[]> = { 'c1': c1Rehearsals, 'c2': [] };
export const mockAllScenarios: Record<string, Scenario[]> = { 'c1': c1Scenarios, 'c2': [] };

// ### GOVERNANCE ###
const c1BCMRoles: BCMRole[] = [ { id: 'role1', name: 'Crisis Manager', assigneeId: 'user1', deputyId: 'user4', responsibilities: ['Overall command of incident response'], hasInvocationAuthority: true } ];
const c1BCMStrategies: BCMStrategy[] = [ { id: 'strat1', name: 'Cloud Replication (AWS)', description: 'Replicate critical VMs to AWS af-south-1 region.', type: 'Cloud Failover' } ];
const c1GovControls: GovernanceControl[] = [
    { id: 'gov1', controlReference: 'APO01.01', description: 'Define the organizational structure.', domain: 'Align, Plan and Organize', status: 'Compliant', owner: 'CIO', lastAudit: '2024-05-20' },
    { id: 'DSS04.01', controlReference: 'DSS04.01', description: 'Define business continuity policy, objectives and scope.', domain: 'Deliver, Service and Support', status: 'Compliant', owner: 'BCM Manager', lastAudit: '2024-07-10'},
    { id: 'DSS04.07', controlReference: 'DSS04.07', description: 'Manage backup arrangements.', domain: 'Deliver, Service and Support', status: 'Compliant', owner: 'IT Director', lastAudit: '2024-08-01'},
];
const c1PciReqs: PCIDSSRequirement[] = [ { id: 'pci1', goal: 1, requirement: 'Build and Maintain a Secure Network', description: 'Install and maintain a firewall configuration.', status: 'Completed', progress: 100 } ];
const c1BlockedThreats: BlockedThreat[] = [ { id: 'bt1', timestamp: '2024-08-15 10:22:04', type: 'Ransomware', name: 'LockBit 3.0', sourceIp: '185.220.101.35', action: 'Blocked' } ];
export const mockAllBCMRoles: Record<string, BCMRole[]> = { 'c1': c1BCMRoles, 'c2': [] };
export const mockAllBCMStrategies: Record<string, BCMStrategy[]> = { 'c1': c1BCMStrategies, 'c2': [] };
export const mockAllGovControls: Record<string, GovernanceControl[]> = { 'c1': c1GovControls, 'c2': [] };
export const mockAllPciReqs: Record<string, PCIDSSRequirement[]> = { 'c1': c1PciReqs, 'c2': [] };
export const mockAllBlockedThreats: Record<string, BlockedThreat[]> = { 'c1': c1BlockedThreats, 'c2': [] };

// ### SECURE COMMS ###
const c1Channels: ChatChannel[] = [
    { id: 'chan1', name: 'Crisis Management Team', description: 'For Gold command during an incident.', memberIds: ['user1', 'user4'], isEncrypted: true },
    { id: 'chan2', name: 'IT Recovery Team', description: 'For technical coordination during a DR event.', memberIds: ['user2', 'user5'], isEncrypted: true },
];
const c1Messages: SecureMessage[] = [
    { id: 'msg1', channelId: 'chan1', authorId: 'user4', authorName: 'Priya Singh', authorAvatar: '', timestamp: '2024-08-20T10:00:00Z', content: 'Incident declared. All CMT members please confirm availability.' },
    { id: 'msg2', channelId: 'chan1', authorId: 'user1', authorName: 'Thabo Ndlovu', authorAvatar: '', timestamp: '2024-08-20T10:01:30Z', content: 'Thabo available. What is the status of the impacted services?' },
];
export const mockAllChannels: Record<string, ChatChannel[]> = { 'c1': c1Channels, 'c2': [] };
export const mockAllSecureMessages: Record<string, SecureMessage[]> = { 'c1': c1Messages, 'c2': [] };


// ### INTEGRATIONS ###
const defaultIntegrations: Integration[] = [
    { id: 'Twilio', status: 'Inactive', credentials: { accountSid: '', authToken: '' } },
    { id: 'Trello', status: 'Inactive', credentials: { apiKey: '', apiToken: '' } },
    { id: 'Slack', status: 'Inactive', credentials: { botToken: '' } },
    { id: 'ServiceNow', status: 'Inactive', credentials: { instanceUrl: '', username: '', password: '' } },
    { id: 'Everbridge', status: 'Inactive', credentials: { username: '', password: '' } },
    { id: 'SCCM', status: 'Inactive', credentials: { serverUrl: '', username: '', password: '' } },
];

export const mockAvailableIntegrations: {
    id: IntegrationName;
    name: IntegrationName;
    description: string;
    logo: (props: React.SVGProps<SVGSVGElement>) => React.ReactNode;
    fields: { key: string, label: string, type: 'text' | 'password' }[];
}[] = [
    { id: 'Twilio', name: 'Twilio', description: 'Send SMS notifications for alerts and incidents.', logo: TwilioIcon, fields: [{key: 'accountSid', label: 'Account SID', type: 'text'}, {key: 'authToken', label: 'Auth Token', type: 'password'}] },
    { id: 'Trello', name: 'Trello', description: 'Create Trello cards from risk treatment actions.', logo: TrelloIcon, fields: [{key: 'apiKey', label: 'API Key', type: 'text'}, {key: 'apiToken', label: 'API Token', type: 'password'}] },
    { id: 'Slack', name: 'Slack', description: 'Send notifications to Slack channels during incidents.', logo: SlackIcon, fields: [{key: 'botToken', label: 'Bot User OAuth Token', type: 'password'}] },
    { id: 'ServiceNow', name: 'ServiceNow', description: 'Create incidents in ServiceNow from risks.', logo: ServiceNowIcon, fields: [{key: 'instanceUrl', label: 'Instance URL (e.g. your-instance.service-now.com)', type: 'text'}, {key: 'username', label: 'Username', type: 'text'}, {key: 'password', label: 'Password', type: 'password'}] },
    { id: 'Everbridge', name: 'Everbridge', description: 'Trigger mass notifications via Everbridge.', logo: EverbridgeIcon, fields: [{key: 'username', label: 'Username', type: 'text'}, {key: 'password', label: 'Password', type: 'password'}] },
    { 
        id: 'SCCM', 
        name: 'SCCM', 
        description: 'Sync IT assets from Microsoft SCCM/MECM CMDB.', 
        logo: SCCMIcon, 
        fields: [
            {key: 'serverUrl', label: 'Server FQDN', type: 'text'}, 
            {key: 'username', label: 'Username', type: 'text'}, 
            {key: 'password', label: 'Password', type: 'password'}
        ] 
    },
];

// #####################################################################
// # COMPANY PROFILE ASSEMBLY
// #####################################################################

const completedCompanyData: Omit<CompanyProfile, 'id' | 'name' | 'address' | 'logoUrl' | 'keyContacts' | 'sites' | 'isWizardCompleted'> = {
    financialRiskZAR: 25_850_000,
    tasks: [ { id: 't1', description: 'Review Q3 BIA with department heads', dueDate: '2024-09-15', completed: false } ],
    aiAlerts: [ { id: 'a1', title: 'Gap Detected: RTO Mismatch', message: 'The DRP for "CustomerDB" has an RTO of 4h, but its dependency "AuthService" has an RTO of 8h.', timestamp: '2 hours ago', severity: 'Critical' } ],
    notifyUsers: c1NotifyUsers,
    invocationPlan: [ 
      { id: 'inv1', step: 1, action: 'Assemble Crisis Management Team', description: 'Contact all primary members of the CMT via secure group chat.', assigneeRole: 'Crisis Manager', status: 'Pending' },
      { id: 'inv2', step: 2, action: 'Assess Incident Severity', description: 'Evaluate the business and technical impact to classify the incident.', assigneeRole: 'Crisis Management Team', status: 'Pending' },
      { id: 'inv3', step: 3, action: 'Make Invocation Decision', description: 'Decide whether to formally declare a disaster and invoke the BCP/DRP.', assigneeRole: 'Crisis Manager', status: 'Pending' },
      { id: 'inv4', step: 4, action: 'Initiate Stakeholder Communications', description: 'Send initial alerts to executives, staff, and key customers as per the comms plan.', assigneeRole: 'Comms Lead', status: 'Pending' },
    ],
    siteRiskBreakdown: {
        's1-site1': { electricity: { score: 8.5, trend: 'up'}, vandalism: { score: 7.2, trend: 'stable'} },
        's1-site2': { electricity: { score: 8.0, trend: 'up'}, vandalism: { score: 6.8, trend: 'up'} },
    },
    historicalGeoRisk: [ { date: '2024-07-01', siteId: 's1-site1', electricity: 8.5, vandalism: 7.2 } ],
    integrations: defaultIntegrations.map(i => ({...i})),
    resilienceFramework: [
        { id: 'phase1', name: 'Policy and Program Management', description: 'Establishing the governance, scope, and objectives of the BCMS.', status: 'Mature', progress: 0, resources: [{name: 'BCM Policy Statement', type: 'Document', url: '/documents?docId=d3'}] },
        { id: 'phase2', name: 'Analysis', description: 'Business Impact Analysis (BIA) and Risk Assessment activities.', status: 'In Progress', progress: 0, resources: [] },
        { id: 'phase3', name: 'Design', description: 'Identifying and selecting appropriate BCM strategies and solutions.', status: 'In Progress', progress: 0, resources: [] },
        { id: 'phase4', name: 'Implementation', description: 'Developing and implementing business continuity plans (BCPs).', status: 'Mature', progress: 0, resources: [] },
        { id: 'phase5', name: 'Validation', description: 'Testing, exercising, and reviewing the BCMS effectiveness.', status: 'In Progress', progress: 0, resources: [] },
        { id: 'phase6', name: 'Embedding', description: 'Integrating BCM into the organization\'s culture.', status: 'Not Started', progress: 0, resources: [] },
    ],
};

const emptyCompanyData: Omit<CompanyProfile, 'id' | 'name' | 'address' | 'logoUrl' | 'keyContacts' | 'sites' | 'isWizardCompleted'> = {
    financialRiskZAR: 0,
    tasks: [],
    aiAlerts: [],
    notifyUsers: [],
    invocationPlan: [],
    siteRiskBreakdown: {},
    historicalGeoRisk: [],
    integrations: defaultIntegrations.map(i => ({...i})),
    resilienceFramework: completedCompanyData.resilienceFramework.map(p => ({...p, progress: 0, status: 'Not Started'})), 
};

export const mockCompanies: CompanyProfile[] = [
    {
        id: 'c1',
        name: 'OmniCorp (SA)',
        address: '1 Sandton Drive, Sandton, Johannesburg',
        isWizardCompleted: true,
        logoUrl: '',
        keyContacts: [ { id: 's1-kc1', name: 'Thabo Ndlovu', role: 'BCM Manager (Custodian)', email: 'thabo.ndlovu@omnicorp.co.za' } ],
        sites: [
            { id: 's1-site1', name: 'Johannesburg HQ', location: 'Johannesburg, GP' },
            { id: 's1-site2', name: 'Midrand DC', location: 'Midrand, GP' },
        ],
        ...completedCompanyData,
    },
    {
        id: 'c2',
        name: 'Innovate Solutions',
        address: '123 Tech Park, Cape Town',
        isWizardCompleted: false,
        keyContacts: [{id: 's2-kc1', name: 'Alice Williams', role: 'Founder (Custodian)', email: 'alice.w@innovate.com'}],
        sites: [{id: 's2-site1', name: 'Woodstock Hub', location: 'Cape Town, WC'}],
        ...emptyCompanyData,
    }
];

// ### SERVICE DEFINITION ###
export const mockServiceDefinition: ServiceModule[] = [
  {
    name: 'Business Impact Analysis',
    description: 'Understand the impact of disruption on your critical business processes and resources.',
    relatedStandard: 'ISO 22317',
    features: [
      { name: 'Hierarchical Process Mapping', benefit: 'Model your business from units down to individual processes.', tier: 'Standard' },
      { name: 'RTO, RPO, and MTPD Definition', benefit: 'Establish clear recovery targets for every process.', tier: 'Standard' },
      { name: 'Dependency Analysis', benefit: 'Visualize how processes, services, and assets are interconnected.', tier: 'Standard' },
      { name: 'Impact-over-time Profiling', benefit: 'Quantify financial and non-financial impacts as a disruption unfolds.', tier: 'Standard' },
    ]
  },
  {
    name: 'Risk Management',
    description: 'Identify, analyze, and evaluate threats to your organization to prioritize mitigation efforts.',
    relatedStandard: 'ISO 31000',
    features: [
      { name: 'Centralized Risk Register', benefit: 'Maintain a single source of truth for all identified risks.', tier: 'Standard' },
      { name: 'Impact & Likelihood Scoring', benefit: 'Use a consistent methodology to quantify and compare risks.', tier: 'Standard' },
      { name: 'Risk Treatment Plans', benefit: 'Create, assign, and track actionable tasks to mitigate risks.', tier: 'Standard' },
      { name: 'COBIT Control Linking', benefit: 'Connect operational risks to specific governance controls.', tier: 'Standard' },
    ]
  },
  {
    name: 'IT Service Continuity Management',
    description: 'Ensure your technology can support the business\'s recovery requirements.',
    relatedStandard: 'ITIL / ISO 27031',
    features: [
      { name: 'IT Asset Inventory', benefit: 'Catalogue all critical servers, applications, and network devices.', tier: 'Standard' },
      { name: 'Service Level Dashboard', benefit: 'Identify gaps between business RTOs and technical recovery capabilities.', tier: 'Standard' },
      { name: 'Technical Recovery Procedures', benefit: 'Store and access step-by-step recovery guides for IT assets.', tier: 'Standard' },
      { name: 'Dependency Failure Simulation', benefit: 'Model the cascading impact of an IT asset failure.', tier: 'Standard' },
    ]
  },
  {
    name: 'Continuity Planning',
    description: 'Develop, document, and maintain your Business Continuity and Disaster Recovery plans.',
    relatedStandard: 'ISO 22301',
    features: [
      { name: 'Document Generation Wizard', benefit: 'Rapidly create BCPs and DRPs using live data from other modules.', tier: 'Standard' },
      { name: 'Centralized Document Library', benefit: 'Manage the entire lifecycle of your continuity plans.', tier: 'Standard' },
      { name: 'Role-based Governance', benefit: 'Define a clear RACI matrix for your response structure.', tier: 'Standard' },
      { name: 'Compliance Tracker', benefit: 'Track your program\'s alignment with ISO 22301 requirements.', tier: 'Standard' },
    ]
  },
  {
    name: 'Incident Management',
    description: 'Manage disruptions and coordinate your response in real-time.',
    relatedStandard: 'ISO 22320',
    features: [
      { name: 'Live Command Center', benefit: 'A single pane of glass for managing an active incident.', tier: 'Standard' },
      { name: 'Interactive Invocation Checklist', benefit: 'Track response steps and ensure nothing is missed.', tier: 'Standard' },
      { name: 'Timestamped Event Logging', benefit: 'Create an authoritative, auditable timeline of the incident.', tier: 'Standard' },
      { name: 'Secure Communications Hub', benefit: 'Collaborate with your team in dedicated, encrypted chat channels.', tier: 'Standard' },
      { name: 'Mass Notifications', benefit: 'Communicate with stakeholders via SMS, Email, and other channels.', tier: 'Premium' },
    ]
  },
   {
    name: 'Third-Party Risk Management',
    description: 'Understand and mitigate the risks posed by your supply chain.',
    relatedStandard: 'ISO 22318',
    features: [
      { name: 'Vendor Directory & Tiering', benefit: 'Catalogue all third-party suppliers and rank them by criticality.', tier: 'Standard' },
      { name: 'SLA / OLA Management', benefit: 'Track service level agreements and log breaches.', tier: 'Standard' },
      { name: 'Risk Assessment Questionnaires', benefit: 'Conduct detailed assessments to calculate a vendor risk score.', tier: 'Standard' },
      { name: 'Certificate Management', benefit: 'Store and track expiry for vendor certifications like ISO 27001.', tier: 'Standard' },
    ]
  },
];

// ### RESOURCES ###
export const mockGlossaryTerms: GlossaryTerm[] = [
    { term: 'Business Continuity (BC)', definition: 'The capability of an organization to continue the delivery of products or services at acceptable predefined levels following a disruptive incident.', category: 'General' },
    { term: 'Business Continuity Plan (BCP)', definition: 'A documented collection of procedures and information that is developed, compiled, and maintained in readiness for use in an incident to enable an organization to continue to deliver its critical products and services.', category: 'General' },
    { term: 'Business Impact Analysis (BIA)', definition: 'The process of analyzing business functions and the effect that a business disruption might have upon them.', category: 'Analysis' },
    { term: 'Recovery Time Objective (RTO)', definition: 'The period of time following an incident within which a business process must be resumed, or resources must be recovered.', category: 'Recovery' },
    { term: 'Recovery Point Objective (RPO)', definition: 'The point in time to which data must be recovered after a disruption. It represents the maximum acceptable amount of data loss.', category: 'Recovery' },
    { term: 'Maximum Tolerable Period of Disruption (MTPD)', definition: 'The time it would take for adverse impacts, which might arise as a result of not providing a product/service or performing an activity, to become unacceptable.', category: 'Analysis' },
    { term: 'Risk Assessment', definition: 'The overall process of risk identification, risk analysis, and risk evaluation.', category: 'Analysis' },
    { term: 'Invocation', definition: 'The act of declaring that an organization’s business continuity plan needs to be put into effect in order to continue the delivery of key products or services.', category: 'Recovery' },
];