
import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { useDocuments } from '../context/DocumentsContext';
import { mockGlossaryTerms } from '../data/mockData';
import { DocumentIcon } from '../components/icons/DocumentIcon';

const TABS = ['BCI Glossary', 'Resource Library'];

const GlossaryView: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedTerm, setSelectedTerm] = useState(mockGlossaryTerms[0]);

    const filteredTerms = useMemo(() => {
        return mockGlossaryTerms.filter(term => 
            term.term.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [searchTerm]);
    
    return (
        <div className="flex gap-6 h-[calc(100vh-250px)]">
            <div className="w-1/3 flex flex-col">
                <input
                    type="text"
                    placeholder="Search glossary..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500 mb-4"
                />
                <div className="flex-grow overflow-y-auto border border-slate-700/50 rounded-lg">
                    {filteredTerms.map(term => (
                        <button 
                            key={term.term}
                            onClick={() => setSelectedTerm(term)}
                            className={`w-full text-left p-3 text-sm transition-colors ${selectedTerm.term === term.term ? 'bg-cyan-500/10 text-cyan-400' : 'hover:bg-slate-800/60 text-slate-300'}`}
                        >
                            {term.term}
                        </button>
                    ))}
                </div>
            </div>
            <div className="w-2/3">
                 {selectedTerm && (
                    <div className="bg-slate-800/50 p-6 rounded-lg h-full animate-fade-in">
                        <h3 className="text-2xl font-bold text-cyan-400">{selectedTerm.term}</h3>
                        <p className="text-sm font-semibold text-slate-500 mt-1 mb-4">Category: {selectedTerm.category}</p>
                        <p className="text-slate-300 whitespace-pre-wrap">{selectedTerm.definition}</p>
                    </div>
                 )}
            </div>
        </div>
    );
}

const LibraryView: React.FC = () => {
    const { documents } = useDocuments();
    const resourceDocs = useMemo(() => documents.filter(d => d.category === 'Resource'), [documents]);

    return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-slate-400">
                <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                    <tr>
                        <th scope="col" className="px-6 py-3">Document Title</th>
                        <th scope="col" className="px-6 py-3">Type</th>
                        <th scope="col" className="px-6 py-3">Source / Owner</th>
                        <th scope="col" className="px-6 py-3">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {resourceDocs.map((doc) => (
                        <tr key={doc.id} className="border-b border-slate-700/50 hover:bg-slate-800/40">
                            <td className="px-6 py-4 font-medium text-slate-200">{doc.name}</td>
                            <td className="px-6 py-4">{doc.type}</td>
                            <td className="px-6 py-4">{doc.owner}</td>
                            <td className="px-6 py-4">
                                <a href="#" className="text-cyan-400 hover:underline flex items-center gap-1 text-xs">
                                    <DocumentIcon className="w-4 h-4" />
                                    Download
                                </a>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default function Resources() {
  const [activeTab, setActiveTab] = useState(TABS[0]);

  const renderContent = () => {
    switch (activeTab) {
      case 'BCI Glossary': return <GlossaryView />;
      case 'Resource Library': return <LibraryView />;
      default: return null;
    }
  };

  return (
    <div className="flex flex-col gap-6">
        <div className="flex border-b border-slate-700">
            {TABS.map(tab => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-2 text-sm font-medium transition-colors
                        ${activeTab === tab 
                            ? 'border-b-2 border-cyan-400 text-cyan-400' 
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                >
                    {tab}
                </button>
            ))}
        </div>
        <Card title={activeTab}>
            {renderContent()}
        </Card>
    </div>
  );
};
