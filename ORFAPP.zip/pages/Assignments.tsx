
import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { Assignment, RiskLevel, Document, Rehearsal } from '../types';
import { useMetadata } from '../context/MetadataContext';
import { useAssignments } from '../context/AssignmentsContext';
import { useDocuments } from '../context/DocumentsContext';
import { useRehearsals } from '../context/RehearsalsContext';
import { CloseIcon } from '../components/icons/CloseIcon';

function NewAssignmentModal({ isOpen, onClose, onSave }: { isOpen: boolean, onClose: () => void, onSave: (assignment: Assignment) => void }) {
    const { currentCompany } = useMetadata();
    const { documents } = useDocuments();
    const { rehearsals } = useRehearsals();
    const notifyUsers = currentCompany?.notifyUsers || [];

    const [task, setTask] = useState('');
    const [assigneeId, setAssigneeId] = useState('');
    const [dueDate, setDueDate] = useState('');
    const [riskLevel, setRiskLevel] = useState<RiskLevel>(RiskLevel.Medium);
    const [relatedItemId, setRelatedItemId] = useState('');

    const relatedItems = useMemo(() => {
        const docItems = documents.map(d => ({ value: `Document:${d.id}`, label: `Doc: ${d.name}` }));
        const rehearsalItems = rehearsals.map(t => ({ value: `Rehearsal:${t.id}`, label: `Rehearsal: ${t.name}` }));
        return [...docItems, ...rehearsalItems];
    }, [documents, rehearsals]);
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!task || !assigneeId || !dueDate || !relatedItemId) {
            alert("Please fill out all fields.");
            return;
        }

        const [type, id] = relatedItemId.split(':');
        const allItems = [...documents, ...rehearsals];
        const selectedItem = allItems.find(item => item.id === id);
        
        if (!selectedItem) {
            alert("Invalid related item selected.");
            return;
        }

        const newAssignment: Assignment = {
            id: `as${Date.now()}`,
            task,
            assigneeId,
            dueDate,
            status: 'To Do',
            progress: 0,
            riskLevel: Number(riskLevel),
            relatedItem: {
                type: type as 'Document' | 'Rehearsal',
                id: selectedItem.id,
                name: selectedItem.name,
            }
        };

        onSave(newAssignment);
        // Reset form
        setTask('');
        setAssigneeId('');
        setDueDate('');
        setRiskLevel(RiskLevel.Medium);
        setRelatedItemId('');
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-2xl border border-slate-700">
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h3 className="text-lg font-semibold text-slate-200">Create New Assignment</h3>
                    <button onClick={onClose} className="text-slate-400 hover:text-white">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <div>
                        <label htmlFor="task" className="block text-sm font-medium text-slate-300 mb-1">Task Description</label>
                        <textarea id="task" value={task} onChange={e => setTask(e.target.value)} required rows={3} className="w-full bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500" placeholder="e.g., Review and update the CRM recovery plan"></textarea>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="assigneeId" className="block text-sm font-medium text-slate-300 mb-1">Assignee</label>
                            <select id="assigneeId" value={assigneeId} onChange={e => setAssigneeId(e.target.value)} required className="w-full bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500">
                                <option value="" disabled>Select a user</option>
                                {notifyUsers.map(user => <option key={user.id} value={user.id}>{user.name}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="dueDate" className="block text-sm font-medium text-slate-300 mb-1">Due Date</label>
                            <input type="date" id="dueDate" value={dueDate} onChange={e => setDueDate(e.target.value)} required className="w-full bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500" />
                        </div>
                    </div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="riskLevel" className="block text-sm font-medium text-slate-300 mb-1">Risk Level</label>
                            <select id="riskLevel" value={riskLevel} onChange={e => setRiskLevel(Number(e.target.value) as RiskLevel)} required className="w-full bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500">
                                {Object.keys(RiskLevel).filter(k => isNaN(Number(k))).map((level, i) => (
                                    <option key={i} value={i}>{level}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="relatedItemId" className="block text-sm font-medium text-slate-300 mb-1">Related Item</label>
                            <select id="relatedItemId" value={relatedItemId} onChange={e => setRelatedItemId(e.target.value)} required className="w-full bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500">
                                <option value="" disabled>Select a document or rehearsal</option>
                                {relatedItems.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}
                            </select>
                        </div>
                    </div>
                    <div className="pt-4 flex justify-end">
                        <button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-6 rounded-lg text-sm">
                            Save Assignment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    )
}


export default function Assignments() {
    const { currentCompany } = useMetadata();
    const { assignments, addAssignment, updateAssignment } = useAssignments();
    const notifyUsers = currentCompany?.notifyUsers || [];
    
    const [statusFilter, setStatusFilter] = useState('All');
    const [assigneeFilter, setAssigneeFilter] = useState('All');
    const [dueDateFilter, setDueDateFilter] = useState('All');
    const [isModalOpen, setIsModalOpen] = useState(false);

    const users = [{ id: 'All', name: 'All Assignees' }, ...notifyUsers];

    const handleProgressChange = (id: string, progress: number) => {
        let status: Assignment['status'] = 'In Progress';
        if (progress <= 0) status = 'To Do';
        if (progress >= 100) status = 'Completed';
        updateAssignment(id, { progress, status });
    };
    
    const filteredAssignments = useMemo(() => {
        return assignments.filter(assignment => {
            const statusMatch = statusFilter === 'All' || assignment.status === statusFilter;
            const assigneeMatch = assigneeFilter === 'All' || assignment.assigneeId === assigneeFilter;

            const today = new Date();
            today.setHours(0,0,0,0);
            const dueDate = new Date(assignment.dueDate);
            let dateMatch = true;
            if (dueDateFilter === 'Overdue') {
                dateMatch = dueDate < today && assignment.status !== 'Completed';
            } else if (dueDateFilter === 'ThisWeek') {
                const endOfWeek = new Date(today);
                endOfWeek.setDate(today.getDate() + (7 - today.getDay()));
                dateMatch = dueDate >= today && dueDate <= endOfWeek;
            } else if (dueDateFilter === 'ThisMonth') {
                const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                dateMatch = dueDate >= today && dueDate <= endOfMonth;
            }

            return statusMatch && assigneeMatch && dateMatch;
        });
    }, [statusFilter, assigneeFilter, dueDateFilter, assignments]);
    
    const assigneeMap = useMemo(() => new Map(notifyUsers.map(u => [u.id, u.name])), [notifyUsers]);

    const handleSaveAssignment = (newAssignment: Assignment) => {
        addAssignment(newAssignment);
        setIsModalOpen(false);
    }
    
    if (!currentCompany) return <Card title="Loading...">Loading company data...</Card>;

    return (
        <>
            <NewAssignmentModal 
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSaveAssignment}
            />
            <Card title="Task Assignments">
                <div className="mb-4 flex flex-wrap gap-4">
                    <div>
                        <label htmlFor="status-filter" className="text-sm font-medium text-slate-400 mr-2">Status:</label>
                        <select id="status-filter" value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="bg-slate-700 border-slate-600 rounded-md p-1.5 text-sm focus:ring-cyan-500 focus:border-cyan-500">
                          <option value="All">All Statuses</option>
                          <option value="To Do">To Do</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Completed">Completed</option>
                        </select>
                    </div>
                    <div>
                        <label htmlFor="assignee-filter" className="text-sm font-medium text-slate-400 mr-2">Assignee:</label>
                        <select id="assignee-filter" value={assigneeFilter} onChange={e => setAssigneeFilter(e.target.value)} className="bg-slate-700 border-slate-600 rounded-md p-1.5 text-sm focus:ring-cyan-500 focus:border-cyan-500">
                          {users.map(user => <option key={user.id} value={user.id}>{user.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="duedate-filter" className="text-sm font-medium text-slate-400 mr-2">Due:</label>
                        <select id="duedate-filter" value={dueDateFilter} onChange={e => setDueDateFilter(e.target.value)} className="bg-slate-700 border-slate-600 rounded-md p-1.5 text-sm focus:ring-cyan-500 focus:border-cyan-500">
                          <option value="All">All Dates</option>
                          <option value="Overdue">Overdue</option>
                          <option value="ThisWeek">This Week</option>
                          <option value="ThisMonth">This Month</option>
                        </select>
                    </div>
                    <div className="flex-grow text-right">
                        <button onClick={() => setIsModalOpen(true)} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-1.5 px-4 rounded-lg text-sm">
                            Create New Assignment
                        </button>
                    </div>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-400">
                        <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                            <tr>
                                <th scope="col" className="px-6 py-3">Task</th>
                                <th scope="col" className="px-6 py-3">Assignee</th>
                                <th scope="col" className="px-6 py-3 w-1/5">Progress</th>
                                <th scope="col" className="px-6 py-3">Due Date</th>
                                <th scope="col" className="px-6 py-3">Related Item</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredAssignments.map((assignment) => (
                                <tr key={assignment.id} className="border-b border-slate-700/50 hover:bg-slate-800/40">
                                    <td className="px-6 py-4 font-medium text-slate-200">{assignment.task}</td>
                                    <td className="px-6 py-4">{assigneeMap.get(assignment.assigneeId) || 'Unknown'}</td>
                                    <td className="px-6 py-4">
                                         <div className="flex items-center gap-2">
                                            <input 
                                                type="range"
                                                min="0"
                                                max="100"
                                                step="10"
                                                value={assignment.progress}
                                                onChange={(e) => handleProgressChange(assignment.id, parseInt(e.target.value))}
                                                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                                            />
                                            <span className="text-sm font-semibold w-10 text-right">{assignment.progress}%</span>
                                         </div>
                                    </td>
                                    <td className="px-6 py-4">{assignment.dueDate}</td>
                                    <td className="px-6 py-4">{assignment.relatedItem.name}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {filteredAssignments.length === 0 && <p className="text-center py-8 text-slate-500">No assignments match your filters.</p>}
                </div>
            </Card>
        </>
    );
};
