import React from 'react';
import { useAuth } from '../context/AuthContext';
import { SpinnerIcon } from '../components/icons/SpinnerIcon';

export default function WaitingForSetup() {
  const { logout } = useAuth();
  return (
    <div className="flex flex-col items-center justify-center h-full text-center">
      <SpinnerIcon className="w-12 h-12 text-cyan-400 animate-spin mb-6" />
      <h1 className="text-3xl font-bold text-slate-100">Application Setup in Progress</h1>
      <p className="mt-4 text-lg text-slate-400">An administrator for your company is currently configuring the application.</p>
      <p className="mt-2 text-slate-500">Please check back later. Once setup is complete, you will be able to access the dashboard.</p>
      <button
        onClick={logout}
        className="mt-8 px-6 py-2 bg-slate-600 text-white font-semibold rounded-lg hover:bg-slate-700 transition-colors"
      >
        Logout
      </button>
    </div>
  );
};