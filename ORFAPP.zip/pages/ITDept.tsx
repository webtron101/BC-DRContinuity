


import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { RiskLevel, ITAsset, BusinessUnit, Process, Service, RTOPeriod, RPOPeriod, SuppliedService } from '../types';
import DependencyMap from '../components/DependencyMap';
import { useBIA } from '../context/BIAContext';
import { useIT } from '../context/ITContext';
import { useThirdPartyRisk } from '../context/ThirdPartyRiskContext';
import { useMetadata } from '../context/MetadataContext';

const TABS = ['BIA Workflow', 'Analysis & Charts', 'Dependency Map'];

const getRiskLevelInfo = (level: RiskLevel) => {
    switch (level) {
        case RiskLevel.Critical: return { text: 'Critical', color: 'bg-red-500/20 text-red-400' };
        case RiskLevel.High: return { text: 'High', color: 'bg-orange-500/20 text-orange-400' };
        case RiskLevel.Medium: return { text: 'Medium', color: 'bg-yellow-500/20 text-yellow-400' };
        default: return { text: 'Low', color: 'bg-green-500/20 text-green-400' };
    }
};

const BIAWorkflowView: React.FC = () => {
    const { businessUnits, processes, services, addBusinessUnit, addProcess } = useBIA();
    const { suppliedServices } = useThirdPartyRisk();
    const { itAssets } = useIT();
    const [expandedUnitId, setExpandedUnitId] = useState<string | null>(null);
    const [expandedProcessId, setExpandedProcessId] = useState<string | null>(null);

    const serviceMap = useMemo(() => new Map(services.map(s => [s.id, s])), [services]);
    const suppliedServiceMap = useMemo(() => new Map(suppliedServices.map(s => [s.id, s])), [suppliedServices]);
    const assetMap = useMemo(() => new Map(itAssets.map(a => [a.id, a.name])), [itAssets]);
    
    const toggleUnit = (unitId: string) => setExpandedUnitId(prev => prev === unitId ? null : unitId);
    const toggleProcess = (processId: string) => setExpandedProcessId(prev => prev === processId ? null : processId);

    return (
        <Card title="Business Units & BIA">
             <div className="mb-4 text-right">
                <button onClick={() => {/* TODO: addBusinessUnit modal */}} className="bg-cyan-600 text-white font-bold py-2 px-4 rounded">Add Business Unit</button>
            </div>
            <div className="space-y-2">
                {businessUnits.map(unit => (
                    <div key={unit.id} className="bg-slate-800/50 rounded-lg border border-slate-700/50">
                        <button onClick={() => toggleUnit(unit.id)} className="w-full flex justify-between items-center p-4 hover:bg-slate-700/30">
                            <h3 className="text-xl font-semibold text-slate-100">{unit.name}</h3>
                            <span className="text-slate-400">...</span>
                        </button>
                        {expandedUnitId === unit.id && (
                            <div className="p-4 border-t border-slate-700/50 space-y-3">
                                <div className="grid grid-cols-3 gap-4 text-sm">
                                    <p><strong className="text-slate-400">Owner:</strong> {unit.functionalOwner}</p>
                                    <p><strong className="text-slate-400">Headcount:</strong> {unit.headcount}</p>
                                    <p><strong className="text-slate-400">Cluster:</strong> {unit.cluster}</p>
                                </div>
                                <div className="text-sm text-slate-400">{unit.description}</div>

                                <div className="pt-4 mt-4 border-t border-slate-600">
                                    <div className="flex justify-between items-center">
                                         <h4 className="text-lg font-semibold text-cyan-400">Critical Processes</h4>
                                         <button className="bg-cyan-700 text-white text-xs py-1 px-3 rounded">Add Process</button>
                                    </div>
                                    <div className="mt-2 space-y-2">
                                        {processes.filter(p => p.unitId === unit.id).map(process => (
                                            <div key={process.id} className="bg-slate-900/50 rounded-md">
                                                <button onClick={() => toggleProcess(process.id)} className="w-full flex justify-between items-center p-3 hover:bg-slate-800/50">
                                                    <p className="font-semibold text-slate-200">{process.name}</p>
                                                    <p className="text-sm">RTO: <span className="font-mono text-cyan-300">{process.rto}</span></p>
                                                </button>
                                                {expandedProcessId === process.id && (
                                                     <div className="p-3 border-t border-slate-700/50 space-y-2">
                                                         <div className="flex justify-between items-center">
                                                            <h5 className="text-md font-semibold text-slate-300">Dependencies</h5>
                                                            <button className="bg-cyan-800 text-white text-xs py-1 px-3 rounded">Add/Link Dependency</button>
                                                         </div>
                                                        {process.dependencies.map(dep => {
                                                            const isInternal = dep.type === 'internal';
                                                            const service: Service | SuppliedService | undefined = isInternal ? serviceMap.get(dep.serviceId) : suppliedServiceMap.get(dep.serviceId);
                                                            if (!service) return null;
                                                            return (
                                                                <div key={dep.serviceId} className="pl-4 text-sm border-l-2 border-slate-700 ml-2">
                                                                    <p className="font-semibold text-slate-300">{service.name} <span className={`text-xs px-1.5 py-0.5 rounded-full ${isInternal ? 'bg-blue-500/20 text-blue-300' : 'bg-purple-500/20 text-purple-300'}`}>{isInternal ? 'Internal' : 'External'}</span></p>
                                                                    <p className="text-xs text-slate-400">{service.description}</p>
                                                                    <p className="text-xs text-slate-500">Required Uptime: {'ola' in service ? service.ola.uptimePercentage : service.sla.uptimePercentage}%</p>
                                                                </div>
                                                            )
                                                        })}
                                                        {process.dependencies.length === 0 && <p className="text-slate-500 text-sm">No dependencies linked.</p>}
                                                     </div>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </Card>
    );
};

const AnalysisView: React.FC = () => {
    const { processes, services } = useBIA();
    const { itAssets } = useIT();
    const [selectedProcessId, setSelectedProcessId] = useState<string>(processes[0]?.id || '');

     const timeToMinutes = (timeStr: RTOPeriod | RPOPeriod): number => {
        if (timeStr === 'N/A') return Infinity;
        const periodMap: Record<string, number> = {
            '< 1 Hour': 59, '1-4 Hours': 240, '4-8 Hours': 480, '8-12 Hours': 720, '12-24 Hours': 1440,
            '1-2 Days': 2880, '3-4 Days': 5760, '5-7 Days': 10080, '> 1 Week': 10081,
            'Zero / Synchronous': 0, '< 15 minutes': 14, '15 - 60 minutes': 60, '1 - 4 hours': 240,
            '4 - 12 hours': 720, '12 - 24 hours': 1440,
        };
        return periodMap[timeStr] ?? Infinity;
    };
    
    const chartData = useMemo(() => {
        const process = processes.find(p => p.id === selectedProcessId);
        if (!process) return [];

        const processRTO = { name: `PROCESS: ${process.name}`, rto: timeToMinutes(process.rto) };
        const dependencies = (process.dependencies || [])
             .filter(dep => dep.type === 'internal')
            .map(dep => services.find(s => s.id === dep.serviceId))
            .filter((s): s is Service => !!s)
            .flatMap(s => [
                { name: `SERVICE: ${s.name}`, rto: timeToMinutes(s.rto) },
                ...s.supportingAssets
                    .map(aId => itAssets.find(a => a.id === aId))
                    .filter((a): a is ITAsset => !!a)
                    .map(a => ({ name: `ASSET: ${a.name}`, rto: timeToMinutes(a.rto || 'N/A') }))
            ]);
        
        return [processRTO, ...dependencies].filter(d => d.rto !== Infinity);

    }, [selectedProcessId, processes, services, itAssets]);

    const maxRto = Math.max(...chartData.map(d => d.rto), 1);

    return (
        <Card title="RTO/RPO Gap Analysis">
            <div className="mb-4">
                <label htmlFor="process-select" className="text-sm font-medium text-slate-400 mr-2">Select a Process:</label>
                <select id="process-select" value={selectedProcessId} onChange={e => setSelectedProcessId(e.target.value)} className="bg-slate-700 border-slate-600 rounded-md p-1.5 text-sm focus:ring-cyan-500 focus:border-cyan-500">
                  {processes.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
            </div>
            <div className="space-y-4 pr-4">
                {chartData.map((item, index) => {
                    const isRequirement = item.name.startsWith('PROCESS');
                    const barWidth = (item.rto / maxRto) * 100;
                    const rtoRequirement = chartData[0]?.rto || 0;
                    const hasGap = !isRequirement && item.rto > rtoRequirement;

                    return (
                        <div key={index}>
                             <p className="text-sm font-semibold text-slate-300 truncate">{item.name}</p>
                             <div className="flex items-center gap-2 mt-1">
                                <div className="w-full bg-slate-700 rounded-full h-6">
                                    <div 
                                        className={`h-6 rounded-full ${isRequirement ? 'bg-cyan-500' : hasGap ? 'bg-red-500' : 'bg-green-500'}`}
                                        style={{ width: `${barWidth}%`}}
                                    ></div>
                                </div>
                                {hasGap && <span className="text-red-400 font-bold text-lg">!</span>}
                             </div>
                        </div>
                    );
                })}
            </div>
             <div className="flex justify-end gap-4 text-xs mt-4">
                <span className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-cyan-500"></div> Process RTO Requirement</span>
                <span className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-green-500"></div> Dependency Meets RTO</span>
                <span className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-red-500"></div> Dependency GAP</span>
            </div>
        </Card>
    )
}


const DependencyMapView: React.FC = () => {
    const { itAssets } = useIT();
    return (
        <Card title="Dependency Map">
            <DependencyMap assets={itAssets} />
        </Card>
    );
};

export default function BIA() {
    const [activeTab, setActiveTab] = useState(TABS[0]);
    const { currentCompany } = useMetadata();

    if (!currentCompany) return <Card title="Loading...">Loading company data...</Card>;

    const renderContent = () => {
        switch (activeTab) {
            case 'BIA Workflow': return <BIAWorkflowView />;
            case 'Analysis & Charts': return <AnalysisView />;
            case 'Dependency Map': return <DependencyMapView />;
            default: return null;
        }
    };

    return (
        <div className="flex flex-col gap-6">
            <div className="flex border-b border-slate-700 overflow-x-auto">
                {TABS.map(tab => (
                    <button key={tab} onClick={() => setActiveTab(tab)} className={`px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${activeTab === tab ? 'border-b-2 border-cyan-400 text-cyan-400' : 'text-slate-400 hover:text-slate-200'}`}>{tab}</button>
                ))}
            </div>
            <div>{renderContent()}</div>
        </div>
    );
};