
import React, { useState } from 'react';
import Card from '../components/Card';
import { RiskLevel } from '../types';
import { useMetadata } from '../context/MetadataContext';


function TrendArrow({ trend }: { trend: 'up' | 'down' | 'stable'}) {
    if (trend === 'up') return <span className="text-red-400">↑</span>;
    if (trend === 'down') return <span className="text-green-400">↓</span>;
    return <span className="text-slate-400">→</span>;
}

export default function GeoRisk() {
    const { currentCompany } = useMetadata();
    const sites = currentCompany?.sites || [];
    const siteRiskBreakdown = currentCompany?.siteRiskBreakdown || {};
    const historicalGeoRisk = currentCompany?.historicalGeoRisk || [];
    
    const [selectedSiteId, setSelectedSiteId] = useState<string | null>(sites[0]?.id || null);
    const [viewMode, setViewMode] = useState<'live' | 'historical'>('live');

    const selectedSite = sites.find(s => s.id === selectedSiteId);
    const selectedSiteDetails = selectedSiteId ? siteRiskBreakdown[selectedSiteId] : null;

    const getRiskLevelInfo = (level: RiskLevel) => {
        switch (level) {
            case RiskLevel.Critical: return { text: 'Critical', color: 'bg-red-500/20 text-red-400', dot: 'bg-red-500' };
            case RiskLevel.High: return { text: 'High', color: 'bg-orange-500/20 text-orange-400', dot: 'bg-orange-500' };
            case RiskLevel.Medium: return { text: 'Medium', color: 'bg-yellow-500/20 text-yellow-400', dot: 'bg-yellow-500' };
            case RiskLevel.Low: default: return { text: 'Low', color: 'bg-green-500/20 text-green-400', dot: 'bg-green-500' };
        }
    };
    
    const threatFeeds = [
        { id: 1, type: 'Utilities', title: 'Loadshedding Stage 6', details: 'Eskom announced Stage 6 loadshedding until further notice. High impact expected.', severity: 'High' },
        { id: 2, type: 'Civil Unrest', title: 'Service Delivery Protest - PTA', details: 'Protests may disrupt transportation in Pretoria CBD.', severity: 'Medium' },
        { id: 3, type: 'Infrastructure', title: 'Cable Theft Reported - JHB South', details: 'Fiber and copper cable theft may impact connectivity.', severity: 'High' },
        { id: 4, type: 'Cyber', title: 'New Phishing Campaign', details: 'Widespread phishing campaign targeting local banks detected.', severity: 'High' },
        { id: 5, type: 'Weather', title: 'Severe Thunderstorm Warning - CPT', details: 'Heavy rain and potential flooding expected in Cape Town this evening.', severity: 'Medium'},
        { id: 6, type: 'Political', title: 'Election Results Announcement', details: 'Increased security presence in major city centers expected.', severity: 'Low'},
    ] as const;
    
    const getSeverityColor = (severity: 'Low' | 'Medium' | 'High') => {
        if (severity === 'High') return 'border-l-4 border-orange-500';
        if (severity === 'Medium') return 'border-l-4 border-yellow-500';
        return 'border-l-4 border-cyan-500';
    }
    
    if (!currentCompany) return <Card title="Loading...">Loading company data...</Card>;

    // A simple hash function to generate somewhat consistent positions based on ID
    const getPosition = (id: string) => {
        let hash = 0;
        for (let i = 0; i < id.length; i++) {
            const char = id.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0; 
        }
        const top = 30 + (Math.abs(hash) % 50);
        const left = 20 + (Math.abs(hash * 31) % 60);
        return { top: `${top}%`, left: `${left}%` };
    };
    
    const rankedSites = sites.map(site => {
        const riskDetail = siteRiskBreakdown[site.id];
        const score = riskDetail ? (riskDetail.electricity.score + riskDetail.vandalism.score) / 2 : 0;
        return { ...site, score };
    }).sort((a,b) => b.score - a.score);

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
                <Card title="South Africa Site Risk Overview">
                     <div className="relative bg-slate-900/50 p-4 rounded-lg h-96 lg:h-[calc(100vh-20rem)] flex items-center justify-center overflow-hidden">
                        {/* Map and Toggle */}
                        <svg className="absolute w-auto h-full" viewBox="0 0 400 350" preserveAspectRatio="xMidYMid meet">
                             <g stroke="#56657F" strokeWidth="0.5" fill="rgba(148, 163, 184, 0.1)">
                                <path d="M185,296 L108,348 L20,220 L110,192 L145,212 Z" className="hover:fill-cyan-400/20 transition-colors"><title>Western Cape</title></path>
                                <path d="M185,296 L145,212 L200,180 L280,240 Z" className="hover:fill-cyan-400/20 transition-colors"><title>Eastern Cape</title></path>
                                <path d="M110,192 L20,220 L25,110 L120,135 Z" className="hover:fill-cyan-400/20 transition-colors"><title>Northern Cape</title></path>
                                <path d="M280,240 L200,180 L230,120 L295,145 L320,220 Z" className="hover:fill-cyan-400/20 transition-colors"><title>KwaZulu-Natal</title></path>
                                <path d="M230,120 L200,180 L120,135 L200,70 L250,80 Z" className="hover:fill-cyan-400/20 transition-colors"><title>Free State</title></path>
                                <path d="M200,70 L120,135 L25,110 L90,20 L180,40 Z" fill="rgba(249, 115, 22, 0.2)" className="hover:fill-orange-400/30 transition-colors"><title>North West</title></path>
                                <path d="M250,80 L200,70 L260,30 L280,75 Z" fill="rgba(239, 68, 68, 0.3)" className="hover:fill-red-400/40 transition-colors"><title>Gauteng</title></path>
                                <path d="M280,75 L260,30 L350,25 L340,90 Z" fill="rgba(234, 179, 8, 0.2)" className="hover:fill-yellow-400/30 transition-colors"><title>Mpumalanga</title></path>
                                <path d="M260,30 L180,40 L90,20 L280,5 Z" fill="rgba(249, 115, 22, 0.2)" className="hover:fill-orange-400/30 transition-colors"><title>Limpopo</title></path>
                             </g>
                        </svg>

                        {sites.map(site => {
                            const position = getPosition(site.id);
                            const riskInfo = getRiskLevelInfo(RiskLevel.High);
                            return (
                                <div key={site.id} title={`${site.name} (${riskInfo.text})`} 
                                    className="absolute z-20 text-center cursor-pointer transform -translate-x-1/2 -translate-y-1/2"
                                    style={{ top: position.top, left: position.left }}
                                    onClick={() => setSelectedSiteId(site.id)}>
                                    <div className={`w-3 h-3 rounded-full animate-pulse mx-auto ${selectedSiteId === site.id ? 'bg-cyan-400 ring-2 ring-cyan-400' : riskInfo.dot}`}></div>
                                    <span className="text-xs text-white bg-black/50 px-1 py-0.5 rounded whitespace-nowrap">{site.name}</span>
                                </div>
                            )
                        })}
                        
                         <div className="absolute top-4 left-4 z-30 bg-slate-800/70 p-1 rounded-lg text-xs">
                             <button onClick={() => setViewMode('live')} className={`px-3 py-1 rounded ${viewMode === 'live' ? 'bg-cyan-500 text-white' : 'text-slate-300'}`}>Live</button>
                             <button onClick={() => setViewMode('historical')} className={`px-3 py-1 rounded ${viewMode === 'historical' ? 'bg-cyan-500 text-white' : 'text-slate-300'}`}>Historical</button>
                        </div>
                    </div>
                </Card>
            </div>
            <div className="lg:col-span-1 flex flex-col gap-6">
                 <Card title="Ranked Site Risk">
                    <div className="space-y-1 max-h-48 overflow-y-auto pr-2">
                        {rankedSites.map(site => (
                             <div key={site.id} onClick={() => setSelectedSiteId(site.id)} className={`flex items-center justify-between p-2 rounded-lg cursor-pointer transition-colors ${selectedSiteId === site.id ? 'bg-cyan-500/10' : 'hover:bg-slate-800/40'}`}>
                                <p className="font-semibold text-slate-200">{site.name}</p>
                                <span className="font-bold text-lg text-orange-400">{site.score.toFixed(1)}</span>
                            </div>
                        ))}
                    </div>
                </Card>
                 <Card title={viewMode === 'live' ? 'Live Threat Feeds' : 'Historical Trends'}>
                    <div className="space-y-4 max-h-72 overflow-y-auto pr-2">
                        {viewMode === 'live' ? (
                            threatFeeds.map(feed => (
                                <div key={feed.id} className={`p-3 bg-slate-700/50 rounded-lg ${getSeverityColor(feed.severity)}`}>
                                    <p className="font-bold text-sm text-slate-300">{feed.title}</p>
                                    <p className="text-xs text-slate-400 mt-1">{feed.details}</p>
                                </div>
                            ))
                        ) : (
                             historicalGeoRisk.filter(hr => hr.siteId === selectedSiteId).map(hr => (
                                <div key={hr.date} className="p-3 bg-slate-700/50 rounded-lg">
                                    <p className="font-bold text-sm text-slate-300">{hr.date}</p>
                                    <p className="text-xs text-slate-400 mt-1">Electricity Risk: {hr.electricity}</p>
                                     <p className="text-xs text-slate-400">Vandalism Risk: {hr.vandalism}</p>
                                </div>
                            ))
                        )}
                         {viewMode === 'historical' && historicalGeoRisk.filter(hr => hr.siteId === selectedSiteId).length === 0 && (
                             <p className="text-slate-500 text-center">No historical data for this site.</p>
                         )}
                    </div>
                </Card>
            </div>
        </div>
    );
};