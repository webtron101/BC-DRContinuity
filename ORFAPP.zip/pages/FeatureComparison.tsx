
import React from 'react';
import Card from '../components/Card';
import { CheckCircleIcon } from '../components/icons/CheckCircleIcon';
import { LockIcon } from '../components/icons/LockIcon';
import { CloseIcon } from '../components/icons/CloseIcon';

const comparisonData = [
  {
    group: 'Platform & Governance',
    features: [
      { name: 'Multi-tenancy for MSSPs', atlas: 'premium', fusion: true, riskonnect: true, castellan: false },
      { name: 'Role-Based Access Control (RBAC)', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
      { name: 'ISO 22301 Compliance Module', atlas: 'standard', fusion: false, riskonnect: true, castellan: true },
      { name: 'Customizable Dashboards', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
      { name: 'AI Copilot Assistant', atlas: 'premium', fusion: false, riskonnect: false, castellan: false },
    ],
  },
  {
    group: 'Business Impact Analysis (BIA)',
    features: [
      { name: 'Hierarchical Process Mapping', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
      { name: 'RTO/RPO/MTPD Definitions', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
      { name: 'Service Dependency Analysis', atlas: 'standard', fusion: true, riskonnect: true, castellan: false },
      { name: 'Automated RTO/RPO Gap Analysis', atlas: 'standard', fusion: true, riskonnect: false, castellan: false },
    ],
  },
  {
    group: 'Risk Management',
    features: [
      { name: 'Centralized Risk Register', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
      { name: 'Risk Treatment Plans & Tasks', atlas: 'standard', fusion: true, riskonnect: false, castellan: true },
      { name: 'COBIT/ITIL Control Linking', atlas: 'standard', fusion: false, riskonnect: true, castellan: false },
      { name: 'Live GeoRisk Intelligence Feeds', atlas: 'premium', fusion: false, riskonnect: true, castellan: false },
    ],
  },
  {
    group: 'IT Service Continuity (ITSCM)',
    features: [
      { name: 'IT Asset & CMDB Inventory', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
      { name: 'Automated CMDB Sync (SCCM, etc.)', atlas: 'premium', fusion: false, riskonnect: true, castellan: false },
      { name: 'Visual Dependency Mapping', atlas: 'standard', fusion: true, riskonnect: true, castellan: false },
      { name: 'Failure Simulation', atlas: 'premium', fusion: false, riskonnect: false, castellan: false },
    ],
  },
   {
    group: 'Continuity Planning',
    features: [
      { name: 'Centralized Document Library', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
      { name: 'Version Control & Audit History', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
      { name: 'RACI / Role Definitions', atlas: 'standard', fusion: true, riskonnect: false, castellan: true },
      { name: 'AI Plan Generation', atlas: 'premium', fusion: false, riskonnect: false, castellan: false },
    ],
  },
  {
    group: 'Incident Management',
    features: [
      { name: 'Live Command Center Dashboard', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
      { name: 'Interactive Invocation Checklists', atlas: 'standard', fusion: true, riskonnect: false, castellan: true },
      { name: 'Secure Comms (Encrypted Chat)', atlas: 'standard', fusion: false, riskonnect: false, castellan: false },
      { name: 'Mass Notifications (Twilio, Everbridge)', atlas: 'premium', fusion: true, riskonnect: true, castellan: true },
    ],
  },
  {
    group: 'Third-Party Risk',
    features: [
        { name: 'Vendor Directory & Tiering', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
        { name: 'SLA / OLA Tracking', atlas: 'standard', fusion: true, riskonnect: false, castellan: false },
        { name: 'Assessment Questionnaires', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
        { name: 'Secure Vendor Assessment Portal', atlas: 'premium', fusion: false, riskonnect: false, castellan: false },
    ]
  },
   {
    group: 'Rehearsals',
    features: [
        { name: 'Rehearsal Planning & Scheduling', atlas: 'standard', fusion: true, riskonnect: true, castellan: true },
        { name: 'Scenario Library', atlas: 'standard', fusion: true, riskonnect: false, castellan: true },
        { name: 'AI Post-Mortem Report Generation', atlas: 'premium', fusion: false, riskonnect: false, castellan: false },
    ]
  }
];

const FeatureCell = ({ status }: { status: 'standard' | 'premium' | 'none' }) => {
    if (status === 'standard') {
        return <CheckCircleIcon className="w-6 h-6 text-green-400 mx-auto"><title>Included in Standard Plan</title></CheckCircleIcon>;
    }
    if (status === 'premium') {
        return <LockIcon className="w-5 h-5 text-cyan-400 mx-auto"><title>Included in Premium Plan</title></LockIcon>;
    }
    return <CloseIcon className="w-5 h-5 text-slate-600 mx-auto"><title>Not Available</title></CloseIcon>;
};

const CompetitorCell = ({ included }: { included: boolean }) => {
    if (included) {
        return <CheckCircleIcon className="w-6 h-6 text-slate-500 mx-auto"><title>Feature Available</title></CheckCircleIcon>;
    }
    return <CloseIcon className="w-5 h-5 text-slate-600 mx-auto"><title>Not Available</title></CloseIcon>;
};

export default function FeatureComparison() {
    return (
        <Card title="Product Feature Comparison">
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                    <thead className="text-xs text-slate-500 dark:text-slate-400 uppercase bg-slate-50 dark:bg-slate-900/30">
                        <tr>
                            <th scope="col" className="px-6 py-3 min-w-[250px]">Feature</th>
                            <th scope="col" className="px-6 py-3 text-center border-l border-slate-200 dark:border-slate-700">Atlas Resilience <br/><span className="font-normal normal-case">(Standard)</span></th>
                            <th scope="col" className="px-6 py-3 text-center border-l border-slate-200 dark:border-slate-700">Atlas Resilience <br/><span className="font-normal normal-case">(Premium)</span></th>
                            <th scope="col" className="px-6 py-3 text-center border-l border-slate-200 dark:border-slate-700">Fusion</th>
                            <th scope="col" className="px-6 py-3 text-center border-l border-slate-200 dark:border-slate-700">Riskonnect</th>
                            <th scope="col" className="px-6 py-3 text-center border-l border-slate-200 dark:border-slate-700">Castellan</th>
                        </tr>
                    </thead>
                    <tbody>
                        {comparisonData.map((group) => (
                            <React.Fragment key={group.group}>
                                <tr className="bg-slate-100 dark:bg-slate-800/50">
                                    <th colSpan={6} className="px-4 py-2 text-base font-semibold text-slate-800 dark:text-slate-200">{group.group}</th>
                                </tr>
                                {group.features.map((feature, index) => (
                                    <tr key={index} className="border-b border-slate-200 dark:border-slate-700/50 hover:bg-slate-50 dark:hover:bg-slate-800/40">
                                        <td className="px-6 py-4 font-medium text-slate-800 dark:text-slate-300">{feature.name}</td>
                                        <td className="px-6 py-4 text-center border-l border-slate-200 dark:border-slate-700/50">
                                            <FeatureCell status={feature.atlas === 'standard' ? 'standard' : 'none'} />
                                        </td>
                                        <td className="px-6 py-4 text-center border-l border-slate-200 dark:border-slate-700/50">
                                            <FeatureCell status={feature.atlas === 'premium' || feature.atlas === 'standard' ? feature.atlas : 'none'} />
                                        </td>
                                        <td className="px-6 py-4 text-center border-l border-slate-200 dark:border-slate-700/50">
                                            <CompetitorCell included={feature.fusion} />
                                        </td>
                                        <td className="px-6 py-4 text-center border-l border-slate-200 dark:border-slate-700/50">
                                            <CompetitorCell included={feature.riskonnect} />
                                        </td>
                                        <td className="px-6 py-4 text-center border-l border-slate-200 dark:border-slate-700/50">
                                            <CompetitorCell included={feature.castellan} />
                                        </td>
                                    </tr>
                                ))}
                            </React.Fragment>
                        ))}
                    </tbody>
                </table>
            </div>
        </Card>
    );
}