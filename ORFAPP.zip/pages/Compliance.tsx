
import React, { useState } from 'react';
import Card from '../components/Card';
import { ComplianceItem } from '../types';
import { useDocuments } from '../context/DocumentsContext';
import { DocumentIcon } from '../components/icons/DocumentIcon';
import { CloseIcon } from '../components/icons/CloseIcon';

const AuditHistoryModal: React.FC<{ item: ComplianceItem, onClose: () => void }> = ({ item, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-2xl border border-slate-700">
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h3 className="text-lg font-semibold">Audit History for "{item.name}"</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </div>
                <div className="p-6">
                    {item.auditHistory.length > 0 ? (
                        <p>Audit history details would go here.</p>
                    ) : (
                        <p className="text-slate-500 text-center">No audit history recorded for this item.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default function Compliance() {
    const { complianceItems } = useDocuments();
    const [viewingHistory, setViewingHistory] = useState<ComplianceItem | null>(null);

    const getStatusInfo = (status: ComplianceItem['status']) => {
        switch (status) {
            case 'Completed': return { text: 'Completed', color: 'bg-green-500/20 text-green-400' };
            case 'In Progress': return { text: 'In Progress', color: 'bg-yellow-500/20 text-yellow-400' };
            case 'Missing': default: return { text: 'Missing', color: 'bg-red-500/20 text-red-400' };
        }
    }
    
    return (
      <>
        {viewingHistory && <AuditHistoryModal item={viewingHistory} onClose={() => setViewingHistory(null)} />}
        <Card title="ISO 22301 Compliance Tracker">
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Track the status of required documentation for ISO 22301 compliance. This list is based on common templates and mandatory records.</p>
             <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                        <tr>
                            <th className="px-6 py-3">Requirement</th>
                            <th className="px-6 py-3">ISO Clause</th>
                            <th className="px-6 py-3">Status</th>
                            <th className="px-6 py-3">Evidence</th>
                            <th className="px-6 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {complianceItems.map(item => {
                            const statusInfo = getStatusInfo(item.status);
                            return (
                                <tr key={item.id} className="border-b border-slate-700/50 hover:bg-slate-800/40">
                                    <td className="px-6 py-4 font-medium text-slate-200">{item.name}</td>
                                    <td className="px-6 py-4 font-mono">{item.requirement}</td>
                                    <td className="px-6 py-4"><span className={`text-xs font-medium px-2 py-0.5 rounded-full ${statusInfo.color}`}>{statusInfo.text}</span></td>
                                    <td className="px-6 py-4">
                                        {item.linkedDocId ? <a href="#" className="text-cyan-400 hover:underline flex items-center gap-1 text-xs"><DocumentIcon className="w-4 h-4" />View Doc</a> : <span className="text-slate-500 text-xs">Not linked</span>}
                                    </td>
                                    <td className="px-6 py-4 space-x-2">
                                        <button className="text-xs text-cyan-400 hover:underline">Upload</button>
                                        <button onClick={() => setViewingHistory(item)} className="text-xs text-cyan-400 hover:underline">History</button>
                                    </td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
             </div>
        </Card>
      </>
    )
}
