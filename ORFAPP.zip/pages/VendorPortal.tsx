

import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useThirdPartyRisk } from '../context/ThirdPartyRiskContext';
import { useMetadata } from '../context/MetadataContext';
import { Vendor, ThirdPartyAssessmentAnswer } from '../types';
import { FrameworkIcon } from '../components/icons/FrameworkIcon';
import { SpinnerIcon } from '../components/icons/SpinnerIcon';

const AssessmentForm: React.FC<{ vendor: Vendor }> = ({ vendor }) => {
    const { assessmentQuestions, updateVendorAssessment } = useThirdPartyRisk();
    const [answers, setAnswers] = useState<ThirdPartyAssessmentAnswer[]>(vendor.assessments);
    const [isSubmitted, setIsSubmitted] = useState(false);
    
    const { currentCompany } = useMetadata();
    
    const handleAnswerChange = (questionId: string, answer: ThirdPartyAssessmentAnswer['answer'], comment: string = '') => {
        const existing = answers.find(a => a.questionId === questionId);
        if (existing) {
            setAnswers(answers.map(a => a.questionId === questionId ? { ...a, answer, comment } : a));
        } else {
            setAnswers([...answers, { questionId, answer, comment: '' }]);
        }
    };

    const handleSubmit = () => {
        updateVendorAssessment(vendor.id, answers);
        setIsSubmitted(true);
    };
    
    if (isSubmitted) {
        return (
            <div className="text-center p-8 bg-slate-900 rounded-lg">
                <h2 className="text-2xl font-bold text-green-400">Thank You!</h2>
                <p className="text-slate-300 mt-2">Your assessment has been submitted successfully.</p>
                <p className="text-slate-400 text-sm mt-1">You may now close this window.</p>
            </div>
        )
    }

    return (
        <div className="space-y-6">
            <p className="text-slate-400">Please complete the following risk assessment questionnaire for your services provided to <strong className="text-slate-200">{currentCompany?.name}</strong>. Your responses will help us better understand and manage our shared supply chain risk.</p>
            {assessmentQuestions.map(q => (
                <div key={q.id} className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                    <p className="font-semibold text-slate-200">{q.id}. {q.text}</p>
                    <div className="flex flex-wrap gap-4 mt-3">
                        {(['Yes', 'No', 'Partial', 'N/A'] as const).map(opt => (
                            <label key={opt} className="flex items-center gap-2 text-sm text-slate-300">
                                <input 
                                    type="radio" 
                                    name={`q-${q.id}`} 
                                    value={opt} 
                                    checked={answers.find(a => a.questionId === q.id)?.answer === opt} 
                                    onChange={() => handleAnswerChange(q.id, opt)} 
                                    className="h-4 w-4 text-cyan-500 bg-slate-700 border-slate-600 focus:ring-cyan-600" 
                                />
                                {opt}
                            </label>
                        ))}
                    </div>
                    <textarea 
                        value={answers.find(a => a.questionId === q.id)?.comment || ''}
                        onChange={(e) => handleAnswerChange(q.id, answers.find(a=>a.questionId===q.id)?.answer || 'N/A', e.target.value)}
                        placeholder="Optional comment..." 
                        rows={2} 
                        className="w-full bg-slate-700 p-2 rounded-md mt-3 text-sm border-slate-600 focus:ring-cyan-500 focus:border-cyan-500"
                    />
                </div>
            ))}
            <div className="text-right pt-4">
                <button onClick={handleSubmit} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-6 rounded-lg text-lg">
                    Submit Assessment
                </button>
            </div>
        </div>
    );
};


export default function VendorPortal() {
    const { vendorId, accessKey } = useParams();
    const { vendors } = useThirdPartyRisk();
    const { currentCompany } = useMetadata(); // This context will be tied to the app owner, which is what we want.

    const [vendor, setVendor] = useState<Vendor | null | undefined>(undefined); // undefined: loading, null: not found

    useEffect(() => {
        if (vendors.length > 0 && vendorId) {
            const foundVendor = vendors.find(v => v.id === vendorId);
            if (foundVendor && foundVendor.accessKey === accessKey) {
                setVendor(foundVendor);
            } else {
                setVendor(null); // Invalid link or key
            }
        }
    }, [vendors, vendorId, accessKey]);

    // Initial loading state
    if (vendor === undefined || !currentCompany) {
        return (
            <div className="flex items-center justify-center h-screen bg-slate-900">
                <SpinnerIcon className="w-12 h-12 animate-spin text-cyan-400" />
            </div>
        );
    }
    
    // Invalid link state
    if (!vendor) {
        return (
             <div className="flex flex-col items-center justify-center h-screen bg-slate-900 text-center p-4">
                 <FrameworkIcon className="h-16 w-16 mx-auto text-red-500" />
                <h1 className="text-3xl font-bold mt-4 text-red-400">Access Denied</h1>
                <p className="text-slate-400 mt-2">The link you have used is invalid or has expired. Please contact your administrator.</p>
            </div>
        );
    }

    // Valid portal view
    return (
        <div className="min-h-screen bg-slate-900 p-4 md:p-8 text-slate-300">
            <div className="max-w-4xl mx-auto">
                <header className="flex items-center gap-4 mb-8">
                    {currentCompany.logoUrl ? (
                         <img src={currentCompany.logoUrl} alt={`${currentCompany.name} logo`} className="h-16"/>
                    ) : (
                         <FrameworkIcon className="h-16 w-16 text-cyan-400"/>
                    )}
                   <div>
                        <p className="text-slate-400 text-sm">Vendor Portal</p>
                        <h1 className="text-3xl font-bold text-slate-100">{currentCompany.name}</h1>
                   </div>
                </header>
                
                <main className="bg-slate-800 border border-slate-700 rounded-xl p-6 md:p-8">
                    <h2 className="text-2xl font-bold text-cyan-400 mb-2">Third-Party Risk Assessment</h2>
                    <p className="text-lg text-slate-300">for <strong className="font-semibold">{vendor.name}</strong></p>
                    <hr className="my-6 border-slate-700" />
                    <AssessmentForm vendor={vendor} />
                </main>
                 <footer className="text-center text-xs text-slate-600 mt-8">
                    <p>Powered by Open Resilience</p>
                </footer>
            </div>
        </div>
    );
}