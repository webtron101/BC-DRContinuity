import React, { useMemo, useState } from 'react';
import Card from '../components/Card';
import { RiskLevel, Document, Rehearsal, ComplianceItem } from '../types';
import { RehearsalIcon } from '../components/icons/RehearsalIcon';
import { useMetadata } from '../context/MetadataContext';
import { useRisks } from '../context/RisksContext';
import { useRehearsals } from '../context/RehearsalsContext';
import { useDocuments } from '../context/DocumentsContext';
import PlanPreviewModal from '../components/PlanPreviewModal';
import { useBIA } from '../context/BIAContext';


function FinancialRiskCard() {
    const { currentCompany } = useMetadata();
    const financialRisk = currentCompany?.financialRiskZAR || 0;
    
    const formatter = new Intl.NumberFormat('en-ZA', {
        style: 'currency',
        currency: 'ZAR',
        maximumFractionDigits: 0,
    });

    return (
        <div className="flex flex-col items-center justify-center h-full text-center">
            <p className="text-5xl font-bold text-orange-500 dark:text-orange-400">{formatter.format(financialRisk)}</p>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">Total Financial Value at Risk</p>
            <p className="mt-1 text-xs text-slate-500">Based on BIA & Risk Register analysis</p>
        </div>
    );
}

function ComplianceStatus() {
    const { complianceItems } = useDocuments();
    
    const completed = complianceItems.filter(item => item.status === 'Completed').length;
    const total = complianceItems.length;

    const compliancePercentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    
    return (
        <div className="flex flex-col items-center justify-center h-full text-center">
             <p className="text-5xl font-bold text-green-600 dark:text-green-400">{compliancePercentage}%</p>
             <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">Compliance Posture</p>
             <p className="mt-1 text-xs text-slate-500">{completed} of {total} ISO 22301 items completed</p>
        </div>
    );
}


function UpcomingRehearsals() {
    const { rehearsals } = useRehearsals();
    const upcoming = rehearsals.filter(t => t.status === 'Planned' && new Date(t.startDate) > new Date()).slice(0, 3);

    return (
         <div className="space-y-3 h-full flex flex-col justify-center">
            {upcoming.length > 0 ? upcoming.map(rehearsal => (
                <div key={rehearsal.id} className="flex items-center gap-3 p-2 bg-slate-100 dark:bg-slate-700/50 rounded-lg">
                    <RehearsalIcon className="w-5 h-5 text-cyan-500 dark:text-cyan-400 flex-shrink-0" />
                    <div>
                        <p className="font-semibold text-sm text-slate-800 dark:text-slate-200">{rehearsal.name}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{rehearsal.type} - {rehearsal.startDate}</p>
                    </div>
                </div>
            )) : <p className="text-sm text-slate-500 text-center">No upcoming rehearsals scheduled.</p>}
        </div>
    );
}

function RecoveryReadiness() {
    const { documents } = useDocuments();
    const readinessData = useMemo(() => {
        const statuses: Record<string, number> = { 'Approved': 0, 'In Review': 0, 'Draft': 0 };
        documents.filter(d => ['DRP', 'BCM Plan'].includes(d.type)).forEach(doc => {
            if (doc.status in statuses) {
                statuses[doc.status]++;
            }
        });
        return Object.entries(statuses).map(([name, value]) => ({ name, value }));
    }, [documents]);
    
    const colors: Record<string, string> = { 'Approved': 'fill-green-500', 'In Review': 'fill-yellow-500', 'Draft': 'fill-blue-500' };

    return (
        <div className="h-full flex flex-col justify-end">
            <div className="flex items-end justify-around h-full gap-4 pt-4">
                {readinessData.map(item => (
                    <div key={item.name} className="flex flex-col items-center flex-1">
                        <div className={`w-full ${colors[item.name]} rounded-t-md hover:opacity-80 transition-opacity`} style={{ height: `${item.value * 20 + 5}px` }} title={`${item.name}: ${item.value}`}>
                           <span className="text-white font-bold text-center block pt-1">{item.value > 0 ? item.value : ''}</span>
                        </div>
                    </div>
                ))}
            </div>
            <div className="flex items-center justify-around text-xs text-slate-600 dark:text-slate-400 border-t border-slate-200 dark:border-slate-600 mt-2 pt-1">
                {readinessData.map(item => <span key={item.name}>{item.name}</span>)}
            </div>
        </div>
    );
}

function TopRisks() {
    const { risks } = useRisks();
    const topRisks = useMemo(() => {
        return (risks || [])
            .sort((a, b) => b.riskScore - a.riskScore)
            .slice(0, 3);
    }, [risks]);

    return (
        <div className="space-y-4 h-full flex flex-col justify-center">
            {topRisks.map(risk => (
                <div key={risk.id}>
                    <div className="flex justify-between text-sm mb-1">
                        <span className="font-semibold text-slate-700 dark:text-slate-300 truncate pr-2">{risk.title}</span>
                        <span className="font-bold text-red-500 dark:text-red-400">{risk.riskScore}</span>
                    </div>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5">
                        <div className="bg-red-600 h-2.5 rounded-full" style={{ width: `${(risk.riskScore / 25) * 100}%` }}></div>
                    </div>
                </div>
            ))}
        </div>
    );
}

function QuickReports({ setPreviewContent, setPreviewTitle }: { setPreviewContent: (c: string) => void, setPreviewTitle: (t: string) => void}) {
    const { currentCompany } = useMetadata();
    const { businessUnits, processes } = useBIA();
    const { risks } = useRisks();
    const { complianceItems } = useDocuments();

    const generateBiaHtml = () => {
        if (!currentCompany) return '';
        const businessUnitMap = new Map(businessUnits.map(bu => [bu.id, bu.name]));
        const processesHtml = processes.map(p => `
            <tr>
                <td style="padding: 8px; border: 1px solid #4A5568;">${p.name}</td>
                <td style="padding: 8px; border: 1px solid #4A5568;">${businessUnitMap.get(p.unitId)}</td>
                <td style="padding: 8px; border: 1px solid #4A5568;">${p.rto}</td>
                <td style="padding: 8px; border: 1px solid #4A5568;">${p.rpo}</td>
                <td style="padding: 8px; border: 1px solid #4A5568;">${RiskLevel[p.criticality]}</td>
            </tr>
        `).join('');
        return `<h1>BIA Summary for ${currentCompany.name}</h1>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead><tr><th>Process</th><th>Unit</th><th>RTO</th><th>RPO</th><th>Criticality</th></tr></thead>
                    <tbody>${processesHtml}</tbody>
                </table>`;
    }

    const generateRiskHtml = () => {
         if (!currentCompany) return '';
        const risksHtml = risks.map(r => `
            <tr>
                <td style="padding: 8px; border: 1px solid #4A5568;">${r.title}</td>
                <td style="padding: 8px; border: 1px solid #4A5568;">${r.category}</td>
                <td style="padding: 8px; border: 1px solid #4A5568;">${r.riskScore}</td>
                <td style="padding: 8px; border: 1px solid #4A5568;">${RiskLevel[r.level]}</td>
            </tr>
        `).join('');
        return `<h1>Risk Register for ${currentCompany.name}</h1>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead><tr><th>Risk</th><th>Category</th><th>Score</th><th>Level</th></tr></thead>
                    <tbody>${risksHtml}</tbody>
                </table>`;
    }

    const generateComplianceHtml = () => {
        if (!currentCompany) return '';
        const itemsHtml = complianceItems.map(item => `
            <tr>
                <td style="padding: 8px; border: 1px solid #CBD5E0;">${item.name}</td>
                <td style="padding: 8px; border: 1px solid #CBD5E0;">${item.requirement}</td>
                <td style="padding: 8px; border: 1px solid #CBD5E0;">${item.status}</td>
                <td style="padding: 8px; border: 1px solid #CBD5E0;">${item.progress}%</td>
            </tr>
        `).join('');
        return `
            <style>
                table { width: 100%; border-collapse: collapse; font-family: sans-serif; }
                th, td { padding: 8px; border: 1px solid #e2e8f0; text-align: left; }
                th { background-color: #f1f5f9; }
                h1 { font-family: sans-serif; color: #1e293b; }
            </style>
            <h1>ISO 22301 Compliance Matrix for ${currentCompany.name}</h1>
            <table>
                <thead>
                    <tr>
                        <th>Requirement</th>
                        <th>Clause</th>
                        <th>Status</th>
                        <th>Progress</th>
                    </tr>
                </thead>
                <tbody>${itemsHtml}</tbody>
            </table>`;
    };

    const handleGenerate = (type: 'bia' | 'risk' | 'compliance') => {
        if (type === 'bia') {
            setPreviewContent(generateBiaHtml());
            setPreviewTitle('BIA Summary Report');
        } else if (type === 'risk') {
            setPreviewContent(generateRiskHtml());
            setPreviewTitle('Risk Register Report');
        } else if (type === 'compliance') {
            setPreviewContent(generateComplianceHtml());
            setPreviewTitle('Compliance Matrix Report');
        }
    }

    return (
        <div className="space-y-3 flex flex-col justify-center h-full">
            <button onClick={() => handleGenerate('bia')} className="text-sm bg-slate-100 dark:bg-slate-700/50 hover:bg-slate-200 dark:hover:bg-slate-700 p-2 rounded-lg text-left">Generate BIA Summary PDF</button>
            <button onClick={() => handleGenerate('risk')} className="text-sm bg-slate-100 dark:bg-slate-700/50 hover:bg-slate-200 dark:hover:bg-slate-700 p-2 rounded-lg text-left">Export Full Risk Register</button>
            <button onClick={() => handleGenerate('compliance')} className="text-sm bg-slate-100 dark:bg-slate-700/50 hover:bg-slate-200 dark:hover:bg-slate-700 p-2 rounded-lg text-left">Export Compliance Matrix</button>
        </div>
    );
}

export default function Dashboard() {
    const { currentCompany } = useMetadata();
    const [previewContent, setPreviewContent] = useState<string | null>(null);
    const [previewTitle, setPreviewTitle] = useState('');
    
    if (!currentCompany) {
        return <div className="text-center p-8">Loading company data...</div>;
    }

    const maturityScore = useMemo(() => {
        if (!currentCompany.resilienceFramework?.length) return 0;
        const totalProgress = currentCompany.resilienceFramework.reduce((sum, phase) => sum + phase.progress, 0);
        return Math.round(totalProgress / currentCompany.resilienceFramework.length);
    }, [currentCompany.resilienceFramework]);

    return (
        <>
        {previewContent && <PlanPreviewModal title={previewTitle} content={previewContent} onClose={() => setPreviewContent(null)} />}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-3 gap-6">
            <Card title="BCM Program Maturity" className="xl:col-span-1">
                <div className="flex items-center justify-center h-full">
                    <div className="relative">
                        <svg className="w-32 h-32" viewBox="0 0 100 100">
                            <circle className="text-slate-200 dark:text-slate-700" strokeWidth="10" stroke="currentColor" fill="transparent" r="45" cx="50" cy="50" />
                            <circle className="text-cyan-500 dark:text-cyan-400" strokeWidth="10" strokeDasharray="283" strokeDashoffset={283 - (maturityScore/100 * 283)} strokeLinecap="round" stroke="currentColor" fill="transparent" r="45" cx="50" cy="50" transform="rotate(-90 50 50)" />
                        </svg>
                        <span className="absolute inset-0 flex items-center justify-center text-3xl font-bold text-slate-800 dark:text-slate-100">{maturityScore}%</span>
                    </div>
                </div>
            </Card>
            
            <Card title="DR Plan Readiness" className="xl:col-span-1">
                 <RecoveryReadiness />
            </Card>
            
            <Card title="Compliance Posture" className="xl:col-span-1">
                <ComplianceStatus />
            </Card>
            
            <Card title="Active Risks" className="md:col-span-1 lg:col-span-2 xl:col-span-1">
                <TopRisks />
            </Card>

             <Card title="Upcoming Rehearsals" className="md:col-span-1 lg:col-span-2 xl:col-span-1">
                <UpcomingRehearsals />
            </Card>
            
             <Card title="Quick Reports" className="md:col-span-2 lg:col-span-4 xl:col-span-1">
                <QuickReports setPreviewContent={setPreviewContent} setPreviewTitle={setPreviewTitle} />
            </Card>
        </div>
        </>
    );
};