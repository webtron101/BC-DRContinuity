
import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { RiskLevel, ITAsset, BusinessUnit, Process, RTOPeriod, RPOPeriod, VitalRecord } from '../types';
import { useBIA } from '../context/BIAContext';
import { useIT } from '../context/ITContext';
import { useMetadata } from '../context/MetadataContext';
import { CloseIcon } from '../components/icons/CloseIcon';
import { TrashIcon } from '../components/icons/TrashIcon';
import { EditIcon } from '../components/icons/EditIcon';

const RTO_PERIODS: RTOPeriod[] = ['N/A', '< 1 Hour', '1-4 Hours', '4-8 Hours', '8-12 Hours', '12-24 Hours', '1-2 Days', '3-4 Days', '5-7 Days', '> 1 Week'];
const RPO_PERIODS: RPOPeriod[] = ['N/A', 'Zero / Synchronous', '< 15 minutes', '15 - 60 minutes', '1 - 4 hours', '4 - 12 hours', '12 - 24 hours'];

const getRiskColor = (level: RiskLevel) => {
    switch (level) {
        case RiskLevel.Critical: return 'text-red-400 border-red-400';
        case RiskLevel.High: return 'text-orange-400 border-orange-400';
        case RiskLevel.Medium: return 'text-yellow-400 border-yellow-400';
        default: return 'text-green-400 border-green-400';
    }
};


// MODALS
const UnitModal: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (data: Omit<BusinessUnit, 'id'>) => void }> = ({ isOpen, onClose, onSave }) => {
    const [name, setName] = useState('');
    const [functionalOwner, setFunctionalOwner] = useState('');
    const [description, setDescription] = useState('');
    const [headcount, setHeadcount] = useState(0);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ name, functionalOwner, description, headcount });
        onClose(); setName(''); setFunctionalOwner(''); setDescription(''); setHeadcount(0);
    };
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                     <h3 className="text-lg font-semibold">Add Business Unit</h3>
                    <input value={name} onChange={e => setName(e.target.value)} required placeholder="Business Unit Name" className="w-full bg-slate-700 p-2 rounded-md" />
                    <input value={functionalOwner} onChange={e => setFunctionalOwner(e.target.value)} required placeholder="Functional Owner (e.g., CFO)" className="w-full bg-slate-700 p-2 rounded-md" />
                    <input type="number" value={headcount} onChange={e => setHeadcount(Number(e.target.value))} required placeholder="Headcount" className="w-full bg-slate-700 p-2 rounded-md" />
                    <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Description" rows={3} className="w-full bg-slate-700 p-2 rounded-md" />
                    <div className="text-right pt-4"><button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg">Save Unit</button></div>
                </form>
            </div>
        </div>
    );
};

const ProcessModal: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (data: Omit<Process, 'id' | 'linkedSystemIds' | 'vitalRecords' | 'manualDependencies'>) => void, unitId: string }> = ({ isOpen, onClose, onSave, unitId }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [rto, setRto] = useState<RTOPeriod>('4-8 Hours');
    const [rpo, setRpo] = useState<RPOPeriod>('12 - 24 hours');
    const [criticality, setCriticality] = useState<RiskLevel>(RiskLevel.Medium);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ name, description, rto, rpo, criticality, unitId });
        onClose(); setName(''); setDescription('');
    };

    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                     <h3 className="text-lg font-semibold">Add Process</h3>
                    <input value={name} onChange={e => setName(e.target.value)} required placeholder="Process Name" className="w-full bg-slate-700 p-2 rounded-md" />
                    <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Description" rows={3} className="w-full bg-slate-700 p-2 rounded-md" />
                    <select value={rto} onChange={e => setRto(e.target.value as RTOPeriod)} className="w-full bg-slate-700 p-2 rounded-md"><option disabled>RTO</option>{RTO_PERIODS.map(p => <option key={p} value={p}>{p}</option>)}</select>
                    <select value={rpo} onChange={e => setRpo(e.target.value as RPOPeriod)} className="w-full bg-slate-700 p-2 rounded-md"><option disabled>RPO</option>{RPO_PERIODS.map(p => <option key={p} value={p}>{p}</option>)}</select>
                    <select value={criticality} onChange={e => setCriticality(Number(e.target.value))} className="w-full bg-slate-700 p-2 rounded-md"><option disabled>Criticality</option>{Object.keys(RiskLevel).filter(k=>!isNaN(Number(k))).map(k => <option key={k} value={k}>{RiskLevel[Number(k)]}</option>)}</select>
                    <div className="text-right pt-4"><button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg">Save Process</button></div>
                </form>
            </div>
        </div>
    );
};

const SystemModal: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (assetData: Omit<ITAsset, 'id'>) => void }> = ({ isOpen, onClose, onSave }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState(''); // Purpose
    const [type, setType] = useState<ITAsset['type']>('Application');
    const [rto, setRto] = useState<RTOPeriod>('4-8 Hours');
    const [rpo, setRpo] = useState<RPOPeriod>('12 - 24 hours');
    const [riskRating, setRiskRating] = useState<RiskLevel>(RiskLevel.Medium);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            name, description, type, rto, rpo, riskRating,
            siteId: 's1-site4', // Mock data
            dependencies: [],
            owner: 'System Owner',
            resilienceStatus: 'Not Resilient',
            vulnerabilities: []
        });
        onClose();
    };

    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <h3 className="text-lg font-semibold">Add New System</h3>
                    <input value={name} onChange={e => setName(e.target.value)} required placeholder="System Name (e.g., Core Banking App)" className="w-full bg-slate-700 p-2 rounded-md" />
                    <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Purpose" rows={2} className="w-full bg-slate-700 p-2 rounded-md" />
                    <select value={type} onChange={e => setType(e.target.value as any)} className="w-full bg-slate-700 p-2 rounded-md"><option>Application</option><option>Server (Virtual)</option><option>Database</option></select>
                    <select value={rto} onChange={e => setRto(e.target.value as any)} className="w-full bg-slate-700 p-2 rounded-md">{RTO_PERIODS.map(p=><option key={p} value={p}>{p}</option>)}</select>
                    <select value={rpo} onChange={e => setRpo(e.target.value as any)} className="w-full bg-slate-700 p-2 rounded-md">{RPO_PERIODS.map(p=><option key={p} value={p}>{p}</option>)}</select>
                    <select value={riskRating} onChange={e => setRiskRating(Number(e.target.value))} className="w-full bg-slate-700 p-2 rounded-md">{Object.keys(RiskLevel).filter(k=>!isNaN(Number(k))).map(k=><option key={k} value={k}>{RiskLevel[Number(k)]}</option>)}</select>
                    <div className="text-right pt-4"><button type="submit" className="bg-cyan-600 px-4 py-2 rounded-lg">Save System</button></div>
                </form>
            </div>
        </div>
    );
};

// Main Component
export default function BIA() {
    const { businessUnits, processes, addBusinessUnit, addProcess, updateProcess } = useBIA();
    const { itAssets, addITAsset } = useIT();
    const [selectedProcessId, setSelectedProcessId] = useState<string | null>(null);

    // Modal states
    const [modals, setModals] = useState({ unit: false, process: false, system: false });
    const [activeUnitId, setActiveUnitId] = useState<string|null>(null);

    const selectedProcess = useMemo(() => processes.find(p => p.id === selectedProcessId), [processes, selectedProcessId]);
    const linkedSystems = useMemo(() => itAssets.filter(asset => selectedProcess?.linkedSystemIds.includes(asset.id)), [itAssets, selectedProcess]);
    
    const handleSaveUnit = (unitData: Omit<BusinessUnit, 'id'>) => { addBusinessUnit(unitData); setModals({ ...modals, unit: false }); };
    const handleSaveProcess = (processData: Omit<Process, 'id'>) => { addProcess({ ...processData, linkedSystemIds:[], vitalRecords: [], manualDependencies:''}); setModals({ ...modals, process: false }); };
    const handleSaveSystem = (assetData: Omit<ITAsset, 'id'>) => {
        const newId = `asset-${Date.now()}`;
        addITAsset({ ...assetData, id: newId });
        if(selectedProcess) {
            updateProcess(selectedProcess.id, { linkedSystemIds: [...selectedProcess.linkedSystemIds, newId] });
        }
        setModals({ ...modals, system: false });
    };

    const handleSaveVitalRecord = (recordData: Omit<VitalRecord, 'id'>) => {
        if (!selectedProcess) return;
        const newRecord = { ...recordData, id: `vr-${Date.now()}` };
        const updatedRecords = [...selectedProcess.vitalRecords, newRecord];
        updateProcess(selectedProcess.id, { vitalRecords: updatedRecords });
    }

    const handleDeleteVitalRecord = (recordId: string) => {
        if (!selectedProcess) return;
        const updatedRecords = selectedProcess.vitalRecords.filter(vr => vr.id !== recordId);
        updateProcess(selectedProcess.id, { vitalRecords: updatedRecords });
    }

    return (
        <>
            <UnitModal isOpen={modals.unit} onClose={() => setModals({...modals, unit: false})} onSave={handleSaveUnit} />
            {activeUnitId && <ProcessModal isOpen={modals.process} onClose={() => setModals({...modals, process: false})} onSave={handleSaveProcess} unitId={activeUnitId} />}
            <SystemModal isOpen={modals.system} onClose={() => setModals({...modals, system: false})} onSave={handleSaveSystem} />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-128px)]">
                {/* Left Pane: Hierarchy */}
                <div className="lg:col-span-1 flex flex-col gap-4">
                    <Card title="Business Impact Analysis" className="flex-grow flex flex-col">
                        <div className="mb-4 text-right">
                            <button onClick={() => setModals({ ...modals, unit: true })} className="bg-cyan-600 text-white font-semibold py-1.5 px-4 rounded-lg text-sm">Add Business Unit</button>
                        </div>
                        <div className="flex-grow overflow-y-auto pr-2">
                            {businessUnits.map(unit => (
                                <div key={unit.id} className="mb-4">
                                    <div className="flex justify-between items-center bg-slate-800/50 p-3 rounded-t-lg">
                                        <h3 className="font-semibold text-slate-200">{unit.name}</h3>
                                        <button onClick={() => { setActiveUnitId(unit.id); setModals({ ...modals, process: true }); }} className="text-cyan-400 text-xs hover:underline">Add Process</button>
                                    </div>
                                    <div className="bg-slate-900/30 p-2 rounded-b-lg">
                                        {processes.filter(p => p.unitId === unit.id).map(proc => (
                                            <button key={proc.id} onClick={() => setSelectedProcessId(proc.id)} className={`w-full text-left p-2 rounded-md text-sm ${selectedProcessId === proc.id ? 'bg-cyan-500/20 text-cyan-300' : 'hover:bg-slate-700/50 text-slate-400'}`}>
                                                {proc.name}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </Card>
                </div>

                {/* Right Pane: Details */}
                <div className="lg:col-span-2 flex flex-col gap-4 overflow-y-auto pr-2">
                    {selectedProcess ? (
                        <>
                            <Card title={`Process: ${selectedProcess.name}`}>
                                <div className="grid grid-cols-3 gap-4 text-center">
                                    <div><p className="text-xs text-slate-500">RTO</p><p className="text-xl font-bold text-cyan-400">{selectedProcess.rto}</p></div>
                                    <div><p className="text-xs text-slate-500">RPO</p><p className="text-xl font-bold text-cyan-400">{selectedProcess.rpo}</p></div>
                                    <div><p className="text-xs text-slate-500">Criticality</p><p className={`text-xl font-bold ${getRiskColor(selectedProcess.criticality)}`}>{RiskLevel[selectedProcess.criticality]}</p></div>
                                </div>
                            </Card>
                             <Card title="Supporting Systems">
                                <div className="text-right mb-4"><button onClick={() => setModals({...modals, system: true})} className="bg-cyan-700 text-white font-semibold py-1 px-3 rounded-lg text-xs">Add New System</button></div>
                                <div className="space-y-2">
                                    {linkedSystems.map(sys => (
                                        <div key={sys.id} className="bg-slate-800/50 p-3 rounded-md">
                                            <p className="font-semibold text-slate-200">{sys.name} <span className="text-xs text-slate-500">({sys.type})</span></p>
                                            <p className="text-xs text-slate-400">{sys.description}</p>
                                        </div>
                                    ))}
                                </div>
                            </Card>
                            <Card title="Vital Records">
                                <div className="space-y-2">
                                {selectedProcess.vitalRecords.map(vr => (
                                    <div key={vr.id} className="flex justify-between items-start bg-slate-800/50 p-3 rounded-md">
                                        <div>
                                            <p className="font-semibold text-slate-200">{vr.name}</p>
                                            <p className="text-xs text-slate-400">Location: {vr.location}</p>
                                        </div>
                                        <button onClick={() => handleDeleteVitalRecord(vr.id)} className="text-slate-500 hover:text-red-400"><TrashIcon className="w-4 h-4"/></button>
                                    </div>
                                ))}
                                </div>
                                 <VitalRecordForm onSave={handleSaveVitalRecord} />
                            </Card>
                             <Card title="Other Dependencies">
                                <textarea
                                    value={selectedProcess.manualDependencies}
                                    onChange={(e) => updateProcess(selectedProcess.id, { manualDependencies: e.target.value })}
                                    rows={4}
                                    className="w-full bg-slate-800/50 p-2 rounded-md text-sm"
                                    placeholder="Describe any other dependencies..."
                                />
                            </Card>
                        </>
                    ) : (
                        <div className="flex items-center justify-center h-full">
                            <p className="text-slate-500">Select a process to view its details</p>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
}

const VitalRecordForm: React.FC<{onSave: (data: Omit<VitalRecord, 'id'>)=>void}> = ({onSave}) => {
    const [name, setName] = useState('');
    const [location, setLocation] = useState('');
    const [isEditing, setIsEditing] = useState(false);

    const handleSave = () => {
        if (!name || !location) return;
        onSave({ name, location });
        setName(''); setLocation(''); setIsEditing(false);
    }

    if (!isEditing) {
        return <button onClick={() => setIsEditing(true)} className="text-cyan-400 text-xs hover:underline mt-4">+ Add Vital Record</button>
    }

    return (
        <div className="mt-4 p-3 bg-slate-900/50 rounded-lg space-y-2">
            <input value={name} onChange={e => setName(e.target.value)} placeholder="Record Name" className="w-full bg-slate-700 p-2 rounded-md text-sm"/>
            <input value={location} onChange={e => setLocation(e.target.value)} placeholder="Location (e.g., path, vault)" className="w-full bg-slate-700 p-2 rounded-md text-sm"/>
            <div className="flex justify-end gap-2">
                <button onClick={() => setIsEditing(false)} className="text-xs bg-slate-600 px-2 py-1 rounded">Cancel</button>
                <button onClick={handleSave} className="text-xs bg-cyan-600 px-2 py-1 rounded">Save</button>
            </div>
        </div>
    )
}
