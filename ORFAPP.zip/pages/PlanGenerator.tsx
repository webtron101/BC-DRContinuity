
import React from 'react';
import Card from '../components/Card';

export default function PlanGenerator() {
  return (
    <Card title="Plan Generator [DEPRECATED]">
      <p className="text-slate-400">This page is no longer in use. Please use the features within the "Documents" page.</p>
    </Card>
  );
}
