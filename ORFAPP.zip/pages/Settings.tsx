

import React, { useState } from 'react';
import Card from '../components/Card';
import { useMetadata } from '../context/MetadataContext';
import { mockServiceDefinition } from '../data/mockData';
import { CheckCircleIcon } from '../components/icons/CheckCircleIcon';
import { CloseIcon } from '../components/icons/CloseIcon';
import { NotifyUser } from '../types';
import { useGovernance } from '../context/GovernanceContext';
import { useAssignments } from '../context/AssignmentsContext';
import { useRisks } from '../context/RisksContext';
import { useDocuments } from '../context/DocumentsContext';
import { useBIA } from '../context/BIAContext';
import { useIT } from '../context/ITContext';
import { useThirdPartyRisk } from '../context/ThirdPartyRiskContext';
import { useRehearsals } from '../context/RehearsalsContext';

const TABS = ['User Management', 'System & API Settings', 'Data Management', 'Add-ons', 'Service Definition'];

const NewUserModal: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (user: Omit<NotifyUser, 'id'>) => void }> = ({ isOpen, onClose, onSave }) => {
    const [name, setName] = useState('');
    const [role, setRole] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    
    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ name, role, email, phone });
        onClose();
        setName(''); setRole(''); setEmail(''); setPhone('');
    };
    
    return (
         <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <div className="flex justify-between items-center -mt-2 -mx-2 mb-4">
                        <h3 className="text-lg font-semibold">Add New User</h3>
                        <button type="button" onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                    </div>
                    <input value={name} onChange={e => setName(e.target.value)} required placeholder="Full Name" className="w-full bg-slate-700 p-2 rounded-md" />
                    <input value={role} onChange={e => setRole(e.target.value)} required placeholder="Role / Title" className="w-full bg-slate-700 p-2 rounded-md" />
                    <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="Email Address" className="w-full bg-slate-700 p-2 rounded-md" />
                    <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} required placeholder="Phone Number" className="w-full bg-slate-700 p-2 rounded-md" />
                    <div className="text-right pt-4"><button type="submit" className="bg-cyan-600 px-4 py-2 rounded-lg">Save User</button></div>
                </form>
            </div>
        </div>
    );
};


const UserManagementView: React.FC = () => {
    const { notifyUsers } = useGovernance(); // Governance context holds the users
    const [isModalOpen, setIsModalOpen] = useState(false);
    
    const handleSaveUser = (user: Omit<NotifyUser, 'id'>) => {
        // In a real app this would call a context function to add the user
        alert(`User ${user.name} added. (This is a mock action)`);
    }

    return (
        <>
            <NewUserModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleSaveUser} />
            <Card title="User Management">
                <div className="flex justify-end mb-4">
                    <button onClick={() => setIsModalOpen(true)} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-1.5 px-4 rounded-lg text-sm">Add New User</button>
                </div>
                <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                        <tr>
                            <th className="px-6 py-3">Name</th>
                            <th className="px-6 py-3">Role</th>
                            <th className="px-6 py-3">Email / Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        {notifyUsers.map(user => (
                            <tr key={user.id} className="border-b border-slate-700/50">
                                <td className="px-6 py-4 font-medium text-slate-200">{user.name}</td>
                                <td className="px-6 py-4">{user.role}</td>
                                <td className="px-6 py-4">{user.email} / {user.phone}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </Card>
        </>
    );
};

const SystemSettingsView: React.FC = () => {
    return (
        <Card title="API & System Settings">
            <div className="space-y-6">
                <div>
                    <h4 className="text-lg font-semibold text-cyan-400 mb-2">Gemini API</h4>
                    <label className="block text-sm font-medium text-slate-300 mb-1">API Key</label>
                    <div className="flex items-center gap-2">
                         <input type="password" value="******************" readOnly className="w-full md:w-1/2 bg-slate-700 p-2 rounded-md font-mono" />
                         <span className="text-xs text-green-400">Connected</span>
                    </div>
                     <p className="text-xs text-slate-500 mt-1">The Gemini API key is managed via environment variables and is connected.</p>
                </div>
            </div>
        </Card>
    );
};

const DataManagementView: React.FC = () => {
    const { currentCompany } = useMetadata();
    const { assignments } = useAssignments();
    const { risks } = useRisks();
    const { documents, complianceItems, documentTemplates, notificationTemplates, statementOfApplicability } = useDocuments();
    const { businessUnits, processes, services } = useBIA();
    const { itAssets, networks, battleboxItems } = useIT();
    const { vendors, suppliedServices } = useThirdPartyRisk();
    const { rehearsals, scenarios } = useRehearsals();
    const { bcmRoles, bcmStrategies, governanceControls, pciDssRequirements, blockedThreats, notifyUsers } = useGovernance();

    const handleExport = () => {
        const allData = {
            companyProfile: currentCompany,
            assignments,
            risks,
            documents,
            complianceItems,
            documentTemplates,
            notificationTemplates,
            statementOfApplicability,
            businessUnits,
            processes,
            services,
            itAssets,
            networks,
            battleboxItems,
            vendors,
            suppliedServices,
            rehearsals,
            scenarios,
            bcmRoles,
            bcmStrategies,
            governanceControls,
            pciDssRequirements,
            blockedThreats,
            notifyUsers
        };

        const jsonString = JSON.stringify(allData, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'open-resilience-data-export.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    return (
        <Card title="Data Management">
            <div className="space-y-6">
                <div>
                    <h4 className="text-lg font-semibold text-cyan-400 mb-2">Export Data</h4>
                    <p className="text-sm text-slate-400 mb-4">Export all of your company's data into a single JSON file. This is useful for backups, migrating to a self-hosted instance, or for external analysis.</p>
                    <button 
                        onClick={handleExport}
                        className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg text-sm">
                        Export All Data
                    </button>
                </div>
                 <div>
                    <h4 className="text-lg font-semibold text-cyan-400 mb-2">Import Data</h4>
                    <p className="text-sm text-slate-400 mb-4">Import data from a previously exported JSON file. This will overwrite all existing data for the current company. Please be careful.</p>
                    <button 
                        className="bg-slate-600 text-white font-semibold py-2 px-4 rounded-lg text-sm disabled:opacity-50 cursor-not-allowed"
                        disabled>
                        Import from File (Coming Soon)
                    </button>
                </div>
            </div>
        </Card>
    );
};

const AddonsView: React.FC = () => {
    return (
        <Card title="Manage Add-ons">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-800/50 p-4 rounded-lg flex justify-between items-center">
                    <div>
                        <h4 className="font-semibold text-slate-200">GeoRisk Module</h4>
                        <p className="text-sm text-slate-400">Live threat feeds on an interactive map.</p>
                    </div>
                    <div className="w-12 h-6 flex items-center bg-green-500 rounded-full p-1 cursor-pointer">
                        <div className="bg-white w-4 h-4 rounded-full shadow-md transform translate-x-6"></div>
                    </div>
                </div>
                 <div className="bg-slate-800/50 p-4 rounded-lg flex justify-between items-center">
                    <div>
                        <h4 className="font-semibold text-slate-200">Mass Notification Module</h4>
                        <p className="text-sm text-slate-400">Send alerts via SMS, WhatsApp, etc.</p>
                    </div>
                    <div className="w-12 h-6 flex items-center bg-green-500 rounded-full p-1 cursor-pointer">
                        <div className="bg-white w-4 h-4 rounded-full shadow-md transform translate-x-6"></div>
                    </div>
                </div>
            </div>
        </Card>
    );
};

const ServiceDefinitionView: React.FC = () => {
    const modules = mockServiceDefinition;

    return (
        <div className="space-y-6">
            <Card title="Service Overview">
                <p className="text-slate-400">
                    Open Resilience is a comprehensive Software-as-a-Service (SaaS) platform designed to help organizations build, manage, and maintain a robust operational resilience program. It aligns with leading industry standards, including ISO 22301, to provide a single, integrated solution for all aspects of business continuity management. From initial analysis to incident response, Open Resilience provides the tools needed to prepare for, respond to, and recover from any disruption.
                </p>
            </Card>

            <Card title="Core Modules & Features">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {modules.map(module => (
                        <div key={module.name} className="bg-slate-800/50 p-6 rounded-xl border border-slate-700/50 flex flex-col">
                            <h4 className="text-lg font-bold text-cyan-400">{module.name}</h4>
                            <p className="text-xs text-slate-500 mb-2">Aligned with: {module.relatedStandard}</p>
                            <p className="text-sm text-slate-400 flex-grow">{module.description}</p>
                        </div>
                    ))}
                </div>
            </Card>
        </div>
    )
}


export default function Settings() {
    const [activeTab, setActiveTab] = useState(TABS[0]);
    
    const renderContent = () => {
        switch(activeTab) {
            case 'User Management': return <UserManagementView />;
            case 'System & API Settings': return <SystemSettingsView />;
            case 'Data Management': return <DataManagementView />;
            case 'Add-ons': return <AddonsView />;
            case 'Service Definition': return <ServiceDefinitionView />;
            default: return null;
        }
    };
    
    return (
        <div className="flex flex-col gap-6">
            <div className="flex border-b border-slate-700 overflow-x-auto">
                {TABS.map(tab => (
                    <button key={tab} onClick={() => setActiveTab(tab)} className={`px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${activeTab === tab ? 'border-b-2 border-cyan-400 text-cyan-400' : 'text-slate-400 hover:text-slate-200'}`}>{tab}</button>
                ))}
            </div>
            <div>{renderContent()}</div>
        </div>
    );
}