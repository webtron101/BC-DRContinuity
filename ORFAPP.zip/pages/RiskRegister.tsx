



import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { Risk, RiskLevel, RiskTreatmentAction } from '../types';
import { useRisks } from '../context/RisksContext';
import { useIT } from '../context/ITContext';
import { CloseIcon } from '../components/icons/CloseIcon';
import { useGovernance } from '../context/GovernanceContext';
import { useMetadata } from '../context/MetadataContext';

const NewRiskModal: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (risk: Omit<Risk, 'id'>) => void }> = ({ isOpen, onClose, onSave }) => {
    const [title, setTitle] = useState('');
    const [category, setCategory] = useState<Risk['category']>('Operational');
    const [impact, setImpact] = useState(3);
    const [likelihood, setLikelihood] = useState(3);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const riskScore = impact * likelihood;

        const calculateLevel = (score: number): RiskLevel => {
            if (score > 15) return RiskLevel.Critical;
            if (score > 9) return RiskLevel.High;
            if (score > 4) return RiskLevel.Medium;
            return RiskLevel.Low;
        };
        
        onSave({
            title, category, impact, likelihood,
            riskScore,
            level: calculateLevel(riskScore),
            trend: 'stable',
            treatmentPlan: [],
            relatedAssetIds: []
        });
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h3 className="text-lg font-semibold">Add New Risk</h3>
                    <button type="button" onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <div>
                        <label htmlFor="risk-title" className="block text-sm font-medium text-slate-300 mb-1">Risk Title</label>
                        <input id="risk-title" value={title} onChange={e => setTitle(e.target.value)} required placeholder="e.g., Ransomware Attack" className="w-full bg-slate-700 p-2 rounded-md" />
                    </div>
                     <div>
                        <label htmlFor="risk-category" className="block text-sm font-medium text-slate-300 mb-1">Category</label>
                        <select id="risk-category" value={category} onChange={e => setCategory(e.target.value as any)} className="w-full bg-slate-700 p-2 rounded-md">
                            <option>Operational</option><option>Financial</option><option>Technical</option><option>Strategic</option><option>Reputational</option>
                        </select>
                    </div>
                     <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="risk-impact" className="block text-sm font-medium text-slate-300 mb-1">Impact (1-5)</label>
                            <input id="risk-impact" type="number" min="1" max="5" value={impact} onChange={e => setImpact(parseInt(e.target.value))} className="w-full bg-slate-700 p-2 rounded-md" />
                        </div>
                        <div>
                            <label htmlFor="risk-likelihood" className="block text-sm font-medium text-slate-300 mb-1">Likelihood (1-5)</label>
                            <input id="risk-likelihood" type="number" min="1" max="5" value={likelihood} onChange={e => setLikelihood(parseInt(e.target.value))} className="w-full bg-slate-700 p-2 rounded-md" />
                        </div>
                    </div>
                    <div className="text-right pt-4"><button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg">Save Risk</button></div>
                </form>
            </div>
        </div>
    );
};

const TreatmentActionModal: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (action: Omit<RiskTreatmentAction, 'id' | 'status'>) => void }> = ({ isOpen, onClose, onSave }) => {
    const { notifyUsers } = useGovernance();
    const [description, setDescription] = useState('');
    const [assigneeId, setAssigneeId] = useState('');
    const [dueDate, setDueDate] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ description, assigneeId, dueDate });
        onClose();
        setDescription(''); setAssigneeId(''); setDueDate('');
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <h3 className="text-lg font-semibold">New Treatment Action</h3>
                    <textarea value={description} onChange={e => setDescription(e.target.value)} required rows={2} placeholder="Action description..." className="w-full bg-slate-700 p-2 rounded-md" />
                    <select value={assigneeId} onChange={e => setAssigneeId(e.target.value)} required className="w-full bg-slate-700 p-2 rounded-md">
                        <option value="" disabled>-- Assign to User --</option>
                        {notifyUsers.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                    </select>
                    <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} required className="w-full bg-slate-700 p-2 rounded-md" />
                    <div className="text-right pt-4"><button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg">Add Action</button></div>
                </form>
            </div>
        </div>
    );
};


function TrendArrow({ trend }: { trend: 'up' | 'down' | 'stable'}) {
    if (trend === 'up') return <span className="text-red-400" title="Getting worse">↑</span>;
    if (trend === 'down') return <span className="text-green-400" title="Improving">↓</span>;
    return <span className="text-slate-400" title="Stable">→</span>;
}

const getStatusChip = (status: RiskTreatmentAction['status']) => {
    switch(status) {
        case 'Completed': return 'bg-green-500/20 text-green-300';
        case 'In Progress': return 'bg-yellow-500/20 text-yellow-300';
        default: return 'bg-blue-500/20 text-blue-300';
    }
}

export default function RiskRegister() {
    const { risks, addRisk, addTreatmentAction, updateTreatmentActionStatus } = useRisks();
    const { currentCompany } = useMetadata();
    const { itAssets } = useIT();
    const { notifyUsers } = useGovernance();
    const [isNewRiskModalOpen, setIsNewRiskModalOpen] = useState(false);
    const [isTreatmentModalOpen, setIsTreatmentModalOpen] = useState(false);
    const [selectedRiskId, setSelectedRiskId] = useState<string | null>(null);

    const assetMap = new Map(itAssets.map(a => [a.id, a.name]));
    const userMap = new Map(notifyUsers.map(u => [u.id, u.name]));
    
    const isIntegrationActive = (name: 'Trello' | 'ServiceNow') => {
        return currentCompany?.integrations.find(i => i.id === name)?.status === 'Active';
    };

    const getRiskLevelInfo = (level: RiskLevel) => {
        switch (level) {
            case RiskLevel.Critical: return { text: 'Critical', color: 'bg-red-500/20 text-red-400' };
            case RiskLevel.High: return { text: 'High', color: 'bg-orange-500/20 text-orange-400' };
            case RiskLevel.Medium: return { text: 'Medium', color: 'bg-yellow-500/20 text-yellow-400' };
            case RiskLevel.Low: default: return { text: 'Low', color: 'bg-green-500/20 text-green-400' };
        }
    };

    const handleSaveRisk = (riskData: Omit<Risk, 'id'>) => {
        addRisk(riskData);
    };

    const handleOpenTreatmentModal = (riskId: string) => {
        setSelectedRiskId(riskId);
        setIsTreatmentModalOpen(true);
    }
    
    const handleSaveTreatmentAction = (action: Omit<RiskTreatmentAction, 'id' | 'status'>) => {
        if (selectedRiskId) {
            addTreatmentAction(selectedRiskId, action);
        }
    };
    
    return (
        <>
            <NewRiskModal isOpen={isNewRiskModalOpen} onClose={() => setIsNewRiskModalOpen(false)} onSave={handleSaveRisk} />
            <TreatmentActionModal isOpen={isTreatmentModalOpen} onClose={() => setIsTreatmentModalOpen(false)} onSave={handleSaveTreatmentAction} />
            
            <Card title="Risk Register">
                <div className="mb-4 flex justify-end">
                    <button onClick={() => setIsNewRiskModalOpen(true)} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-1.5 px-4 rounded-lg text-sm">
                        Add New Risk
                    </button>
                </div>
                <div className="space-y-6">
                    {risks.map((risk) => (
                        <div key={risk.id} className="bg-slate-800/50 rounded-lg p-4 border border-slate-700/50">
                            <div className="flex justify-between items-start flex-wrap gap-2">
                                <h3 className="text-lg font-semibold text-slate-100">{risk.title}</h3>
                                <div className="flex items-center gap-4">
                                     <button
                                        onClick={() => alert(`(Mock) Creating ServiceNow incident for risk: ${risk.title}`)}
                                        disabled={!isIntegrationActive('ServiceNow')}
                                        className="text-xs bg-blue-600/50 text-blue-300 px-2 py-1 rounded-md hover:bg-blue-600 disabled:bg-slate-600/50 disabled:text-slate-400 disabled:cursor-not-allowed"
                                        title={isIntegrationActive('ServiceNow') ? 'Create Incident in ServiceNow' : 'ServiceNow integration not active'}
                                    >
                                        Create SNOW Incident
                                    </button>
                                    <div className="text-center">
                                        <p className="font-bold text-xl text-orange-400">{risk.riskScore}</p>
                                        <p className="text-xs text-slate-500">({risk.impact}x{risk.likelihood}) <TrendArrow trend={risk.trend} /></p>
                                    </div>
                                    <span className={`text-sm font-bold px-3 py-1 rounded-full ${getRiskLevelInfo(risk.level).color}`}>
                                        {getRiskLevelInfo(risk.level).text}
                                    </span>
                                </div>
                            </div>
                            
                            <div className="mt-4 pt-4 border-t border-slate-700/50">
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-md font-semibold text-cyan-400">Treatment Plan</h4>
                                    <button onClick={() => handleOpenTreatmentModal(risk.id)} className="text-xs bg-cyan-600/50 text-cyan-300 px-2 py-1 rounded-md hover:bg-cyan-600">Add Action</button>
                                </div>
                                <div className="space-y-2">
                                    {risk.treatmentPlan.map(action => (
                                        <div key={action.id} className="grid grid-cols-1 md:grid-cols-10 gap-4 items-center bg-slate-900/40 p-2 rounded-md text-sm">
                                            <p className="md:col-span-5 text-slate-300">{action.description}</p>
                                            <p className="md:col-span-1 text-slate-400">{userMap.get(action.assigneeId) || 'N/A'}</p>
                                            <p className="md:col-span-1 text-slate-400">{action.dueDate}</p>
                                            <div className="md:col-span-2">
                                                <select value={action.status} onChange={e => updateTreatmentActionStatus(risk.id, action.id, e.target.value as any)} className={`w-full bg-slate-800 p-1 rounded-md text-xs border-0 focus:ring-2 focus:ring-cyan-500 ${getStatusChip(action.status)}`}>
                                                    <option>To Do</option>
                                                    <option>In Progress</option>
                                                    <option>Completed</option>
                                                </select>
                                            </div>
                                            <div className="md:col-span-1 text-right">
                                                <button
                                                    onClick={() => alert(`(Mock) Creating Trello card for: ${action.description}`)}
                                                    disabled={!isIntegrationActive('Trello')}
                                                    className="text-xs bg-sky-600/50 text-sky-300 px-2 py-1 rounded-md hover:bg-sky-600 disabled:bg-slate-600/50 disabled:text-slate-400 disabled:cursor-not-allowed"
                                                    title={isIntegrationActive('Trello') ? 'Create Trello Card' : 'Trello integration not active'}
                                                >
                                                    To Trello
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                    {risk.treatmentPlan.length === 0 && <p className="text-xs text-slate-500">No treatment actions defined.</p>}
                                </div>
                            </div>
                        </div>
                    ))}
                    {risks.length === 0 && <p className="text-center py-8 text-slate-500">No risks registered for this company.</p>}
                </div>
            </Card>
        </>
    );
};
