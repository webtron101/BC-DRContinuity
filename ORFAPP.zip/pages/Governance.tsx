
import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { ControlStatus, BCMRole, NotifyUser } from '../types';
import { useGovernance } from '../context/GovernanceContext';
import { CloseIcon } from '../components/icons/CloseIcon';
import { TrashIcon } from '../components/icons/TrashIcon';
import { EditIcon } from '../components/icons/EditIcon';

const TABS = ['RACI Matrix / Roles', 'COBIT Controls'];

const RoleModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (role: BCMRole) => void;
    existingRole?: BCMRole | null;
    users: NotifyUser[];
}> = ({ isOpen, onClose, onSave, existingRole, users }) => {
    const [name, setName] = useState('');
    const [assigneeId, setAssigneeId] = useState('');
    const [deputyId, setDeputyId] = useState('');
    const [responsibilities, setResponsibilities] = useState('');
    const [hasInvocationAuthority, setHasInvocationAuthority] = useState(false);

    React.useEffect(() => {
        if (existingRole) {
            setName(existingRole.name);
            setAssigneeId(existingRole.assigneeId);
            setDeputyId(existingRole.deputyId || '');
            setResponsibilities(existingRole.responsibilities.join('\n'));
            setHasInvocationAuthority(existingRole.hasInvocationAuthority);
        } else {
            setName(''); setAssigneeId(''); setDeputyId(''); setResponsibilities(''); setHasInvocationAuthority(false);
        }
    }, [existingRole, isOpen]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const finalRole: BCMRole = {
            id: existingRole?.id || `role-${Date.now()}`,
            name,
            assigneeId,
            deputyId: deputyId || undefined,
            responsibilities: responsibilities.split('\n').filter(r => r.trim() !== ''),
            hasInvocationAuthority
        };
        onSave(finalRole);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-2xl border border-slate-700">
                <form onSubmit={handleSubmit}>
                    <div className="flex justify-between items-center p-4 border-b border-slate-700">
                        <h3 className="text-lg font-semibold">{existingRole ? 'Edit Role' : 'Add New Role'}</h3>
                        <button type="button" onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                    </div>
                    <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                        <input value={name} onChange={e => setName(e.target.value)} required placeholder="Role Name (e.g., Crisis Manager)" className="w-full bg-slate-700 p-2 rounded-md" />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <select value={assigneeId} onChange={e => setAssigneeId(e.target.value)} required className="w-full bg-slate-700 p-2 rounded-md">
                                <option value="" disabled>-- Select Primary Assignee --</option>
                                {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                            </select>
                            <select value={deputyId} onChange={e => setDeputyId(e.target.value)} className="w-full bg-slate-700 p-2 rounded-md">
                                <option value="">-- Select Deputy (Optional) --</option>
                                {users.filter(u => u.id !== assigneeId).map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                            </select>
                        </div>
                        <textarea value={responsibilities} onChange={e => setResponsibilities(e.target.value)} placeholder="Responsibilities (one per line)" rows={4} className="w-full bg-slate-700 p-2 rounded-md" />
                        <div className="flex items-center gap-2">
                            <input id="invocationAuth" type="checkbox" checked={hasInvocationAuthority} onChange={e => setHasInvocationAuthority(e.target.checked)} className="h-4 w-4 rounded bg-slate-700 border-slate-600 text-cyan-500 focus:ring-cyan-600" />
                            <label htmlFor="invocationAuth" className="text-sm font-medium">Has Invocation Authority</label>
                        </div>
                    </div>
                    <div className="text-right p-4 border-t border-slate-700">
                        <button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg">Save Role</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const RolesView: React.FC = () => {
    const { bcmRoles, notifyUsers, addBCMRole, updateBCMRole, deleteBCMRole } = useGovernance();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingRole, setEditingRole] = useState<BCMRole | null>(null);

    const userMap = useMemo(() => new Map(notifyUsers.map(u => [u.id, u.name])), [notifyUsers]);

    const handleEdit = (role: BCMRole) => {
        setEditingRole(role);
        setIsModalOpen(true);
    };
    
    const handleSave = (role: BCMRole) => {
        if (editingRole) {
            updateBCMRole(role.id, role);
        } else {
            addBCMRole(role);
        }
        setIsModalOpen(false);
        setEditingRole(null);
    };

    return (
        <>
            <RoleModal isOpen={isModalOpen} onClose={() => { setIsModalOpen(false); setEditingRole(null); }} onSave={handleSave} existingRole={editingRole} users={notifyUsers} />
            <Card title="BCM Roles & Responsibilities (RACI)">
                 <div className="mb-4 flex justify-end">
                    <button onClick={() => { setEditingRole(null); setIsModalOpen(true); }} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-1.5 px-4 rounded-lg text-sm">
                        Add New Role
                    </button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-400">
                        <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                            <tr>
                                <th className="px-6 py-3">Role</th>
                                <th className="px-6 py-3">Assignee (Deputy)</th>
                                <th className="px-6 py-3">Responsibilities</th>
                                <th className="px-6 py-3">Invocation Authority</th>
                                <th className="px-6 py-3">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {bcmRoles.map(role => (
                                <tr key={role.id} className="border-b border-slate-700/50">
                                    <td className="px-6 py-4 font-semibold text-slate-200">{role.name}</td>
                                    <td className="px-6 py-4">{userMap.get(role.assigneeId) || 'N/A'} {role.deputyId && `(${userMap.get(role.deputyId)})`}</td>
                                    <td className="px-6 py-4"><ul className="list-disc list-inside text-xs">{role.responsibilities.map(r => <li key={r}>{r}</li>)}</ul></td>
                                    <td className="px-6 py-4 text-center">{role.hasInvocationAuthority ? <span className="text-green-400 font-bold">✓</span> : '✗'}</td>
                                    <td className="px-6 py-4 space-x-2">
                                        <button onClick={() => handleEdit(role)} className="p-1 text-slate-400 hover:text-cyan-400"><EditIcon className="w-4 h-4"/></button>
                                        <button onClick={() => deleteBCMRole(role.id)} className="p-1 text-slate-400 hover:text-red-400"><TrashIcon className="w-4 h-4"/></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>
        </>
    );
};

const CobitView: React.FC = () => {
    const { governanceControls } = useGovernance();
    const [statusFilter, setStatusFilter] = useState<ControlStatus | 'All'>('All');
    const [domainFilter, setDomainFilter] = useState<string>('All');

    const domains = useMemo(() => ['All', ...Array.from(new Set(governanceControls.map(c => c.domain)))], [governanceControls]);

    const filteredControls = useMemo(() => {
        return governanceControls.filter(control => {
            const statusMatch = statusFilter === 'All' || control.status === statusFilter;
            const domainMatch = domainFilter === 'All' || control.domain === domainFilter;
            return statusMatch && domainMatch;
        });
    }, [statusFilter, domainFilter, governanceControls]);
    
    const getStatusChip = (status: ControlStatus) => {
        switch (status) {
            case 'Compliant': return 'bg-green-500/20 text-green-400';
            case 'Non-compliant': return 'bg-red-500/20 text-red-400';
            case 'At Risk': return 'bg-yellow-500/20 text-yellow-400';
            case 'Not Audited':
            default: return 'bg-slate-500/20 text-slate-400';
        }
    };
    
    return (
        <Card title="COBIT Control Register">
             <div className="mb-4 flex flex-wrap gap-4">
              <div>
                <label htmlFor="status-filter" className="text-sm font-medium text-slate-400 mr-2">Status:</label>
                <select id="status-filter" value={statusFilter} onChange={e => setStatusFilter(e.target.value as any)} className="bg-slate-700 border-slate-600 rounded-md p-1.5 text-sm focus:ring-cyan-500 focus:border-cyan-500">
                  <option value="All">All</option>
                  <option value="Compliant">Compliant</option>
                  <option value="Non-compliant">Non-compliant</option>
                  <option value="At Risk">At Risk</option>
                  <option value="Not Audited">Not Audited</option>
                </select>
              </div>
              <div>
                <label htmlFor="domain-filter" className="text-sm font-medium text-slate-400 mr-2">Domain:</label>
                <select id="domain-filter" value={domainFilter} onChange={e => setDomainFilter(e.target.value)} className="bg-slate-700 border-slate-600 rounded-md p-1.5 text-sm focus:ring-cyan-500 focus:border-cyan-500">
                  {domains.map(domain => <option key={domain} value={domain}>{domain}</option>)}
                </select>
              </div>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                        <tr>
                            <th scope="col" className="px-6 py-3">Control Ref.</th>
                            <th scope="col" className="px-6 py-3">Description</th>
                            <th scope="col" className="px-6 py-3">Domain</th>
                            <th scope="col" className="px-6 py-3">Owner</th>
                            <th scope="col" className="px-6 py-3">Last Audit</th>
                            <th scope="col" className="px-6 py-3">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredControls.map((control) => (
                            <tr key={control.id} className="border-b border-slate-700/50 hover:bg-slate-800/40">
                                <td className="px-6 py-4 font-mono text-slate-200">{control.controlReference}</td>
                                <td className="px-6 py-4">{control.description}</td>
                                <td className="px-6 py-4">{control.domain}</td>
                                <td className="px-6 py-4 font-medium text-slate-300">{control.owner}</td>
                                <td className="px-6 py-4">{control.lastAudit}</td>
                                <td className="px-6 py-4">
                                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getStatusChip(control.status)}`}>
                                        {control.status}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {filteredControls.length === 0 && <p className="text-center py-8 text-slate-500">No controls match the current filters.</p>}
            </div>
        </Card>
    );
};


export default function Governance() {
    const [activeTab, setActiveTab] = useState(TABS[0]);
    
    const renderContent = () => {
        switch(activeTab) {
            case 'RACI Matrix / Roles': return <RolesView />;
            case 'COBIT Controls': return <CobitView />;
            default: return null;
        }
    };
    
    return (
        <div className="flex flex-col gap-6">
            <div className="flex border-b border-slate-700">
                {TABS.map(tab => (
                    <button key={tab} onClick={() => setActiveTab(tab)} className={`px-4 py-2 text-sm font-medium transition-colors ${activeTab === tab ? 'border-b-2 border-cyan-400 text-cyan-400' : 'text-slate-400 hover:text-slate-200'}`}>{tab}</button>
                ))}
            </div>
            <div>{renderContent()}</div>
        </div>
    );
};
