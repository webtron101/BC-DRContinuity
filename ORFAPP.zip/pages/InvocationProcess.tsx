

import React, { useState, useEffect } from 'react';
import Card from '../components/Card';
import { InvocationStep, IncidentEvent } from '../types';
import { useMetadata } from '../context/MetadataContext';
import { useIncident } from '../context/IncidentContext';
import { useAuth } from '../context/AuthContext';
import { CommandCenterIcon } from '../components/icons/CommandCenterIcon';
import { SlackIcon } from '../components/icons/SlackIcon';


const getStatusChip = (status: InvocationStep['status']) => {
    switch (status) {
        case 'Completed': return 'bg-green-500/20 text-green-400';
        case 'In Progress': return 'bg-yellow-500/20 text-yellow-400';
        case 'Pending': return 'bg-blue-500/20 text-blue-400';
        case 'Skipped': return 'bg-slate-500/20 text-slate-400';
        default: return 'bg-gray-500/20 text-gray-400';
    }
};

const formatDuration = (start: string) => {
    const startTime = new Date(start).getTime();
    if (isNaN(startTime)) return '00:00:00';
    
    const now = new Date().getTime();
    const seconds = Math.floor((now - startTime) / 1000);
    
    const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    
    return `${h}:${m}:${s}`;
}

const LiveCommandCenter: React.FC = () => {
    const { user } = useAuth();
    const { activeIncident, addLogEntry, updateStepStatus, resolveIncident } = useIncident();
    const { currentCompany } = useMetadata();
    const [duration, setDuration] = useState('00:00:00');
    const [logMessage, setLogMessage] = useState('');

    const isSlackActive = currentCompany?.integrations.find(i => i.id === 'Slack')?.status === 'Active';

    useEffect(() => {
        if (activeIncident && activeIncident.status === 'Active') {
            const timer = setInterval(() => {
                setDuration(formatDuration(activeIncident.declaredAt));
            }, 1000);
            return () => clearInterval(timer);
        }
    }, [activeIncident]);

    if (!activeIncident) return null; // Should be handled by the parent component

    const handleAddLogEntry = () => {
        if (logMessage.trim() && user) {
            addLogEntry(logMessage);
            setLogMessage('');
        }
    }

    const handleSendToSlack = () => {
        if (!logMessage.trim()) {
            alert("Please enter a message to send.");
            return;
        }
        alert(`(Mock) Sending to Slack #crisis-channel:\n\n${logMessage}`);
    }

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
            <div className="lg:col-span-2">
                <Card title="Invocation Checklist">
                    <div className="space-y-4">
                        {activeIncident.plan.map(step => (
                            <div key={step.id} className="bg-slate-800/50 p-4 rounded-lg">
                                <div className="flex justify-between items-start gap-4">
                                    <div>
                                        <p className="font-semibold text-slate-200">{step.step}. {step.action}</p>
                                        <p className="text-xs text-slate-400 mt-1">{step.description}</p>
                                    </div>
                                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full whitespace-nowrap ${getStatusChip(step.status)}`}>
                                        {step.status}
                                    </span>
                                </div>
                                <div className="flex gap-2 mt-3 text-xs">
                                    <button onClick={() => updateStepStatus(step.id, 'In Progress')} className="bg-yellow-500/20 text-yellow-300 px-2 py-1 rounded-md">In Progress</button>
                                    <button onClick={() => updateStepStatus(step.id, 'Completed')} className="bg-green-500/20 text-green-300 px-2 py-1 rounded-md">Complete</button>
                                    <button onClick={() => updateStepStatus(step.id, 'Skipped')} className="bg-slate-500/20 text-slate-300 px-2 py-1 rounded-md">Skip</button>
                                </div>
                            </div>
                        ))}
                    </div>
                </Card>
            </div>
            <div className="lg:col-span-1 flex flex-col gap-6">
                <Card title="Incident Status">
                     <div className="text-center">
                        <p className="text-sm text-slate-400">Incident Duration</p>
                        <p className="text-4xl font-mono font-bold text-orange-400 my-2">{duration}</p>
                        <p className="text-sm text-slate-400">Status: <span className="font-semibold text-red-400">{activeIncident.status}</span></p>
                        <button onClick={resolveIncident} className="mt-4 w-full bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded">
                           Resolve Incident
                        </button>
                     </div>
                </Card>
                 <Card title="Live Event Log" className="flex-1">
                    <div className="h-full flex flex-col">
                        <div className="flex-1 space-y-3 overflow-y-auto pr-2 max-h-96">
                            {activeIncident.log.slice().reverse().map(entry => (
                                <div key={entry.id} className="bg-slate-900/50 p-2 rounded-md">
                                    <p className="text-xs text-slate-300 break-words">{entry.message}</p>
                                    <p className="text-right text-xs text-slate-500 mt-1">-- {entry.authorName} at {new Date(entry.timestamp).toLocaleTimeString()}</p>
                                </div>
                            ))}
                        </div>
                        <div className="mt-4 pt-4 border-t border-slate-700">
                            <textarea value={logMessage} onChange={e => setLogMessage(e.target.value)} placeholder="Log an update..." rows={2} className="w-full bg-slate-700 p-2 rounded-md text-sm"></textarea>
                            <div className="flex gap-2 mt-2">
                                <button onClick={handleAddLogEntry} className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-1.5 rounded-lg text-sm">Post Update</button>
                                <button
                                    onClick={handleSendToSlack}
                                    disabled={!isSlackActive}
                                    title={isSlackActive ? "Send this update to Slack" : "Slack integration not active"}
                                    className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-500 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-semibold py-1.5 rounded-lg text-sm"
                                >
                                    <SlackIcon className="w-4 h-4" />
                                    Send to Slack
                                </button>
                            </div>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    )
}


export default function InvocationProcess() {
    const { currentCompany } = useMetadata();
    const { activeIncident, declareIncident } = useIncident();

    if (!currentCompany) return <Card title="Loading...">Loading company data...</Card>;

    if (activeIncident) {
        return <LiveCommandCenter />;
    }

    return (
        <div className="flex items-center justify-center h-full">
            <div className="text-center">
                <CommandCenterIcon className="w-24 h-24 text-slate-600 mx-auto" />
                <h2 className="mt-4 text-3xl font-bold text-slate-200">Command Center is Standby</h2>
                <p className="mt-2 text-slate-400">No active incidents have been declared.</p>
                <button 
                    onClick={() => declareIncident(currentCompany.invocationPlan)}
                    className="mt-8 px-8 py-4 font-bold text-lg text-white bg-red-600 rounded-lg shadow-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-opacity-75 transform transition-all duration-200 ease-in-out active:scale-95"
                >
                    Declare a Major Incident
                </button>
            </div>
        </div>
    );
};
