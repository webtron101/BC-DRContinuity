

import React, { useState } from 'react';
import Card from '../components/Card';
import { useIT } from '../context/ITContext';
import { useDocuments } from '../context/DocumentsContext';
import { useGovernance } from '../context/GovernanceContext';
import { ITAsset, ServerProfile, ResilienceStatus } from '../types';
import { CloseIcon } from '../components/icons/CloseIcon';
import { useMetadata } from '../context/MetadataContext';
import { SCCMIcon } from '../components/icons/SCCMIcon';

const getResilienceStatusChip = (status: ResilienceStatus) => {
    switch (status) {
        case 'Resilient': return 'bg-green-500/20 text-green-400';
        case 'In Progress': return 'bg-yellow-500/20 text-yellow-400';
        case 'Not Resilient': return 'bg-red-500/20 text-red-400';
        default: return 'bg-slate-500/20 text-slate-400';
    }
}

const ServerProfileModal: React.FC<{ profile: ServerProfile, assetName: string, onClose: () => void }> = ({ profile, assetName, onClose }) => (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
        <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
            <div className="flex justify-between items-center p-4 border-b border-slate-700">
                <h3 className="text-lg font-semibold">Server Profile: {assetName}</h3>
                <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
            </div>
            <div className="p-6 space-y-3 text-sm">
                <p><strong>OS:</strong> {profile.os}</p>
                <p><strong>CPU:</strong> {profile.cpu}</p>
                <p><strong>RAM:</strong> {profile.ram}</p>
                <p><strong>Storage:</strong> {profile.storage}</p>
                <p><strong>Roles:</strong> {profile.roles.join(', ')}</p>
                <p><strong>Critical Paths:</strong> {profile.paths.join(', ')}</p>
            </div>
        </div>
    </div>
);

const RecoveryProcedureModal: React.FC<{ docId: string, onClose: () => void }> = ({ docId, onClose }) => {
    const { documents } = useDocuments();
    const doc = documents.find(d => d.id === docId);

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-3xl border border-slate-700">
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h3 className="text-lg font-semibold">{doc?.name || 'Recovery Procedure'}</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </div>
                <div className="p-6 max-h-[70vh] overflow-y-auto prose prose-sm prose-invert max-w-none">
                    {doc?.content ? <div dangerouslySetInnerHTML={{ __html: doc.content.replace(/\n/g, '<br />') }} /> : <p>Document content not found.</p>}
                </div>
            </div>
        </div>
    );
};

const DesignSolutionModal: React.FC<{ asset: ITAsset, onClose: () => void }> = ({ asset, onClose }) => {
    const { updateITAsset } = useIT();
    const { bcmStrategies } = useGovernance();
    const [selectedStrategy, setSelectedStrategy] = useState('');

    const handleSave = () => {
        if (!selectedStrategy) return;
        // In a real app, this might create assignments, etc. Here we just update the status.
        updateITAsset(asset.id, { resilienceStatus: 'In Progress' });
        alert(`Solution design started for ${asset.name} using strategy: ${bcmStrategies.find(s=>s.id === selectedStrategy)?.name}`);
        onClose();
    }
    
    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h3 className="text-lg font-semibold">Design Solution for {asset.name}</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </div>
                <div className="p-6 space-y-4">
                    <p>Select a BCM strategy to make this asset resilient.</p>
                     <select value={selectedStrategy} onChange={e => setSelectedStrategy(e.target.value)} className="w-full bg-slate-700 p-2 rounded-md">
                        <option value="" disabled>-- Select a Strategy --</option>
                        {bcmStrategies.map(s => <option key={s.id} value={s.id}>{s.name} ({s.type})</option>)}
                     </select>
                </div>
                <div className="text-right p-4 border-t border-slate-700">
                    <button onClick={handleSave} disabled={!selectedStrategy} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg disabled:opacity-50">Start Implementation</button>
                </div>
            </div>
        </div>
    );
}

export default function ITSCM() {
    const { itAssets } = useIT();
    const { currentCompany } = useMetadata();
    
    const [viewingProfile, setViewingProfile] = useState<ITAsset | null>(null);
    const [viewingProcedure, setViewingProcedure] = useState<string | null>(null);
    const [designingSolution, setDesigningSolution] = useState<ITAsset | null>(null);

    const isSccmActive = currentCompany?.integrations.find(i => i.id === 'SCCM')?.status === 'Active';
    
    return (
        <>
            {viewingProfile && viewingProfile.serverProfile && <ServerProfileModal profile={viewingProfile.serverProfile} assetName={viewingProfile.name} onClose={() => setViewingProfile(null)} />}
            {viewingProcedure && <RecoveryProcedureModal docId={viewingProcedure} onClose={() => setViewingProcedure(null)} />}
            {designingSolution && <DesignSolutionModal asset={designingSolution} onClose={() => setDesigningSolution(null)} />}

            <Card title="IT Service Continuity Management">
                <div className="flex justify-between items-start mb-6 -mt-2 flex-wrap gap-4">
                    <p className="text-sm text-slate-400 max-w-4xl">This module provides a technical view of all critical IT assets identified in the BIA, along with their recovery plans and status, aligned with ITIL principles.</p>
                     <button
                        onClick={() => alert("(Mock) Syncing IT Assets from SCCM...")}
                        disabled={!isSccmActive}
                        title={isSccmActive ? "Sync IT Assets from SCCM" : "SCCM integration is not active"}
                        className="flex items-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg text-sm whitespace-nowrap transition-transform active:scale-95 disabled:bg-slate-600 disabled:cursor-not-allowed"
                    >
                        <SCCMIcon className="w-5 h-5"/>
                        Sync from SCCM
                    </button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-400">
                         <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                            <tr>
                                <th className="px-6 py-3">Asset Name</th>
                                <th className="px-6 py-3">Type</th>
                                <th className="px-6 py-3">Resilience Status</th>
                                <th className="px-6 py-3">Last Rehearsal</th>
                                <th className="px-6 py-3">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {itAssets.map(asset => (
                                <tr key={asset.id} className="border-b border-slate-700/50">
                                    <td className="px-6 py-4 font-semibold text-slate-200">{asset.name}</td>
                                    <td className="px-6 py-4">{asset.type}</td>
                                    <td className="px-6 py-4"><span className={`text-xs font-bold px-2 py-0.5 rounded-full ${getResilienceStatusChip(asset.resilienceStatus)}`}>{asset.resilienceStatus}</span></td>
                                    <td className="px-6 py-4">{asset.lastRehearsal || 'N/A'}</td>
                                    <td className="px-6 py-4 space-x-2 text-xs">
                                        {asset.serverProfile && <button onClick={() => setViewingProfile(asset)} className="text-cyan-400 hover:underline">Profile</button>}
                                        {asset.recoveryProcedureDocId && <button onClick={() => setViewingProcedure(asset.recoveryProcedureDocId!)} className="text-cyan-400 hover:underline">Procedure</button>}
                                        {asset.resilienceStatus === 'Not Resilient' && <button onClick={() => setDesigningSolution(asset)} className="bg-orange-500/20 text-orange-300 px-2 py-1 rounded-md">Design Solution</button>}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>
        </>
    );
}