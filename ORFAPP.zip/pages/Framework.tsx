
import React, { useMemo, useCallback } from 'react';
import Card from '../components/Card';
import { ResiliencePhase } from '../types';
import { useMetadata } from '../context/MetadataContext';
import { useAssignments } from '../context/AssignmentsContext';
import { useRisks } from '../context/RisksContext';
import { useDocuments } from '../context/DocumentsContext';
import { useBIA } from '../context/BIAContext';
import { useRehearsals } from '../context/RehearsalsContext';
import { useGovernance } from '../context/GovernanceContext';
import { DocumentIcon } from '../components/icons/DocumentIcon';
import { RefreshIcon } from '../components/icons/RefreshIcon';

function MaturityScoreCircle({ score }: { score: number }) {
    const circumference = 2 * Math.PI * 45;
    const offset = circumference - (score / 100) * circumference;

    return (
        <div className="flex items-center justify-center">
            <svg className="w-40 h-40" viewBox="0 0 100 100">
                <circle className="text-slate-700" strokeWidth="8" stroke="currentColor" fill="transparent" r="45" cx="50" cy="50" />
                <circle
                    className="text-cyan-400"
                    strokeWidth="8"
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="transparent"
                    r="45"
                    cx="50"
                    cy="50"
                    transform="rotate(-90 50 50)"
                />
                <text x="50" y="50" className="text-2xl font-bold fill-current text-slate-100" textAnchor="middle" dy=".3em">{score}%</text>
            </svg>
        </div>
    );
};

export default function Framework() {
    const { currentCompany, updateResilienceFramework } = useMetadata();
    const { assignments } = useAssignments();
    const { risks } = useRisks();
    const { documents } = useDocuments();
    const { processes } = useBIA();
    const { rehearsals } = useRehearsals();
    const { bcmRoles, bcmStrategies } = useGovernance();
    
    const handleUpdateMaturity = useCallback(() => {
        if (!currentCompany) return;

        const hasApprovedPolicy = documents.some(d => d.type === 'Policy' && d.status === 'Approved');
        const hasDefinedRoles = bcmRoles.length > 0;
        const policyProgress = (hasApprovedPolicy ? 50 : 0) + (hasDefinedRoles ? 50 : 0);

        const biAsCompleted = processes.length > 0;
        const risksAssessed = risks.length > 0;
        const analysisProgress = (biAsCompleted ? 60 : 0) + (risksAssessed ? 40 : 0);

        const strategiesDefined = bcmStrategies.length > 0;
        const strategiesLinked = processes.some(p => p.strategyIds && p.strategyIds.length > 0);
        const designProgress = (strategiesDefined ? 60 : 0) + (strategiesLinked ? 40 : 0);
        
        const drpsApproved = documents.filter(d => d.type === 'DRP' && d.status === 'Approved').length;
        const bcpsApproved = documents.filter(d => d.type === 'BCM Plan' && d.status === 'Approved').length;
        const totalPlans = documents.filter(d => ['DRP', 'BCM Plan'].includes(d.type)).length;
        const implementationProgress = totalPlans > 0 ? Math.round(((drpsApproved + bcpsApproved) / totalPlans) * 100) : 0;
        
        const rehearsalsCompleted = rehearsals.filter(r => r.status === 'Completed').length;
        const totalRehearsals = rehearsals.length;
        const validationProgress = totalRehearsals > 0 ? Math.round((rehearsalsCompleted / totalRehearsals) * 100) : 5;

        const assignmentsCompleted = assignments.filter(a => a.status === 'Completed').length;
        const totalAssignments = assignments.length;
        const embeddingProgress = totalAssignments > 0 ? Math.round((assignmentsCompleted / totalAssignments) * 100) : 10;
        
        const getStatus = (progress: number): ResiliencePhase['status'] => {
            if (progress >= 80) return 'Mature';
            if (progress > 10) return 'In Progress';
            return 'Not Started';
        }

        const updatedFramework = (currentCompany.resilienceFramework || []).map(phase => {
             switch(phase.id) {
                 case 'phase1': return {...phase, progress: policyProgress, status: getStatus(policyProgress)};
                 case 'phase2': return {...phase, progress: analysisProgress, status: getStatus(analysisProgress)};
                 case 'phase3': return {...phase, progress: designProgress, status: getStatus(designProgress)};
                 case 'phase4': return {...phase, progress: implementationProgress, status: getStatus(implementationProgress)};
                 case 'phase5': return {...phase, progress: validationProgress, status: getStatus(validationProgress)};
                 case 'phase6': return {...phase, progress: embeddingProgress, status: getStatus(embeddingProgress)};
                 default: return phase;
             }
        });
        
        updateResilienceFramework(updatedFramework);
        alert('Maturity scores have been updated.');

    }, [currentCompany, assignments, risks, documents, processes, rehearsals, bcmRoles, bcmStrategies, updateResilienceFramework]);

    const framework = currentCompany?.resilienceFramework || [];

    const getStatusChip = (status: ResiliencePhase['status']) => {
        switch (status) {
            case 'Mature': return 'bg-green-500/20 text-green-400';
            case 'In Progress': return 'bg-yellow-500/20 text-yellow-400';
            case 'Not Started':
            default: return 'bg-slate-500/20 text-slate-400';
        }
    };
    
    const maturityScore = useMemo(() => {
        if (framework.length === 0) return 0;
        const totalProgress = framework.reduce((sum, phase) => sum + phase.progress, 0);
        return Math.round(totalProgress / framework.length);
    }, [framework]);

    if (!currentCompany) return <Card title="Loading...">Loading company data...</Card>;

    return (
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <Card title="Resilience Framework Maturity">
              <div className="flex flex-wrap justify-between items-start mb-6 gap-4">
                  <p className="text-sm text-slate-400 max-w-4xl">
                      This dashboard calculates the maturity of your BCMS against the BCI Good Practice Guidelines based on real data from the application. Click the update button to refresh the scores.
                  </p>
                  <button 
                      onClick={handleUpdateMaturity}
                      className="flex items-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg text-sm whitespace-nowrap transition-transform active:scale-95"
                      title="Refresh maturity scores based on current data"
                  >
                      <RefreshIcon className="w-5 h-5" />
                      Update Scores
                  </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {framework.map((phase) => (
                      <div key={phase.id} className="bg-slate-800/50 p-6 rounded-xl border border-slate-700/50 flex flex-col justify-between">
                          <div>
                              <div className="flex justify-between items-start mb-2">
                                  <h3 className="text-lg font-semibold text-cyan-400">{phase.name}</h3>
                                   <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getStatusChip(phase.status)}`}>
                                      {phase.status}
                                   </span>
                              </div>
                              <p className="text-sm text-slate-400 mb-4 h-20">{phase.description}</p>
                          </div>
                           <div>
                              {phase.resources.length > 0 && (
                                <div className="mb-4">
                                    <h4 className="text-xs font-bold text-slate-500 uppercase">Resources</h4>
                                    <div className="mt-1 space-y-1">
                                        {phase.resources.map(res => (
                                            <a key={res.name} href={res.url} target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline flex items-center gap-1 text-xs">
                                                <DocumentIcon className="w-4 h-4" /> {res.name}
                                            </a>
                                        ))}
                                    </div>
                                </div>
                              )}
                              <div className="flex items-center gap-3">
                                  <div className="w-full bg-slate-700 rounded-full h-2.5">
                                      <div className="bg-cyan-500 h-2.5 rounded-full" style={{width: `${phase.progress}%`}}></div>
                                  </div>
                                  <span className="font-semibold text-sm text-slate-200">{phase.progress}%</span>
                              </div>
                          </div>
                      </div>
                  ))}
                   {framework.length === 0 && <p className="col-span-full text-center py-8 text-slate-500">No framework data configured for this company.</p>}
              </div>
          </Card>
        </div>
        <div className="lg:col-span-1">
            <Card title="Overall Maturity">
                 <MaturityScoreCircle score={maturityScore} />
                 <p className="text-center mt-2 text-slate-400">Aggregated score from all phases.</p>
            </Card>
        </div>
      </div>
    );
};