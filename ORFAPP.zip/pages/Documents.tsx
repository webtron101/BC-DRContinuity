
import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { Document, SoAControl, DocumentType } from '../types';
import { CloseIcon } from '../components/icons/CloseIcon';
import { useDocuments } from '../context/DocumentsContext';
import { useAuth } from '../context/AuthContext';

const TABS = ['Document Library', 'Statement of Applicability'];

const getStatusChip = (status: Document['status']) => {
    switch (status) {
      case 'Approved': return 'bg-green-500/20 text-green-500 dark:text-green-400';
      case 'In Review': return 'bg-yellow-500/20 text-yellow-500 dark:text-yellow-400';
      case 'Draft': return 'bg-blue-500/20 text-blue-500 dark:text-blue-400';
      case 'Archived': return 'bg-slate-500/20 text-slate-500 dark:text-slate-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
};

const ChangeHistoryModal: React.FC<{ doc: Document, onClose: () => void }> = ({ doc, onClose }) => (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-2xl border border-slate-200 dark:border-slate-700">
            <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700">
                <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Change History for "{doc.name}"</h3>
                <button onClick={onClose} className="text-slate-500 dark:text-slate-400 hover:text-black dark:hover:text-white"><CloseIcon className="w-6 h-6" /></button>
            </div>
            <div className="p-6 max-h-[60vh] overflow-y-auto">
                {doc.changeHistory.length > 0 ? (
                    <table className="w-full text-sm text-left text-slate-600 dark:text-slate-400">
                        <thead className="text-xs text-slate-500 dark:text-slate-400 uppercase bg-slate-50 dark:bg-slate-900/30">
                            <tr><th className="px-4 py-2">Version</th><th className="px-4 py-2">Date</th><th className="px-4 py-2">Editor</th><th className="px-4 py-2">Summary</th></tr>
                        </thead>
                        <tbody>
                            {doc.changeHistory.map(entry => (
                                <tr key={entry.version} className="border-b border-slate-200 dark:border-slate-700/50">
                                    <td className="px-4 py-3 font-mono">v{entry.version}</td><td className="px-4 py-3">{entry.date}</td><td className="px-4 py-3 text-slate-800 dark:text-slate-200">{entry.editor}</td><td className="px-4 py-3">{entry.summary}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : <p className="text-center text-slate-500">No change history recorded.</p>}
            </div>
        </div>
    </div>
);

const NewDocumentModal: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (doc: Omit<Document, 'id' | 'version' | 'status' | 'lastUpdated' | 'changeHistory'>) => void }> = ({ isOpen, onClose, onSave }) => {
    const [name, setName] = useState('');
    const [owner, setOwner] = useState('');
    const [category, setCategory] = useState<Document['category']>('BCM');
    const [type, setType] = useState<DocumentType>('Policy');

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ name, owner, category, type });
        onClose();
        setName(''); setOwner('');
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <h3 className="text-lg font-semibold">Add New Document</h3>
                    <input value={name} onChange={e => setName(e.target.value)} required placeholder="Document Name" className="w-full bg-slate-700 p-2 rounded-md" />
                    <input value={owner} onChange={e => setOwner(e.target.value)} required placeholder="Document Owner" className="w-full bg-slate-700 p-2 rounded-md" />
                    <select value={category} onChange={e => setCategory(e.target.value as any)} className="w-full bg-slate-700 p-2 rounded-md"><option>BCM</option><option>IT</option><option>Resource</option></select>
                    <select value={type} onChange={e => setType(e.target.value as any)} className="w-full bg-slate-700 p-2 rounded-md"><option>Policy</option><option>DRP</option><option>BCM Plan</option><option>Report</option></select>
                    <div className="text-right pt-4"><button type="submit" className="bg-cyan-600 px-4 py-2 rounded-lg">Save Document</button></div>
                </form>
            </div>
        </div>
    );
};

function LibraryView() {
  const { documents, approveDocument, addDocument } = useDocuments();
  const { user } = useAuth();
  
  const [viewingHistory, setViewingHistory] = useState<Document | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleApprove = (docId: string) => {
      if (!user) return;
      approveDocument(docId, user.id, user.name);
      alert(`Document approved by ${user.name}.`);
  };

  const handleSaveDocument = (docData: Omit<Document, 'id' | 'version' | 'status' | 'lastUpdated' | 'changeHistory'>) => {
      const newDoc: Document = {
          ...docData,
          id: `doc-${Date.now()}`,
          version: '1.0',
          status: 'Draft',
          lastUpdated: new Date().toISOString().split('T')[0],
          changeHistory: [{ version: '1.0', date: new Date().toISOString().split('T')[0], editor: user?.name || 'System', summary: 'Initial creation.' }]
      };
      addDocument(newDoc);
  };

  return (
    <>
      {viewingHistory && <ChangeHistoryModal doc={viewingHistory} onClose={() => setViewingHistory(null)} />}
      <NewDocumentModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleSaveDocument} />
      <Card title="Document Library">
        <div className="mb-4 flex justify-end">
            <button onClick={() => setIsModalOpen(true)} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-1.5 px-4 rounded-lg text-sm">
                Add New Document
            </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-slate-600 dark:text-slate-400">
            <thead className="text-xs text-slate-500 dark:text-slate-400 uppercase bg-slate-50 dark:bg-slate-900/30">
              <tr>
                <th scope="col" className="px-6 py-3">Document Name</th><th scope="col" className="px-6 py-3">Owner</th><th scope="col" className="px-6 py-3">Version</th>
                <th scope="col" className="px-6 py-3">Status</th><th scope="col" className="px-6 py-3">Last Updated</th><th scope="col" className="px-6 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {documents.map((doc) => (
                <tr key={doc.id} className="border-b border-slate-200 dark:border-slate-700/50 hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="px-6 py-4 font-medium text-slate-800 dark:text-slate-200">{doc.name}</td>
                  <td className="px-6 py-4">{doc.owner}</td><td className="px-6 py-4">v{doc.version}</td>
                  <td className="px-6 py-4"><span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getStatusChip(doc.status)}`}>{doc.status}</span></td>
                  <td className="px-6 py-4">{doc.lastUpdated}</td>
                  <td className="px-6 py-4 space-x-2">
                      <button onClick={() => setViewingHistory(doc)} className="text-cyan-500 dark:text-cyan-400 hover:underline text-xs">History</button>
                      {doc.status === 'In Review' && user && (<>
                        <button onClick={() => handleApprove(doc.id)} className="text-green-500 dark:text-green-400 hover:underline text-xs">Approve</button>
                        <button className="text-red-500 dark:text-red-400 hover:underline text-xs">Reject</button>
                      </>)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
};

const SoAView: React.FC = () => {
    const { statementOfApplicability, updateSoAControl } = useDocuments();

    return (
        <Card title="Statement of Applicability (ISO 22301)">
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Declare which ISO 22301 controls are applicable to your organization and provide justification for any exclusions. This is a mandatory document for certification.</p>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                        <tr>
                            <th className="px-4 py-2 w-16">Applicable</th>
                            <th className="px-4 py-2">Control Reference</th>
                            <th className="px-4 py-2 w-1/2">Justification</th>
                        </tr>
                    </thead>
                    <tbody>
                        {statementOfApplicability.map(control => (
                            <tr key={control.id} className="border-b border-slate-700/50">
                                <td className="px-4 py-3 text-center">
                                    <input type="checkbox" checked={control.applicable} onChange={(e) => updateSoAControl(control.id, { applicable: e.target.checked })}
                                        className="h-5 w-5 rounded bg-slate-700 border-slate-600 text-cyan-500 focus:ring-cyan-600"
                                    />
                                </td>
                                <td className="px-4 py-3">
                                    <p className="font-semibold text-slate-200">{control.controlRef}</p>
                                    <p className="text-xs text-slate-500">{control.description}</p>
                                </td>
                                <td className="px-4 py-3">
                                    <textarea value={control.justification}
                                        onChange={(e) => updateSoAControl(control.id, { justification: e.target.value })}
                                        className="w-full bg-slate-700/80 p-2 rounded-md text-xs border border-slate-600/50 focus:ring-cyan-500 focus:border-cyan-500"
                                        rows={2} placeholder="Justify inclusion or exclusion..."
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </Card>
    );
};


export default function Documents() {
  const [activeTab, setActiveTab] = useState(TABS[0]);

  const renderContent = () => {
    switch (activeTab) {
      case 'Document Library': return <LibraryView />;
      case 'Statement of Applicability': return <SoAView />;
      default: return null;
    }
  };

  return (
    <div className="flex flex-col gap-6">
        <div className="flex border-b border-slate-200 dark:border-slate-700">
            {TABS.map(tab => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-2 text-sm font-medium transition-colors
                        ${activeTab === tab 
                            ? 'border-b-2 border-cyan-500 dark:border-cyan-400 text-cyan-500 dark:text-cyan-400' 
                            : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                        }`}
                >
                    {tab}
                </button>
            ))}
        </div>
        <div>{renderContent()}</div>
    </div>
  );
};
