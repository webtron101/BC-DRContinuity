
import React, { useState, useRef, useEffect } from 'react';
import Card from '../components/Card';
import { useSecureComms } from '../context/SecureCommsContext';
import { useAuth } from '../context/AuthContext';
import { SendIcon } from '../components/icons/SendIcon';
import { LockIcon } from '../components/icons/LockIcon';

export default function SecureComms() {
    const { channels, getMessagesForChannel, sendMessage } = useSecureComms();
    const { user } = useAuth();
    const [activeChannelId, setActiveChannelId] = useState<string | null>(channels[0]?.id || null);
    const [messageInput, setMessageInput] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const activeChannel = channels.find(c => c.id === activeChannelId);
    const messages = activeChannelId ? getMessagesForChannel(activeChannelId) : [];

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const handleSendMessage = () => {
        if (messageInput.trim() && activeChannelId) {
            sendMessage(activeChannelId, messageInput);
            setMessageInput('');
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    };

    return (
        <div className="flex h-[calc(100vh-128px)]">
            {/* Channel List */}
            <div className="w-1/3 bg-slate-800/50 rounded-l-xl border-r border-slate-700/50 flex flex-col">
                <div className="p-4 border-b border-slate-700/50">
                    <h2 className="text-lg font-semibold">Secure Channels</h2>
                </div>
                <div className="flex-grow overflow-y-auto">
                    {channels.map(channel => (
                        <button 
                            key={channel.id}
                            onClick={() => setActiveChannelId(channel.id)}
                            className={`w-full text-left p-4 ${activeChannelId === channel.id ? 'bg-cyan-500/10' : 'hover:bg-slate-700/30'}`}
                        >
                            <h3 className="font-semibold text-slate-200 flex items-center gap-2">
                                {channel.isEncrypted && <LockIcon className="w-4 h-4 text-green-400" />}
                                {channel.name}
                            </h3>
                            <p className="text-xs text-slate-400 mt-1">{channel.description}</p>
                        </button>
                    ))}
                </div>
            </div>

            {/* Chat Window */}
            <div className="w-2/3 bg-slate-800 rounded-r-xl flex flex-col">
                {activeChannel ? (
                    <>
                        <div className="p-4 border-b border-slate-700/50">
                            <h2 className="text-lg font-semibold">{activeChannel.name}</h2>
                        </div>
                        <div className="flex-grow p-4 overflow-y-auto space-y-4">
                            {messages.map((msg, index) => {
                                const isSelf = msg.authorId === user?.id;
                                return (
                                    <div key={index} className={`flex items-start gap-3 ${isSelf ? 'justify-end' : ''}`}>
                                        {!isSelf && <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0 text-cyan-400 font-bold">{msg.authorName.charAt(0)}</div>}
                                        <div className={`max-w-md rounded-xl px-4 py-2 ${isSelf ? 'bg-cyan-600 text-white rounded-br-none' : 'bg-slate-700 text-slate-300 rounded-bl-none'}`}>
                                            {!isSelf && <p className="text-xs font-bold text-cyan-400 mb-1">{msg.authorName}</p>}
                                            <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                                            <p className={`text-xs mt-1 ${isSelf ? 'text-cyan-200' : 'text-slate-500'} text-right`}>{new Date(msg.timestamp).toLocaleTimeString()}</p>
                                        </div>
                                    </div>
                                );
                            })}
                             <div ref={messagesEndRef} />
                        </div>
                        <div className="p-4 border-t border-slate-700/50">
                             <div className="relative">
                                <textarea
                                    value={messageInput}
                                    onChange={(e) => setMessageInput(e.target.value)}
                                    onKeyDown={handleKeyDown}
                                    placeholder={`Message #${activeChannel.name}`}
                                    className="w-full bg-slate-700 text-slate-200 rounded-lg py-2 pl-3 pr-12 resize-none focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                                    rows={1}
                                />
                                <button onClick={handleSendMessage} disabled={!messageInput.trim()} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full text-slate-400 hover:bg-slate-600 disabled:text-slate-600 disabled:hover:bg-transparent">
                                    <SendIcon className="h-5 w-5" />
                                </button>
                            </div>
                        </div>
                    </>
                ) : (
                    <div className="flex items-center justify-center h-full">
                        <p className="text-slate-500">Select a channel to start communicating.</p>
                    </div>
                )}
            </div>
        </div>
    );
}
