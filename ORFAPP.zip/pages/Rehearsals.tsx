
import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { Rehearsal, RehearsalType, Scenario } from '../types';
import { useMetadata } from '../context/MetadataContext';
import { useRehearsals } from '../context/RehearsalsContext';
import { CloseIcon } from '../components/icons/CloseIcon';
import AiCopilotWidget from '../components/AiCopilotWidget';

const REHEARSAL_TYPES: RehearsalType[] = [
    'Unit Test', 'Network Test', 'Application Test', 'Failover Test', 
    'Systems Integration Test', 'BCM Tabletop Test', 'Fully Integrated Test', 
    'Full BCM Test', 'Data Restore Test', 'Technical Recovery Test'
];

const NewRehearsalModal: React.FC<{ 
    isOpen: boolean, 
    onClose: () => void, 
    onSave: (rehearsal: Omit<Rehearsal, 'id' | 'status'>) => void 
    scenarios: Scenario[];
}> = ({ isOpen, onClose, onSave, scenarios }) => {
    const { currentCompany } = useMetadata();
    const [name, setName] = useState('');
    const [type, setType] = useState<RehearsalType>('BCM Tabletop Test');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [objectives, setObjectives] = useState('');
    const [participants, setParticipants] = useState<string[]>([]);
    const [scenarioId, setScenarioId] = useState<string | undefined>();
    
    const notifyUsers = currentCompany?.notifyUsers || [];

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !startDate || !endDate || !objectives) return;
        onSave({ 
            name, type, startDate, endDate, objectives,
            participants, scenarioId
        });
        onClose();
        setName(''); setType('BCM Tabletop Test'); setStartDate(''); setEndDate(''); setObjectives(''); setParticipants([]);
    };

    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-2xl border border-slate-700">
                <form onSubmit={handleSubmit}>
                    <div className="flex justify-between items-center p-4 border-b border-slate-700">
                        <h3 className="text-lg font-semibold">Schedule New Rehearsal</h3>
                        <button type="button" onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                    </div>
                    <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                        <input value={name} onChange={e => setName(e.target.value)} required placeholder="Rehearsal Name" className="w-full bg-slate-700 p-2 rounded-md" />
                        <textarea value={objectives} onChange={e => setObjectives(e.target.value)} required placeholder="Rehearsal Objectives (one per line)" rows={3} className="w-full bg-slate-700 p-2 rounded-md" />
                        <div className="grid grid-cols-2 gap-4">
                            <select value={type} onChange={e => setType(e.target.value as any)} className="w-full bg-slate-700 p-2 rounded-md">
                                {REHEARSAL_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                            </select>
                             <select value={scenarioId} onChange={e => setScenarioId(e.target.value)} className="w-full bg-slate-700 p-2 rounded-md">
                                <option value="">-- Select a Scenario (Optional) --</option>
                                {scenarios.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}
                            </select>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                               <label className="text-sm">Start Date</label>
                               <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} required className="w-full bg-slate-700 p-2 rounded-md" />
                            </div>
                            <div>
                               <label className="text-sm">End Date</label>
                               <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} required className="w-full bg-slate-700 p-2 rounded-md" />
                            </div>
                        </div>
                        <div>
                           <label className="block text-sm">Participants</label>
                           <select multiple value={participants} onChange={e => setParticipants(Array.from(e.target.selectedOptions, o => o.value))} className="w-full bg-slate-700 p-2 rounded-md h-32">
                               {notifyUsers.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                           </select>
                        </div>
                    </div>
                    <div className="text-right p-4 border-t border-slate-700"><button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg">Schedule Rehearsal</button></div>
                </form>
            </div>
        </div>
    )
}

export default function Rehearsals() {
    const { rehearsals, addRehearsal, scenarios } = useRehearsals();
    const { currentCompany } = useMetadata();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [copilotOpen, setCopilotOpen] = useState(false);
    const [copilotPrompt, setCopilotPrompt] = useState('');
    
    const scenarioMap = useMemo(() => new Map(scenarios.map(s => [s.id, s.title])), [scenarios]);

    const getStatusChip = (status: Rehearsal['status']) => {
        switch (status) {
            case 'Completed': return 'bg-green-500/20 text-green-400';
            case 'Planned': return 'bg-blue-500/20 text-blue-400';
            case 'In Progress': return 'bg-yellow-500/20 text-yellow-400';
            case 'Cancelled': return 'bg-slate-500/20 text-slate-400';
            default: return 'bg-gray-500/20 text-gray-400';
        }
    };

    if (!currentCompany) return <Card title="Loading...">Loading company data...</Card>;
    
    const handleAiPostMortem = (rehearsal: Rehearsal) => {
        const prompt = `Generate a post-mortem report for the BCM rehearsal named "${rehearsal.name}".
        
        The objectives were:
        ${rehearsal.objectives}
        
        The final results summary was:
        "${rehearsal.resultsSummary}"
        
        Please structure the report with:
        1. An executive summary.
        2. What went well.
        3. What didn't go well.
        4. Key findings and recommendations for improvement.`;
        
        setCopilotPrompt(prompt);
        setCopilotOpen(true);
    }
    
    const handleSaveRehearsal = (rehearsalData: Omit<Rehearsal, 'id' | 'status'>) => {
        addRehearsal(rehearsalData);
    }

    return (
        <>
        <NewRehearsalModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleSaveRehearsal} scenarios={scenarios} />
        {copilotOpen && <AiCopilotWidget startOpen prefilledInput={copilotPrompt} onClose={() => setCopilotOpen(false)} />}
        <Card title="Rehearsals & Exercises">
             <div className="mb-4 flex justify-between items-center">
                <p className="text-slate-400 text-sm">This is your annual rehearsal plan to validate your BCM program.</p>
                <button onClick={() => setIsModalOpen(true)} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-1.5 px-4 rounded-lg text-sm whitespace-nowrap">
                    Schedule New Rehearsal
                </button>
            </div>
             <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                        <tr>
                            <th className="px-6 py-3">Rehearsal Name</th>
                            <th className="px-6 py-3">Type</th>
                            <th className="px-6 py-3">Date(s)</th>
                            <th className="px-6 py-3">Status</th>
                            <th className="px-6 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rehearsals.sort((a,b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime()).map((rehearsal) => (
                            <tr key={rehearsal.id} className="border-b border-slate-700/50 hover:bg-slate-800/40">
                                <td className="px-6 py-4">
                                    <p className="font-semibold text-slate-200">{rehearsal.name}</p>
                                    <p className="text-xs text-slate-500 truncate max-w-xs">{rehearsal.objectives}</p>
                                    {rehearsal.scenarioId && <p className="text-xs text-cyan-400 mt-1">Scenario: {scenarioMap.get(rehearsal.scenarioId)}</p>}
                                </td>
                                <td className="px-6 py-4">{rehearsal.type}</td>
                                <td className="px-6 py-4">{rehearsal.startDate === rehearsal.endDate ? rehearsal.startDate : `${rehearsal.startDate} to ${rehearsal.endDate}`}</td>
                                <td className="px-6 py-4">
                                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getStatusChip(rehearsal.status)}`}>
                                        {rehearsal.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                    {rehearsal.status === 'Completed' && (
                                        <button onClick={() => handleAiPostMortem(rehearsal)} className="text-cyan-400 hover:underline text-xs">Generate Report</button>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
             {rehearsals.length === 0 && <p className="text-center py-8 text-slate-500">No rehearsals scheduled for this company.</p>}
        </Card>
        </>
    );
};
