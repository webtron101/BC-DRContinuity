
import React from 'react';
import Card from '../components/Card';
import { PCIDSSRequirement } from '../types';
import { useGovernance } from '../context/GovernanceContext';
import { useIT } from '../context/ITContext';

export default function ITSecurity() {
    const { pciDssRequirements, blockedThreats } = useGovernance();
    const { itAssets } = useIT();

    const getStatusChip = (status: PCIDSSRequirement['status']) => {
        switch (status) {
            case 'Completed': return 'bg-green-500/20 text-green-400';
            case 'In Progress': return 'bg-yellow-500/20 text-yellow-400';
            case 'Not Started':
            default: return 'bg-slate-500/20 text-slate-400';
        }
    };
    
    const getThreatChip = (type: string) => {
        switch (type) {
            case 'Ransomware': return 'bg-red-500/20 text-red-400';
            case 'Phishing': return 'bg-orange-500/20 text-orange-400';
            case 'Malware': return 'bg-yellow-500/20 text-yellow-400';
            case 'DDoS': return 'bg-purple-500/20 text-purple-400';
            default: return 'bg-slate-500/20 text-slate-400';
        }
    }
    
     const getSeverityChip = (severity: 'Critical' | 'High' | 'Medium' | 'Low') => {
        switch (severity) {
            case 'Critical': return 'bg-red-500/20 text-red-400';
            case 'High': return 'bg-orange-500/20 text-orange-400';
            case 'Medium': return 'bg-yellow-500/20 text-yellow-400';
            case 'Low': default: return 'bg-blue-500/20 text-blue-400';
        }
    }

    const vulnerabilities = itAssets.flatMap(asset => 
        asset.vulnerabilities.map(vuln => ({ ...vuln, assetName: asset.name, assetId: asset.id }))
    );
    
    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card title="PCI DSS Compliance Dashboard">
                <div className="space-y-4">
                    {pciDssRequirements.map(req => (
                        <div key={req.id} className="bg-slate-800/50 p-4 rounded-lg">
                            <div className="flex justify-between items-center mb-2 flex-wrap gap-2">
                                <h4 className="font-semibold text-slate-200">Goal {req.goal}: {req.requirement}</h4>
                                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getStatusChip(req.status)}`}>
                                    {req.status}
                                </span>
                            </div>
                            <p className="text-sm text-slate-400 mb-3">{req.description}</p>
                             <div className="flex items-center gap-2">
                                <div className="w-full bg-slate-700 rounded-full h-2.5">
                                    <div className="bg-cyan-500 h-2.5 rounded-full" style={{width: `${req.progress}%`}}></div>
                                </div>
                                <span className="font-semibold text-xs text-slate-300">{req.progress}%</span>
                            </div>
                        </div>
                    ))}
                     {pciDssRequirements.length === 0 && <p className="text-center py-8 text-slate-500">No PCI DSS requirements configured.</p>}
                </div>
            </Card>

             <Card title="Recent Blocked Threats">
                 <p className="text-xs text-slate-500 mb-4 -mt-2">Simulating live feed from firewall & EDR...</p>
                 <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-400">
                        <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                            <tr>
                                <th scope="col" className="px-6 py-3">Timestamp</th>
                                <th scope="col" className="px-6 py-3">Type</th>
                                <th scope="col" className="px-6 py-3">Source IP</th>
                            </tr>
                        </thead>
                        <tbody>
                            {blockedThreats.map((threat) => (
                                <tr key={threat.id} className="border-b border-slate-700/50 hover:bg-slate-800/40">
                                    <td className="px-6 py-4 font-mono">{threat.timestamp}</td>
                                    <td className="px-6 py-4">
                                        <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getThreatChip(threat.type)}`}>
                                            {threat.type}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 font-mono">{threat.sourceIp}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                     {blockedThreats.length === 0 && <p className="text-center py-8 text-slate-500">Threat feed is clear.</p>}
                </div>
            </Card>
            
            <div className="lg:col-span-2">
                 <Card title="Security Vulnerabilities">
                     <p className="text-xs text-slate-500 mb-4 -mt-2">Simulating live feed from vulnerability scanner...</p>
                     <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-slate-400">
                            <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                                <tr>
                                    <th scope="col" className="px-6 py-3">Asset</th>
                                    <th scope="col" className="px-6 py-3">CVE</th>
                                    <th scope="col" className="px-6 py-3">Severity</th>
                                    <th scope="col" className="px-6 py-3">Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                {vulnerabilities.map((vuln) => (
                                    <tr key={vuln.cve} className="border-b border-slate-700/50 hover:bg-slate-800/40">
                                        <td className="px-6 py-4 font-semibold">{vuln.assetName}</td>
                                        <td className="px-6 py-4 font-mono">{vuln.cve}</td>
                                        <td className="px-6 py-4">
                                            <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getSeverityChip(vuln.severity)}`}>
                                                {vuln.severity}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-xs">{vuln.description}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {vulnerabilities.length === 0 && <p className="text-center py-8 text-slate-500">No critical vulnerabilities detected.</p>}
                     </div>
                 </Card>
            </div>

        </div>
    );
};