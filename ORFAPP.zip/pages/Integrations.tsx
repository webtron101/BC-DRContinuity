
import React, { useState } from 'react';
import Card from '../components/Card';
import { useMetadata } from '../context/MetadataContext';
import { mockAvailableIntegrations } from '../data/mockData';
import { Integration, IntegrationName, IntegrationStatus } from '../types';
import { CloseIcon } from '../components/icons/CloseIcon';

const getStatusChip = (status: IntegrationStatus) => {
    switch (status) {
        case 'Active': return 'bg-green-500/20 text-green-400';
        case 'Error': return 'bg-red-500/20 text-red-400';
        case 'Inactive':
        default: return 'bg-slate-500/20 text-slate-400';
    }
}

const IntegrationModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    integrationDef: typeof mockAvailableIntegrations[0];
    existingIntegration: Integration;
}> = ({ isOpen, onClose, integrationDef, existingIntegration }) => {
    const { updateIntegration } = useMetadata();
    const [credentials, setCredentials] = useState(existingIntegration.credentials);

    if (!isOpen) return null;

    const handleCredentialChange = (key: string, value: string) => {
        setCredentials(prev => ({ ...prev, [key]: value }));
    };

    const handleSave = () => {
        updateIntegration(integrationDef.id, { credentials, status: 'Active' });
        onClose();
    };

    const handleDisconnect = () => {
        const clearedCredentials = Object.fromEntries(Object.keys(credentials).map(key => [key, '']));
        updateIntegration(integrationDef.id, { credentials: clearedCredentials, status: 'Inactive' });
        onClose();
    }

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <div className="flex items-center gap-3">
                        <integrationDef.logo className="w-8 h-8" />
                        <h3 className="text-lg font-semibold">Configure {integrationDef.name}</h3>
                    </div>
                    <button type="button" onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </div>
                <div className="p-6 space-y-4">
                    <p className="text-sm text-slate-400 -mt-2">{integrationDef.description}</p>
                    {integrationDef.fields.map(field => (
                        <div key={field.key}>
                            <label htmlFor={field.key} className="block text-sm font-medium text-slate-300 mb-1">{field.label}</label>
                            <input
                                id={field.key}
                                type={field.type}
                                value={credentials[field.key] || ''}
                                onChange={e => handleCredentialChange(field.key, e.target.value)}
                                className="w-full bg-slate-700 p-2 rounded-md font-mono text-sm"
                            />
                        </div>
                    ))}
                </div>
                <div className="flex justify-between p-4 border-t border-slate-700">
                    <button onClick={handleDisconnect} className="bg-red-600/20 hover:bg-red-600/40 text-red-300 font-semibold py-2 px-4 rounded-lg text-sm">Disconnect</button>
                    <button onClick={handleSave} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg">Save & Connect</button>
                </div>
            </div>
        </div>
    );
};

export default function Integrations() {
    const { currentCompany } = useMetadata();
    const [selectedIntegrationId, setSelectedIntegrationId] = useState<IntegrationName | null>(null);

    const configuredIntegrations = new Map(currentCompany?.integrations.map(i => [i.id, i]));

    const handleConfigure = (id: IntegrationName) => {
        setSelectedIntegrationId(id);
    };

    const selectedDef = mockAvailableIntegrations.find(i => i.id === selectedIntegrationId);
    const selectedConfig = selectedIntegrationId ? configuredIntegrations.get(selectedIntegrationId) : null;

    return (
        <>
            {selectedDef && selectedConfig && (
                <IntegrationModal 
                    isOpen={!!selectedIntegrationId}
                    onClose={() => setSelectedIntegrationId(null)}
                    integrationDef={selectedDef}
                    existingIntegration={selectedConfig}
                />
            )}
            <Card title="Integrations Marketplace">
                <p className="text-sm text-slate-400 -mt-2 mb-6">Connect to third-party applications to automate workflows and extend the functionality of Open Resilience.</p>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {mockAvailableIntegrations.map(integration => {
                        const config = configuredIntegrations.get(integration.id);
                        const status = config?.status || 'Inactive';

                        return (
                            <div key={integration.id} className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6 flex flex-col">
                                <div className="flex items-start justify-between">
                                    <div className="flex items-center gap-4">
                                        <integration.logo className="w-10 h-10" />
                                        <h3 className="font-bold text-lg text-slate-200">{integration.name}</h3>
                                    </div>
                                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getStatusChip(status)}`}>
                                        {status}
                                    </span>
                                </div>
                                <p className="text-sm text-slate-400 mt-4 flex-grow">{integration.description}</p>
                                <div className="mt-6 text-right">
                                    <button onClick={() => handleConfigure(integration.id)} className="bg-slate-700 hover:bg-slate-600 text-white font-semibold py-1.5 px-4 rounded-lg text-sm">
                                        Configure
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </Card>
        </>
    );
}
