
import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { useIT } from '../context/ITContext';
import { BattleboxItem, RiskLevel } from '../types';
import { CloseIcon } from '../components/icons/CloseIcon';

const getRiskLevelInfo = (level: RiskLevel) => {
    switch (level) {
        case RiskLevel.Critical: return { text: 'Critical', color: 'bg-red-500/20 text-red-400' };
        case RiskLevel.High: return { text: 'High', color: 'bg-orange-500/20 text-orange-400' };
        case RiskLevel.Medium: return { text: 'Medium', color: 'bg-yellow-500/20 text-yellow-400' };
        case RiskLevel.Low: default: return { text: 'Low', color: 'bg-green-500/20 text-green-400' };
    }
};

const NewItemModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (item: BattleboxItem) => void;
}> = ({ isOpen, onClose, onSave }) => {
    const [name, setName] = useState('');
    const [type, setType] = useState<BattleboxItem['type']>('Software');
    const [description, setDescription] = useState('');
    const [location, setLocation] = useState('');
    const [criticality, setCriticality] = useState<RiskLevel>(RiskLevel.High);
    const [lastVerified, setLastVerified] = useState(new Date().toISOString().split('T')[0]);

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            id: `bb-${Date.now()}`,
            name, type, description, location, criticality, lastVerified,
        });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-2xl border border-slate-700">
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h3 className="text-lg font-semibold">Add New Battlebox Item</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                    <input value={name} onChange={e => setName(e.target.value)} required placeholder="Item Name (e.g., AD VM Image)" className="w-full bg-slate-700 p-2 rounded-md" />
                    <textarea value={description} onChange={e => setDescription(e.target.value)} required placeholder="Description" rows={3} className="w-full bg-slate-700 p-2 rounded-md" />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <select value={type} onChange={e => setType(e.target.value as any)} className="w-full bg-slate-700 p-2 rounded-md">
                            <option>Software</option><option>Document</option><option>Credential</option><option>Service</option>
                        </select>
                        <select value={criticality} onChange={e => setCriticality(Number(e.target.value))} className="w-full bg-slate-700 p-2 rounded-md">
                             {Object.keys(RiskLevel).filter(k => isNaN(Number(k))).map((level, i) => (
                                <option key={i} value={i}>{level}</option>
                            ))}
                        </select>
                    </div>
                     <input value={location} onChange={e => setLocation(e.target.value)} required placeholder="Location (URL, Path, Vault Reference)" className="w-full bg-slate-700 p-2 rounded-md" />
                     <div>
                        <label htmlFor="lastVerified" className="block text-sm font-medium text-slate-300 mb-1">Last Verified</label>
                        <input type="date" id="lastVerified" value={lastVerified} onChange={e => setLastVerified(e.target.value)} required className="w-full bg-slate-700 p-2 rounded-md" />
                     </div>
                    <div className="text-right pt-4"><button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg">Save Item</button></div>
                </form>
            </div>
        </div>
    );
};


export default function Battlebox() {
    const { battleboxItems, addBattleboxItem } = useIT();
    
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);

    const filteredItems = useMemo(() => {
        return battleboxItems.filter(item => 
            item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item.description.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [searchTerm, battleboxItems]);

    const handleSaveItem = (item: BattleboxItem) => {
        addBattleboxItem(item);
        setIsModalOpen(false);
    };

    return (
        <>
            <NewItemModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleSaveItem} />
            <Card title="Software Battlebox">
                <p className="text-sm text-slate-400 mb-6 -mt-2">This is a secure inventory of all software, documents, and credentials needed for a full disaster recovery. Locations should point to secure, off-site storage.</p>

                <div className="mb-4 flex flex-wrap gap-4 items-center">
                    <input
                        type="text"
                        placeholder="Search battlebox..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="flex-grow bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500"
                    />
                    <button onClick={() => setIsModalOpen(true)} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg text-sm">
                        Add New Item
                    </button>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-400">
                        <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                            <tr>
                                <th scope="col" className="px-6 py-3">Item Name</th>
                                <th scope="col" className="px-6 py-3">Type</th>
                                <th scope="col" className="px-6 py-3">Criticality</th>
                                <th scope="col" className="px-6 py-3">Location / Reference</th>
                                <th scope="col" className="px-6 py-3">Last Verified</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredItems.map(item => (
                                <tr key={item.id} className="border-b border-slate-700/50 hover:bg-slate-800/40">
                                    <td className="px-6 py-4 font-medium text-slate-200">
                                        <p>{item.name}</p>
                                        <p className="text-xs text-slate-500">{item.description}</p>
                                    </td>
                                    <td className="px-6 py-4">{item.type}</td>
                                    <td className="px-6 py-4">
                                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${getRiskLevelInfo(item.criticality).color}`}>
                                            {getRiskLevelInfo(item.criticality).text}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 font-mono text-cyan-400 break-all">{item.location}</td>
                                    <td className="px-6 py-4">{item.lastVerified}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                     {filteredItems.length === 0 && <p className="text-center py-8 text-slate-500">No battlebox items match your search.</p>}
                </div>
            </Card>
        </>
    );
}
