


import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { useMetadata } from '../context/MetadataContext';
import { useDocuments } from '../context/DocumentsContext';
import { CloseIcon } from '../components/icons/CloseIcon';

const TABS = ['Mass Notification', 'User Directory'];
const NOTIFY_METHODS = ['Email', 'SMS', 'WhatsApp', 'Slack', 'Teams'];

const PlaceholderModal: React.FC<{isOpen: boolean, onClose: ()=>void}> = ({isOpen, onClose}) => {
    if(!isOpen) return null;
    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-sm border border-slate-700 p-6 text-center">
                <h3 className="text-lg font-semibold">Feature Coming Soon</h3>
                <p className="text-slate-400 mt-2 text-sm">This feature is part of our premium offering or is currently under development. Contact sales for more information.</p>
                <button onClick={onClose} className="mt-4 bg-cyan-600 px-4 py-2 rounded-lg text-sm">Close</button>
            </div>
        </div>
    )
}

function MassNotificationView() {
    const { currentCompany } = useMetadata();
    const { notificationTemplates } = useDocuments();
    const notifyUsers = currentCompany?.notifyUsers || [];
    
    const [method, setMethod] = useState(NOTIFY_METHODS[0]);
    const [recipients, setRecipients] = useState<string[]>([]);
    const [subject, setSubject] = useState('');
    const [message, setMessage] = useState('');

    const isTwilioActive = currentCompany?.integrations.find(i => i.id === 'Twilio')?.status === 'Active';
    
    const handleSend = () => {
        if(recipients.length === 0 || message.trim() === '') {
            alert('Please select recipients and write a message.');
            return;
        }
        const recipientDetails = recipients.map(id => notifyUsers.find(u=>u.id === id)?.name).join(', ');
        
        let alertMessage = `Message sent via ${method} to ${recipientDetails}.\n\nSubject: ${subject}\n\nMessage: ${message}`;
        if (method === 'SMS' && isTwilioActive) {
            alertMessage = `(Mock) Sending SMS via Twilio to ${recipientDetails}.\n\nMessage: ${message}`;
        }
        alert(alertMessage);
        
        // Reset form
        setRecipients([]);
        setSubject('');
        setMessage('');
    }
    
    const handleTemplateChange = (templateId: string) => {
        const template = notificationTemplates.find(t => t.id === templateId);
        if (template) {
            setSubject(template.subject);
            setMessage(template.body);
        } else {
            setSubject('');
            setMessage('');
        }
    }

    return (
        <Card title="Send Notification">
            <div className="flex border-b border-slate-700/50 mb-6">
                {NOTIFY_METHODS.map(m => (
                    <button
                        key={m}
                        onClick={() => setMethod(m)}
                        className={`px-4 py-2 text-sm font-medium transition-colors rounded-t-lg
                            ${method === m 
                                ? 'bg-slate-700/50 text-cyan-400' 
                                : 'text-slate-400 hover:text-slate-200'
                            }`}
                    >
                        {m}
                        {m === 'SMS' && isTwilioActive && <span className="text-xs text-green-400 ml-1">(Active)</span>}
                    </button>
                ))}
            </div>
            
            <div className="space-y-4">
                 <div>
                    <label htmlFor="recipients" className="block text-sm font-medium text-slate-300 mb-1">Recipients</label>
                    <select
                        id="recipients"
                        multiple
                        value={recipients}
                        onChange={(e) => setRecipients(Array.from(e.target.selectedOptions, option => option.value))}
                        className="w-full bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500 h-32"
                    >
                        {notifyUsers.map(user => (
                            <option key={user.id} value={user.id}>{user.name} ({user.role})</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label htmlFor="template" className="block text-sm font-medium text-slate-300 mb-1">Use Template</label>
                     <select
                        id="template"
                        onChange={(e) => handleTemplateChange(e.target.value)}
                        className="w-full bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500"
                    >
                        <option value="">-- No Template --</option>
                        {notificationTemplates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                    </select>
                </div>
                {method === 'Email' && (
                    <div>
                        <label htmlFor="subject" className="block text-sm font-medium text-slate-300 mb-1">Subject</label>
                        <input
                            type="text"
                            id="subject"
                            value={subject}
                            onChange={(e) => setSubject(e.target.value)}
                            className="w-full bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500"
                        />
                    </div>
                )}
                 <div>
                    <label htmlFor="message" className="block text-sm font-medium text-slate-300 mb-1">Message</label>
                    <textarea
                        id="message"
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        rows={8}
                        className="w-full bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500"
                    ></textarea>
                </div>
                <div className="text-right">
                    <button onClick={handleSend} className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-6 rounded-lg text-sm">
                        Send Notification
                    </button>
                </div>
            </div>
        </Card>
    );
};

function UserDirectoryView() {
    const { currentCompany } = useMetadata();
    const notifyUsers = currentCompany?.notifyUsers || [];

    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);

    const filteredUsers = useMemo(() => {
        return notifyUsers.filter(user => 
            user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.role.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [searchTerm, notifyUsers]);

    return (
        <>
        <PlaceholderModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
        <Card title="User Directory">
            <div className="mb-4 flex flex-wrap gap-4 items-center">
                 <input
                    type="text"
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="flex-grow bg-slate-700 border-slate-600 rounded-md p-2 text-sm focus:ring-cyan-500 focus:border-cyan-500"
                />
                 <button onClick={() => setIsModalOpen(true)} className="bg-slate-600 hover:bg-slate-500 text-white font-semibold py-2 px-4 rounded-lg text-sm">
                    Import Users
                </button>
            </div>
             <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                        <tr>
                            <th scope="col" className="px-6 py-3">Name</th>
                            <th scope="col" className="px-6 py-3">Role</th>
                            <th scope="col" className="px-6 py-3">Email</th>
                            <th scope="col" className="px-6 py-3">Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredUsers.map((user) => (
                            <tr key={user.id} className="border-b border-slate-700/50 hover:bg-slate-800/40">
                                <td className="px-6 py-4 font-medium text-slate-200">{user.name}</td>
                                <td className="px-6 py-4">{user.role}</td>
                                <td className="px-6 py-4">{user.email}</td>
                                <td className="px-6 py-4">{user.phone}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {filteredUsers.length === 0 && <p className="text-center py-8 text-slate-500">No users found.</p>}
            </div>
        </Card>
        </>
    );
};

export default function Notify() {
    const [activeTab, setActiveTab] = useState(TABS[0]);
    const { currentCompany } = useMetadata();
    
    if (!currentCompany) return <Card title="Loading...">Loading company data...</Card>;

    const renderContent = () => {
        switch (activeTab) {
            case 'Mass Notification': return <MassNotificationView />;
            case 'User Directory': return <UserDirectoryView />;
            default: return null;
        }
    };

    return (
        <div className="flex flex-col gap-6">
            <div className="flex border-b border-slate-700">
                {TABS.map(tab => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`px-4 py-2 text-sm font-medium transition-colors
                            ${activeTab === tab 
                                ? 'border-b-2 border-cyan-400 text-cyan-400' 
                                : 'text-slate-400 hover:text-slate-200'
                            }`}
                    >
                        {tab}
                    </button>
                ))}
            </div>
            <div>{renderContent()}</div>
        </div>
    );
};
