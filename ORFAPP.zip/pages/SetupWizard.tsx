import React, { useState, useEffect } from 'react';
import { useMetadata } from '../context/MetadataContext';
import { useAuth } from '../context/AuthContext';
import { CompanyMetadata, KeyContact, CompanySite } from '../types';
import { CloseIcon } from '../components/icons/CloseIcon';

const StepIndicator: React.FC<{ currentStep: number; totalSteps: number }> = ({ currentStep, totalSteps }) => (
    <div className="flex items-center w-full max-w-md">
        {Array.from({ length: totalSteps }).map((_, index) => {
            const step = index + 1;
            const isCompleted = step < currentStep;
            const isActive = step === currentStep;
            return (
                <React.Fragment key={step}>
                    <div className="flex flex-col items-center">
                        <div
                            className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg transition-all duration-300
                            ${isCompleted ? 'bg-cyan-600 text-white' : ''}
                            ${isActive ? 'bg-cyan-500/20 text-cyan-400 border-2 border-cyan-400' : ''}
                            ${!isCompleted && !isActive ? 'bg-slate-700 text-slate-400' : ''}
                            `}
                        >
                            {isCompleted ? '✓' : step}
                        </div>
                    </div>
                    {step < totalSteps && <div className={`flex-1 h-1 transition-all duration-300 ${isCompleted ? 'bg-cyan-600' : 'bg-slate-700'}`}></div>}
                </React.Fragment>
            );
        })}
    </div>
);

export default function SetupWizard() {
    const { currentCompany, updateCurrentCompany } = useMetadata();
    const { user } = useAuth();
    const [step, setStep] = useState(1);
    
    const [formData, setFormData] = useState<CompanyMetadata>({
        name: '',
        address: '',
        logoUrl: '',
        keyContacts: [],
        sites: [],
    });

    useEffect(() => {
        if(currentCompany) {
            setFormData({
                name: currentCompany.name,
                address: currentCompany.address,
                logoUrl: currentCompany.logoUrl || '',
                keyContacts: currentCompany.keyContacts.length > 0 ? currentCompany.keyContacts : [{id: `kc${Date.now()}`, name: user?.name || '', role: 'BCM Manager (Custodian)', email: ''}],
                sites: currentCompany.sites.length > 0 ? currentCompany.sites : [{id: `s${Date.now()}`, name: 'Headquarters', location: ''}],
            });
        }
    }, [currentCompany, user]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleListChange = (
        listName: 'keyContacts' | 'sites', 
        index: number, 
        field: keyof KeyContact | keyof CompanySite, 
        value: string
    ) => {
        setFormData(prev => {
            if (listName === 'keyContacts') {
                const newList = [...prev.keyContacts];
                newList[index] = {...newList[index], [field as keyof KeyContact]: value};
                return {...prev, keyContacts: newList};
            } else { // listName === 'sites'
                const newList = [...prev.sites];
                newList[index] = {...newList[index], [field as keyof CompanySite]: value};
                return {...prev, sites: newList};
            }
        });
    }
    
    const addListItem = (listName: 'keyContacts' | 'sites') => {
        const newItem = listName === 'sites'
            ? { id: `s${Date.now()}`, name: '', location: '' }
            : { id: `kc${Date.now()}`, name: '', role: '', email: '' };
        setFormData(prev => ({...prev, [listName]: [...(prev[listName] as any[]), newItem]}));
    }
    
    const removeListItem = (listName: 'keyContacts' | 'sites', index: number) => {
        setFormData(prev => {
            const newList = [...(prev[listName] as any[])];
            newList.splice(index, 1);
            return {...prev, [listName]: newList};
        });
    }

    const handleSave = () => {
        updateCurrentCompany(formData, true); // Mark wizard as complete
    }
    
    const TOTAL_STEPS = 4;
    
    return (
        <div className="flex flex-col items-center justify-center h-full p-6">
            <div className="w-full max-w-3xl bg-slate-800 rounded-xl border border-slate-700/50 shadow-2xl p-8 flex flex-col items-center">
                 <h1 className="text-3xl font-bold text-slate-100 mb-2">Company Setup</h1>
                 <p className="text-slate-400 mb-8">Let's get your organization's basic details configured.</p>

                <StepIndicator currentStep={step} totalSteps={TOTAL_STEPS} />
            
                <div className="w-full max-w-2xl mt-8">
                {step === 1 && (
                    <div className="animate-fade-in space-y-4">
                        <h2 className="text-xl font-semibold text-slate-200 mb-2">Company Profile</h2>
                        <div>
                            <label htmlFor="name">Company Name</label>
                            <input type="text" name="name" id="name" value={formData.name} onChange={handleInputChange} className="w-full bg-slate-700 p-2 rounded-md mt-1"/>
                        </div>
                        <div>
                            <label htmlFor="address">Primary Address</label>
                            <textarea name="address" id="address" value={formData.address} onChange={handleInputChange} rows={3} className="w-full bg-slate-700 p-2 rounded-md mt-1"></textarea>
                        </div>
                    </div>
                )}
                
                {step === 2 && (
                    <div className="animate-fade-in space-y-4">
                        <h2 className="text-xl font-semibold text-slate-200 mb-2">Locations / Sites</h2>
                        <div className="space-y-3">
                        {formData.sites.map((site, index) => (
                            <div key={site.id} className="flex gap-4 p-3 bg-slate-900/50 rounded-lg items-center">
                                <input type="text" placeholder="Site Name (e.g., London HQ)" value={site.name} onChange={(e) => handleListChange('sites', index, 'name', e.target.value)} className="flex-1 bg-slate-700 p-2 rounded-md"/>
                                <input type="text" placeholder="Location (e.g., London, UK)" value={site.location} onChange={(e) => handleListChange('sites', index, 'location', e.target.value)} className="flex-1 bg-slate-700 p-2 rounded-md"/>
                                <button type="button" onClick={() => removeListItem('sites', index)} className="text-slate-400 hover:text-red-400 p-1"><CloseIcon className="w-5 h-5"/></button>
                            </div>
                        ))}
                        </div>
                        <button type="button" onClick={() => addListItem('sites')} className="mt-4 text-cyan-400 hover:text-cyan-300 font-semibold text-sm">+ Add Location</button>
                    </div>
                )}
                
                {step === 3 && (
                    <div className="animate-fade-in space-y-4">
                        <h2 className="text-xl font-semibold text-slate-200 mb-2">BCM Roles & Custodians</h2>
                        <div className="space-y-3">
                        {formData.keyContacts.map((contact, index) => (
                            <div key={contact.id} className="grid grid-cols-1 md:grid-cols-3 gap-4 p-3 bg-slate-900/50 rounded-lg items-center">
                                <input type="text" placeholder="Name" value={contact.name} onChange={(e) => handleListChange('keyContacts', index, 'name', e.target.value)} className="bg-slate-700 p-2 rounded-md"/>
                                <input type="text" placeholder="Role (e.g., BCM Manager (Custodian))" value={contact.role} onChange={(e) => handleListChange('keyContacts', index, 'role', e.target.value)} className="bg-slate-700 p-2 rounded-md"/>
                            <div className="flex gap-2">
                            <input type="email" placeholder="Email" value={contact.email} onChange={(e) => handleListChange('keyContacts', index, 'email', e.target.value)} className="flex-1 bg-slate-700 p-2 rounded-md"/>
                            <button type="button" onClick={() => removeListItem('keyContacts', index)} className="text-slate-400 hover:text-red-400 p-1"><CloseIcon className="w-5 h-5"/></button>
                            </div>
                            </div>
                        ))}
                        </div>
                        <button type="button" onClick={() => addListItem('keyContacts')} className="mt-4 text-cyan-400 hover:text-cyan-300 font-semibold text-sm">+ Add Role/Custodian</button>
                    </div>
                )}

                {step === TOTAL_STEPS && (
                    <div className="animate-fade-in">
                        <h2 className="text-xl font-semibold text-slate-200 mb-4">Review & Save</h2>
                        <div className="bg-slate-900/50 p-6 rounded-lg space-y-4">
                            <div><p><strong className="text-slate-400">Name:</strong> {formData.name}</p></div>
                             <div><h3 className="font-semibold text-slate-300">Locations</h3>
                                <ul className="list-disc list-inside text-slate-400">
                                    {formData.sites.map(s => <li key={s.id}>{s.name} ({s.location})</li>)}
                                </ul>
                            </div>
                            <div><h3 className="font-semibold text-slate-300">Key Contacts</h3>
                                <ul className="list-disc list-inside text-slate-400">
                                    {formData.keyContacts.map(c => <li key={c.id}>{c.name} ({c.role})</li>)}
                                </ul>
                            </div>
                        </div>
                    </div>
                )}
                </div>


                <div className="mt-8 flex justify-between w-full max-w-2xl">
                    <button
                        onClick={() => setStep(s => s - 1)}
                        disabled={step === 1}
                        className="bg-slate-600 hover:bg-slate-500 text-white font-semibold py-2 px-4 rounded-lg text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Back
                    </button>
                    {step < TOTAL_STEPS ? (
                        <button
                            onClick={() => setStep(s => s + 1)}
                            className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-2 px-4 rounded-lg text-sm"
                        >
                            Next
                        </button>
                    ) : (
                        <button
                            onClick={handleSave}
                            className="bg-green-600 hover:bg-green-500 text-white font-semibold py-2 px-6 rounded-lg text-sm"
                        >
                            Save & Finish Setup
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};