
import React, { useState, useMemo } from 'react';
import Card from '../components/Card';
import { useThirdPartyRisk } from '../context/ThirdPartyRiskContext';
import { useBIA } from '../context/BIAContext';
import { Service, RiskLevel, SuppliedService, Vendor, ThirdPartyAssessmentAnswer, VendorCertificate, SLA } from '../types';
import { CloseIcon } from '../components/icons/CloseIcon';
import { ExternalLinkIcon } from '../components/icons/ExternalLinkIcon';

const TABS = ['Vendors', 'Supplied Services (SLAs)', 'Internal Services (OLAs)'];

const getRiskLevelInfo = (level: RiskLevel) => {
    switch (level) {
        case RiskLevel.Critical: return { text: 'Critical', color: 'bg-red-500/20 text-red-400' };
        case RiskLevel.High: return { text: 'High', color: 'bg-orange-500/20 text-orange-400' };
        case RiskLevel.Medium: return { text: 'Medium', color: 'bg-yellow-500/20 text-yellow-400' };
        default: return { text: 'Low', color: 'bg-green-500/20 text-green-400' };
    }
};

const VendorModal: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (data: Omit<Vendor, 'id' | 'riskScore' | 'assessments' | 'certificates'>) => void }> = ({ isOpen, onClose, onSave }) => {
    const [name, setName] = useState('');
    const [contactPerson, setContactPerson] = useState('');
    const [contactEmail, setContactEmail] = useState('');
    const [contactPhone, setContactPhone] = useState('');
    const [tier, setTier] = useState<'1' | '2' | '3'>('3');

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ name, contactPerson, contactEmail, contactPhone, tier });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <h3 className="text-lg font-semibold">Add New Vendor</h3>
                    <input value={name} onChange={e => setName(e.target.value)} required placeholder="Vendor Name" className="w-full bg-slate-700 p-2 rounded-md" />
                    <input value={contactPerson} onChange={e => setContactPerson(e.target.value)} required placeholder="Primary Contact" className="w-full bg-slate-700 p-2 rounded-md" />
                    <input type="email" value={contactEmail} onChange={e => setContactEmail(e.target.value)} required placeholder="Contact Email" className="w-full bg-slate-700 p-2 rounded-md" />
                    <input type="tel" value={contactPhone} onChange={e => setContactPhone(e.target.value)} placeholder="Contact Phone" className="w-full bg-slate-700 p-2 rounded-md" />
                    <select value={tier} onChange={e => setTier(e.target.value as any)} className="w-full bg-slate-700 p-2 rounded-md"><option value="1">Tier 1</option><option value="2">Tier 2</option><option value="3">Tier 3</option></select>
                    <div className="text-right pt-4"><button type="submit" className="bg-cyan-600 px-4 py-2 rounded-lg">Save Vendor</button></div>
                </form>
            </div>
        </div>
    );
};

const VendorDetailsModal: React.FC<{ vendor: Vendor, onClose: () => void }> = ({ vendor, onClose }) => {
    const { assessmentQuestions, updateVendorAssessment, addVendorCertificate, generateVendorAccessKey } = useThirdPartyRisk();
    const [activeTab, setActiveTab] = useState('Details');
    const [answers, setAnswers] = useState<ThirdPartyAssessmentAnswer[]>(vendor.assessments);
    const [portalLink, setPortalLink] = useState('');

    const handleAnswerChange = (questionId: string, answer: ThirdPartyAssessmentAnswer['answer']) => {
        const existing = answers.find(a => a.questionId === questionId);
        if (existing) {
            setAnswers(answers.map(a => a.questionId === questionId ? { ...a, answer } : a));
        } else {
            setAnswers([...answers, { questionId, answer, comment: '' }]);
        }
    };
    
    const handleSaveAssessment = () => {
        updateVendorAssessment(vendor.id, answers);
        alert('Assessment saved!');
    };
    
    const handleAddCert = () => {
        const newCert: Omit<VendorCertificate, 'id'> = { name: 'ISO 27001', fileUrl: '#', expiryDate: new Date().toISOString().split('T')[0] };
        addVendorCertificate(vendor.id, newCert);
    };
    
    const handleGenerateLink = () => {
        const key = generateVendorAccessKey(vendor.id);
        const url = `${window.location.origin}${window.location.pathname}#/vendor-portal/${vendor.id}/${key}`;
        setPortalLink(url);
    }
    
    const handleCopyLink = () => {
        navigator.clipboard.writeText(portalLink).then(() => {
            alert('Portal link copied to clipboard!');
        });
    }

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-4xl border border-slate-700 h-[80vh] flex flex-col">
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h3 className="text-lg font-semibold">{vendor.name} - Risk Profile</h3>
                    <button onClick={onClose}><CloseIcon className="w-6 h-6" /></button>
                </div>
                <div className="flex border-b border-slate-700">
                    <button onClick={() => setActiveTab('Details')} className={`px-4 py-2 text-sm ${activeTab==='Details' && 'border-b-2 border-cyan-400 text-cyan-400'}`}>Details</button>
                    <button onClick={() => setActiveTab('Assessment')} className={`px-4 py-2 text-sm ${activeTab==='Assessment' && 'border-b-2 border-cyan-400 text-cyan-400'}`}>Assessment</button>
                    <button onClick={() => setActiveTab('Certificates')} className={`px-4 py-2 text-sm ${activeTab==='Certificates' && 'border-b-2 border-cyan-400 text-cyan-400'}`}>Certificates</button>
                    <button onClick={() => setActiveTab('Portal Access')} className={`px-4 py-2 text-sm ${activeTab==='Portal Access' && 'border-b-2 border-cyan-400 text-cyan-400'}`}>Portal Access</button>
                </div>
                <div className="p-6 flex-grow overflow-y-auto">
                    {activeTab === 'Details' && (
                        <div>Details for {vendor.name}</div>
                    )}
                    {activeTab === 'Assessment' && (
                        <div className="space-y-4">
                            {assessmentQuestions.map(q => (
                                <div key={q.id}>
                                    <p className="font-semibold">{q.text}</p>
                                    <div className="flex gap-4 mt-2">
                                        {(['Yes', 'No', 'Partial', 'N/A'] as const).map(opt => (
                                            <label key={opt} className="flex items-center gap-2 text-sm">
                                                <input type="radio" name={`q-${q.id}`} value={opt} checked={answers.find(a=>a.questionId === q.id)?.answer === opt} onChange={() => handleAnswerChange(q.id, opt)} className="h-4 w-4 text-cyan-500 bg-slate-700" />
                                                {opt}
                                            </label>
                                        ))}
                                    </div>
                                </div>
                            ))}
                            <div className="text-right pt-4"><button onClick={handleSaveAssessment} className="bg-cyan-600 px-4 py-2 rounded-lg">Save Assessment</button></div>
                        </div>
                    )}
                    {activeTab === 'Certificates' && (
                        <div>
                            <div className="text-right mb-4"><button onClick={handleAddCert} className="bg-cyan-600 px-4 py-2 rounded-lg text-sm">Upload Certificate</button></div>
                            <table className="w-full text-sm">
                                <thead className="text-left text-xs uppercase text-slate-400"><tr><th className="p-2">Certificate Name</th><th className="p-2">Expiry Date</th><th className="p-2">File</th></tr></thead>
                                <tbody>{vendor.certificates.map(c => (<tr key={c.id} className="border-b border-slate-700"><td className="p-2">{c.name}</td><td className="p-2">{c.expiryDate}</td><td className="p-2"><a href={c.fileUrl}>View</a></td></tr>))}</tbody>
                            </table>
                        </div>
                    )}
                    {activeTab === 'Portal Access' && (
                        <div className="space-y-4">
                            <h4 className="text-lg font-semibold text-slate-200">Vendor Portal Access</h4>
                            <p className="text-sm text-slate-400">Generate a unique, secure link to send to this vendor. They can use this link to complete their risk assessment directly, without needing a user account.</p>
                            <button onClick={handleGenerateLink} className="bg-cyan-600 text-white font-bold py-2 px-4 rounded-lg flex items-center gap-2">
                                <ExternalLinkIcon className="w-5 h-5"/>
                                Generate Secure Link
                            </button>
                            {portalLink && (
                                <div className="mt-4 space-y-2">
                                    <p className="text-sm text-slate-300">Share this link with your contact at {vendor.name}:</p>
                                    <div className="flex gap-2">
                                        <input type="text" readOnly value={portalLink} className="w-full bg-slate-700 p-2 rounded-md font-mono text-cyan-300"/>
                                        <button onClick={handleCopyLink} className="bg-slate-600 px-4 py-2 rounded-lg">Copy</button>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}

const VendorsView: React.FC = () => {
    const { vendors, addVendor } = useThirdPartyRisk();
    const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    
    return (
        <>
            {selectedVendor && <VendorDetailsModal vendor={selectedVendor} onClose={() => setSelectedVendor(null)} />}
            <VendorModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={addVendor} />
            <Card title="Vendor Directory & Risk Rating">
                <div className="text-right mb-4">
                    <button onClick={() => setIsModalOpen(true)} className="bg-cyan-600 text-white font-bold py-2 px-4 rounded">Add Vendor</button>
                </div>
                <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs text-slate-400 uppercase bg-slate-900/30">
                        <tr>
                            <th className="px-6 py-3">Vendor Name</th>
                            <th className="px-6 py-3">Tier</th>
                            <th className="px-6 py-3">Risk Score</th>
                            <th className="px-6 py-3">Contact Person</th>
                        </tr>
                    </thead>
                    <tbody>
                        {vendors.map(v => (
                            <tr key={v.id} className="border-b border-slate-700/50 hover:bg-slate-800/40 cursor-pointer" onClick={() => setSelectedVendor(v)}>
                                <td className="px-6 py-4 font-semibold text-slate-200">{v.name}</td>
                                <td className="px-6 py-4">{v.tier}</td>
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-2">
                                        <div className="w-full bg-slate-700 rounded-full h-2.5">
                                            <div className={`${v.riskScore > 75 ? 'bg-green-500' : v.riskScore > 40 ? 'bg-yellow-500' : 'bg-red-500'} h-2.5 rounded-full`} style={{ width: `${v.riskScore}%` }}></div>
                                        </div>
                                        <span className="font-semibold text-xs">{v.riskScore}</span>
                                    </div>
                                </td>
                                <td className="px-6 py-4">{v.contactPerson}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </Card>
        </>
    );
};

const BreachModal: React.FC<{ isOpen: boolean, onClose: () => void, onSave: (description: string) => void, serviceName: string }> = ({ isOpen, onClose, onSave, serviceName }) => {
    const [description, setDescription] = useState('');
    if (!isOpen) return null;
    return (
         <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg border border-slate-700">
                <div className="p-6 space-y-4">
                    <h3 className="text-lg font-semibold">Log SLA Breach for {serviceName}</h3>
                    <textarea value={description} onChange={e => setDescription(e.target.value)} required placeholder="Breach description" rows={4} className="w-full bg-slate-700 p-2 rounded-md" />
                    <div className="flex justify-end gap-4 pt-4">
                        <button onClick={onClose} className="bg-slate-600 px-4 py-2 rounded-lg">Cancel</button>
                        <button onClick={() => { onSave(description); onClose();}} className="bg-red-600 px-4 py-2 rounded-lg">Log Breach</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

const ServicesView: React.FC<{type: 'internal' | 'external'}> = ({ type }) => {
    const { services: internalServices } = useBIA();
    const { suppliedServices, vendors, logSlaBreach } = useThirdPartyRisk();
    const [loggingBreachFor, setLoggingBreachFor] = useState<Service | SuppliedService | null>(null);
    
    const services = type === 'internal' ? internalServices : suppliedServices;
    const vendorMap = useMemo(() => new Map(vendors.map(v => [v.id, v.name])), [vendors]);

    return(
        <>
            {loggingBreachFor && <BreachModal isOpen={!!loggingBreachFor} onClose={() => setLoggingBreachFor(null)} onSave={(desc) => logSlaBreach(loggingBreachFor.id, { description: desc })} serviceName={loggingBreachFor.name} />}
            <Card title={type === 'internal' ? "Internal Service Level Agreements (OLAs)" : "Third-Party Service Level Agreements (SLAs)"}>
                <div className="text-right mb-4">
                    <button className="bg-cyan-600 text-white font-bold py-2 px-4 rounded">Add Service</button>
                </div>
                <div className="space-y-4">
                {services.map(s => {
                    const service = s;
                    const riskInfo = getRiskLevelInfo(service.criticality);
                    const sla = 'ola' in service ? service.ola : service.sla;
                    return (
                        <div key={service.id} className="bg-slate-800/50 rounded-lg p-4 border border-slate-700/50">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h4 className="text-lg font-semibold text-slate-200">{service.name}</h4>
                                    <p className="text-sm text-slate-400">{('vendorId' in service) && `Vendor: ${vendorMap.get(service.vendorId)}`}</p>
                                </div>
                                <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${riskInfo.color}`}>{riskInfo.text}</span>
                            </div>
                            <p className="text-sm text-slate-400 mt-2">{service.description}</p>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 text-center border-t border-slate-700/50 pt-4">
                                <div>
                                    <p className="text-xs text-slate-500">Uptime</p>
                                    <p className="text-xl font-bold text-cyan-400">{sla.uptimePercentage}%</p>
                                </div>
                                <div>
                                    <p className="text-xs text-slate-500">Response Time</p>
                                    <p className="text-xl font-bold text-cyan-400">{sla.responseTimeHours}h</p>
                                </div>
                                <div>
                                    <p className="text-xs text-slate-500">Breaches (Last 12m)</p>
                                    <p className="text-xl font-bold text-orange-400">{service.breaches.length}</p>
                                </div>
                                <div className="self-center">
                                    <button onClick={() => setLoggingBreachFor(service)} className="text-xs bg-red-800/50 text-red-300 px-3 py-1 rounded-md hover:bg-red-700/50">Log Breach</button>
                                </div>
                            </div>
                        </div>
                    )
                })}
                </div>
            </Card>
        </>
    )
}

export default function ThirdPartyRisk() {
    const [activeTab, setActiveTab] = useState(TABS[0]);

    const renderContent = () => {
        switch (activeTab) {
            case 'Vendors': return <VendorsView />;
            case 'Supplied Services (SLAs)': return <ServicesView type="external"/>;
            case 'Internal Services (OLAs)': return <ServicesView type="internal"/>;
            default: return null;
        }
    };

    return (
        <div className="flex flex-col gap-6">
            <div className="flex border-b border-slate-700 overflow-x-auto">
                {TABS.map(tab => (
                    <button key={tab} onClick={() => setActiveTab(tab)} className={`px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${activeTab === tab ? 'border-b-2 border-cyan-400 text-cyan-400' : 'text-slate-400 hover:text-slate-200'}`}>{tab}</button>
                ))}
            </div>
            <div>{renderContent()}</div>
        </div>
    );
};